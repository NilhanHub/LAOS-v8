# What to upload and when

## New application

Upload to the lead AI:

- `LAOS_v7.0_Complete_System.zip`
- any approved notes, screenshots, research, brand files or constraints

Then receive one new-build implementation ZIP and give only that ZIP to the weaker agent.

## Existing or mid-build application - first entry

Upload to the lead AI:

- `LAOS_v7.0_Complete_System.zip`
- whatever existing specifications, screenshots, URLs, repository archive or prior-agent reports you already have

Receive a capture pack. Give it to a weaker agent with repository access. Receive `App_Intelligence_Return.zip`.

## Existing application - continuation

Upload to the lead AI:

- `App_Intelligence_Return.zip`
- `LAOS_v7.0_Complete_System.zip` when it is not already available
- the new feature, repair or modification discussion

Receive one continuation implementation ZIP and give only that ZIP to the weaker implementation agent.

## When recapture is needed

Recapture or reconciliation is needed when the repository, deployment, database, integrations or major product behaviour changed after the last App Intelligence capture and the new state cannot be established reliably from the implementation evidence.
