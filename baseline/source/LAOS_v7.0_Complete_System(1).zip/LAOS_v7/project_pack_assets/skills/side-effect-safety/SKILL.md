# Side Effect Safety

## Mission
Perform external or destructive actions safely

## Trigger
A task requires deployment, database write, email, cloud change or deletion.

## Procedure
1. Confirm explicit authorization.
2. Create operation ID, unique idempotency key and rollback plan.
3. Advance the side-effect lifecycle before and after execution.
4. Externally verify the result.
5. Do not repeat a terminal or uncertain operation.

## Required outputs
- Terminal journal record
- External proof

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
