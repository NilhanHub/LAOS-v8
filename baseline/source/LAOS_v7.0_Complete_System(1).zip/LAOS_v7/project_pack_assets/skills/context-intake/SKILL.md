# Context Intake

## Mission
Load only the context required for the current task

## Trigger
A task packet or capture contract exists.

## Procedure
1. Read the source-of-truth order.
2. Load requirement, task, preservation, risk and command records relevant to the current scope.
3. Classify facts as verified, reported, inferred or unknown.
4. Do not reread the whole repository unless the task is repository capture or architecture reconciliation.
5. Write a compact context-intake evidence file.

## Required outputs
- Compact task context
- Explicit unknowns and contradictions

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
