# Ui Verification

## Mission
Verify user-visible behaviour as a real user

## Trigger
A UI feature or flow is in scope.

## Procedure
1. Start from the documented entry point and role.
2. Verify loading, empty, error, success and permission states.
3. Perform the complete user journey.
4. Confirm persisted data after refresh or restart.
5. Capture screenshots or video with step references.
6. Distinguish browser inspection from inference.

## Required outputs
- UI journey evidence
- Screen inventory update

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
