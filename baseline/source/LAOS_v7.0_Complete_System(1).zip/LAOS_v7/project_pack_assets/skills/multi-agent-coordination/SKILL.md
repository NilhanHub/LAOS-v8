# Multi Agent Coordination

## Mission
Coordinate parallel agents without conflicting work

## Trigger
Several agents or worktrees are available.

## Procedure
1. Assign non-overlapping tasks and path ownership.
2. Use separate branches or worktrees.
3. Require active lock leases and heartbeats.
4. Merge in dependency order.
5. Rerun integration gates after merge.
6. Resolve conflicts before task closure.

## Required outputs
- Conflict-free merged work
- Integration evidence

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
