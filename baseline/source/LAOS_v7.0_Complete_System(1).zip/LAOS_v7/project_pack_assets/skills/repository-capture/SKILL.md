# Repository Capture

## Mission
Create an evidence-backed App Intelligence Return ZIP

## Trigger
An existing repository is available and no implementation is authorized.

## Procedure
1. Run the capture runtime automatic inspection.
2. Reconcile Git, source, environment, commands, architecture, UI, API, data, authorization, integration, tests and deployment.
3. Populate the feature-status matrix.
4. Reconcile prior-agent claims.
5. Record protected behaviour and unknowns.
6. Validate and finalize the return ZIP.

## Required outputs
- Validated App_Intelligence_Return.zip

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
