# Spec Compilation

## Mission
Compile an approved discussion into a complete project-specific pack

## Trigger
The lead AI has an approved scope and the master LAOS ZIP.

## Procedure
1. Choose new-build, capture, continuation, repair, audit or deployment pack purpose.
2. Assign stable requirement and task IDs.
3. Define roles, journeys, data, security, UI, quality, operations, non-goals and acceptance.
4. Create dependency-aware vertical-slice tasks.
5. Attach exact checks, evidence, permissions, preservation and stop conditions.
6. Lint for contradictions, unmapped requirements and vague placeholders.
7. Compile and self-test the pack.

## Required outputs
- One self-contained project pack
- Traceability from requirements to tasks, checks and evidence

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
