# Spec Amendment

## Mission
Change the approved specification without rewriting history

## Trigger
Current truth materially contradicts the approved scope or a decision must change.

## Procedure
1. Create a proposed amendment with reason and impact.
2. Map affected requirements, tasks, tests, data, deployment and risks.
3. Obtain independent approval.
4. Update the spec only after approval and preserve superseded records.
5. Regenerate affected task packets.

## Required outputs
- Approved amendment
- Updated traceability

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
