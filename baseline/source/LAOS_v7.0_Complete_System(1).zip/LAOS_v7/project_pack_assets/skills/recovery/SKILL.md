# Recovery

## Mission
Resume after interruption or failed work without losing truth

## Trigger
A task is interrupted, blocked, failed or stale.

## Procedure
1. Run doctor and inspect event chain, locks and checkpoints.
2. Compare current files with checkpoint and baseline.
3. Review failed approaches and side effects.
4. Use recover dry-run before confirmation.
5. Reopen with a new plan or escalate.

## Required outputs
- Reconciled state
- Safe resume action

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
