# Context Compaction

## Mission
Create a trustworthy handoff for a new stateless agent

## Trigger
A session is ending or context is large.

## Procedure
1. Generate state from machine files rather than memory.
2. Record current task, checkpoint, exact next action, changed files, latest checks, side effects and blockers.
3. Link authoritative evidence.
4. List failed approaches.
5. Keep historical detail out of the immediate context unless needed.

## Required outputs
- Next-agent launchpad
- Current checkpoint

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
