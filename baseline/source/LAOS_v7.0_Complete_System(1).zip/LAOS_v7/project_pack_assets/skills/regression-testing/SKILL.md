# Regression Testing

## Mission
Protect existing working behaviour while changing the app

## Trigger
A capture baseline or verified current state exists.

## Procedure
1. Identify directly affected and adjacent behaviour.
2. Record the baseline before changes.
3. Run targeted tests during development and the full relevant suite before closure.
4. Exercise success, failure, persistence, refresh and authorization paths.
5. Detect deleted, skipped or weakened tests.
6. Rerun after the final source change.

## Required outputs
- Current regression evidence
- List of untested risk boundaries

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
