# Task Execution

## Mission
Execute a bounded task through the full LAOS lifecycle

## Trigger
A task is READY or already active.

## Procedure
1. Run doctor, verify baseline and read the task packet.
2. Claim and start through the runtime.
3. Write a numbered plan mapping every acceptance criterion to a step, check and evidence item.
4. Create a checkpoint.
5. Implement only allowed paths and record meaningful changes.
6. Run exact checks through LAOS.
7. Register evidence, obtain independent review and advance one state at a time.
8. Stop on failed gates or repeated identical failure.

## Required outputs
- Task state is CLOSED through the runtime
- All evidence is current for the final source fingerprint

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
