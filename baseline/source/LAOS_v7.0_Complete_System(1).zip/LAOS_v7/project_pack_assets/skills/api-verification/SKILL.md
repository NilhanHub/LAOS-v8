# Api Verification

## Mission
Verify an API contract and behaviour

## Trigger
An API route or integration is in scope.

## Procedure
1. Confirm route, method, authentication and authorization.
2. Test valid, invalid, unauthorized, duplicate, timeout and retry cases.
3. Verify stored-data side effects.
4. Record exact request/response samples with secrets redacted.
5. Confirm consumer compatibility.

## Required outputs
- API evidence
- Updated contract status

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
