# Live Integration

## Mission
Implement and verify a real external integration

## Trigger
Credentials and authorization are available.

## Procedure
1. Define provider, environment, request/response contract and error behaviour.
2. Use environment variables by name, never embed values.
3. Create idempotency and rollback records before writes.
4. Verify the real response and external state.
5. Test retries, duplicates, timeouts and permission failures.
6. Record sandbox versus production truth.

## Required outputs
- Externally verified integration
- Side-effect journal terminal state

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
