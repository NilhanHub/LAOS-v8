# Git Truth

## Mission
Establish exact repository state

## Trigger
The current task depends on source history or handoff truth.

## Procedure
1. Record root, branch, full commit, status, staged, unstaged and untracked files.
2. Explain pre-existing dirty work before editing.
3. Record remotes without credentials, tags, submodules and LFS where relevant.
4. Use per-task baselines to distinguish prior work from new changes.
5. Do not call a working tree clean when ignored or external generated state matters.

## Required outputs
- Git truth evidence
- Per-task baseline

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
