# Security Review

## Mission
Review security boundaries of a task

## Trigger
Authentication, authorization, secrets, external data or sensitive actions are involved.

## Procedure
1. Threat-model inputs, tools, commands and external content.
2. Verify backend authorization and data isolation.
3. Scan for secrets and unsafe evidence.
4. Review dependencies and dangerous scripts.
5. Check prompt-injection boundaries.
6. Limit permissions and blast radius.

## Required outputs
- Security review evidence
- Blocking issues or PASS verdict

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
