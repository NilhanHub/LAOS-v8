# Data Migrations

## Mission
Change data safely and reversibly

## Trigger
A schema, migration or data transformation is required.

## Procedure
1. Record current schema and migration state.
2. Define forward and rollback or compensation paths.
3. Back up or snapshot where authorized.
4. Test migration on representative non-sensitive data.
5. Verify indexes, constraints, uniqueness and idempotency.
6. Verify app behaviour before and after.

## Required outputs
- Migration evidence
- Rollback evidence or explicit irreversible approval

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
