# Deployment Verification

## Mission
Deploy and verify the actual target environment

## Trigger
Deployment is authorized and in scope.

## Procedure
1. Record current live revision and rollback target.
2. Create idempotency and side-effect entries.
3. Run deployment command.
4. Verify revision, health, URL, configuration and migration state.
5. Run real smoke tests.
6. Record rollback readiness.

## Required outputs
- Deployment truth evidence
- Terminal side-effect record

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
