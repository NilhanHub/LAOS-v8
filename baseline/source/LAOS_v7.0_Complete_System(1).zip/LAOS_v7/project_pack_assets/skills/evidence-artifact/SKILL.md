# Evidence Artifact

## Mission
Create reviewable, tamper-evident evidence and final artifacts

## Trigger
A task or release needs proof.

## Procedure
1. Write evidence under the root Evidence folder.
2. State what each item proves and does not prove.
3. Register hashes and source fingerprints.
4. Exclude secrets and personal data.
5. Build artifacts from clean staging.
6. Externally extract and compare contents.
7. Lock after verification.

## Required outputs
- Registered evidence
- Verified immutable artifact

## Failure rule
Stop and record the exact blocker when required proof, permission, tool access or current repository truth is unavailable. Do not silently substitute a weaker result.
