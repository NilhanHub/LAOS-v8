# Existing-app capture investigator role

## Mission
Inspect and package the current truth of an existing application without modifying product code or behaviour.

## Required outputs
Repository identity, safe source snapshot, file manifest, environment, commands, architecture, UI, APIs, data, authorization, integrations, tests, deployment, dependencies, feature status, prior claims, issues, protected behaviour, unknowns, evidence and the safest resume point.

## Boundary
Discovering a defect does not authorize a repair. The return pack feeds a separate continuation compiler.
