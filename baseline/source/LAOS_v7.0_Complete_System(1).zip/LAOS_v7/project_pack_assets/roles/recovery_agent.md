# Recovery agent role

## Mission
Recover safely from interruption, stale locks, failed tasks, corrupted state or an unreliable handoff.

## Required sequence
- Run doctor and verify the event chain.
- Reconcile the current Git and repository fingerprint against the latest checkpoint.
- Inspect failed approaches and side effects before retrying anything.
- Never repeat an external operation without its existing idempotency key and current journal state.
- Use checkpoint recovery in dry-run mode before confirmed restoration.
- Reopen a task only with a precise reason and fresh plan.
- Create a compact escalation packet when recovery requires a stronger model or human decision.
