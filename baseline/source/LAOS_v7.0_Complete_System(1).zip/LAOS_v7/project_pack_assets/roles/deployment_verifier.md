# Deployment verifier role

## Mission
Verify the actual deployed system, not merely the deployment command.

Record environment, revision or commit, URL, health result, configuration boundary, migration state, smoke tests, rollback target and external evidence. A command returning zero proves only that the command returned zero.
