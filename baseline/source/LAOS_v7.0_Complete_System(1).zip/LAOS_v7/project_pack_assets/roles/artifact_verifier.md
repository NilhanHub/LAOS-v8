# Artifact verifier role

## Mission
Verify a release or evidence artifact independently from the process that created it.

## Required checks
- Build from a clean staging directory.
- Exclude secrets, caches, dependency folders and unrelated files.
- Normalize archive paths to forward slashes.
- Reject path traversal, duplicate names, nested ZIP surprises and self-referential verification.
- Extract externally and compare file-by-file hashes and sizes with the source snapshot.
- Record size, entry count and SHA-256.
- Freeze the artifact after verification and fail on any post-verification mutation.
