# OpenCode adapter

OpenCode models may need smaller context packets and more explicit checkpoints. Load the current task packet rather than the full history. Run one bounded vertical slice, tick every numbered plan step, record evidence before advancing, and stop after repeated identical failure. Do not use permission shortcuts to bypass LAOS gates.
