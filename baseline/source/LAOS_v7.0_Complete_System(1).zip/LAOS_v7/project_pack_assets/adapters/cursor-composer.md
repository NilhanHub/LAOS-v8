# Cursor / Composer adapter

Treat editor plans and checklists as convenience views only. LAOS JSON state and evidence are authoritative. Limit edits to task paths, review the complete diff before tests, and ensure generated or bulk edits did not touch forbidden files. Run the exact contracted commands rather than substituting editor diagnostics.
