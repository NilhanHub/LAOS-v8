# Codex adapter

Use the universal LAOS project files as authority. Keep plans short and executable, run commands through the LAOS runtime, and use independent review context for high-risk work. Do not let a summary or previous turn replace repository reconciliation. Preserve the event, evidence and checkpoint files in the project.
