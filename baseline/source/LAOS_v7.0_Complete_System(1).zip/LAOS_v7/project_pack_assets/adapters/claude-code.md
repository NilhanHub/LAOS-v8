# Claude Code adapter

Route through `CLAUDE.md` into `START_HERE.md`; unique requirements remain in universal LAOS files. Use Skills only when their trigger applies. Keep the todo state aligned with the machine task state, but never treat a UI todo checkmark as task closure. Use a fresh subagent or separate context for required independent review where available.
