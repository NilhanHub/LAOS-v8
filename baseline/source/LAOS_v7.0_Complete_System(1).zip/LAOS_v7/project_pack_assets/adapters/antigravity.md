# Antigravity adapter

Use the repository root and LAOS runtime as the persistent source of truth across sessions. Create checkpoints before autonomous multi-file changes. Reconcile any partial work after interruption before resuming. Do not infer external or browser success from a plan or tool animation.
