# Generic desktop-agent adapter

Read `START_HERE.md` first. Use exact LAOS commands and files. Work from the actual repository root; never assume its path. If the platform cannot run a required command, record the exact limitation and stop at the evidence boundary. Do not manually edit runtime state. Maintain one active task and a current checkpoint.
