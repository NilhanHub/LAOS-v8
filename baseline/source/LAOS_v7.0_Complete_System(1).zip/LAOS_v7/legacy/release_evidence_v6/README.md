# Internal Release Evidence

These files record checks run against the extracted master system before final packaging.

- `self_tests.txt` - executable runtime and compiler tests.
- `master_validation.json` - required-file, JSON, compiler, doctor, and test validation.
- `build_verification.json` - summary of final build checks and DOCX visual QA.
- `CONTENT_INTEGRITY_MANIFEST.json` - hashes for every intentional release file except itself.

A whole-ZIP SHA-256 verification record must remain external because placing it inside the ZIP would change the ZIP it claims to verify.
