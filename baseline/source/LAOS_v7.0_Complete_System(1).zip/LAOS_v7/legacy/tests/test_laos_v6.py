import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

DIST = Path(__file__).resolve().parents[1]
COMPILER = DIST / "tools" / "compile_project_pack.py"
spec = importlib.util.spec_from_file_location("laos_runtime", DIST / "laos_runtime.py")
laos = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(laos)


class LaosV6Tests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory(prefix="laos_v6_test_")
        self.base = Path(self.td.name)
        self.blueprint = self.base / "blueprint.json"
        data = {
            "engagement_mode": "new_project",
            "include_reconciliation_task": False,
            "project_name": "Runtime Test Project",
            "project_summary": "Exercise LAOS gates.",
            "requirements": [{"id": "REQ-001", "text": "Complete the verified task.", "acceptance": ["Task closes through all gates"]}],
            "tasks": [{
                "id": "TASK-001", "title": "Verified no-code task",
                "description": "Exercise all lifecycle gates without product changes.",
                "requirements": ["REQ-001"], "dependencies": [],
                "allowed_paths": ["Evidence/**", "notes/**"],
                "forbidden_paths": ["forbidden/**", ".laos/runtime/**", "spec/**"],
                "no_code_change": True,
                "acceptance_criteria": ["Check passes", "Evidence exists", "Review passes"],
                "checks": [{"id": "CHECK-OK", "command": f'"{sys.executable}" -c "print(123)"', "stage": "TESTED", "required": True}],
                "evidence_required": [
                    {"path": "Evidence/TASK-001/plan.md", "stage": "IMPLEMENTED", "min_bytes": 20},
                    {"path": "Evidence/TASK-001/tests.md", "stage": "EVIDENCED", "min_bytes": 20},
                    {"path": "Evidence/TASK-001/review.md", "stage": "REVIEWED", "min_bytes": 20}
                ],
                "review_required": True, "side_effects_required": ["op-1"]
            }]
        }
        self.blueprint.write_text(json.dumps(data), encoding="utf-8")
        self.project = self.base / "project"
        cp = subprocess.run([sys.executable, str(COMPILER), str(self.blueprint), str(self.project)], text=True, capture_output=True, timeout=30)
        self.assertEqual(cp.returncode, 0, cp.stderr)
        for cmd in (["git", "init", "-q"], ["git", "config", "user.email", "test@example.com"], ["git", "config", "user.name", "Test"], ["git", "add", "."], ["git", "commit", "-qm", "initial"]):
            cp = subprocess.run(cmd, cwd=self.project, text=True, capture_output=True, timeout=30)
            self.assertEqual(cp.returncode, 0, cp.stderr)

    def tearDown(self):
        self.td.cleanup()

    def create_evidence(self):
        ev = self.project / "Evidence" / "TASK-001"
        ev.mkdir(parents=True)
        (ev / "plan.md").write_text("A sufficiently detailed implementation plan.\n", encoding="utf-8")
        (ev / "tests.md").write_text("The required check executed successfully.\n", encoding="utf-8")
        (ev / "review.md").write_text("Independent reviewer verdict: PASS.\n", encoding="utf-8")

    def test_compile_and_doctor(self):
        result = laos.doctor(self.project)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["event_chain"]["ok"])

    def test_full_lifecycle_with_side_effect(self):
        laos.refresh_ready(self.project)
        laos.claim_task(self.project, "TASK-001", "builder")
        laos.start_task(self.project, "TASK-001", "builder")
        self.create_evidence()
        laos.advance_task(self.project, "TASK-001", "IMPLEMENTED", "builder", None)
        rec = laos.run_check(self.project, "TASK-001", "CHECK-OK", "builder", None)
        self.assertEqual(rec["exit_code"], 0)
        laos.advance_task(self.project, "TASK-001", "TESTED", "builder", None)
        laos.record_evidence(self.project, "TASK-001", "Evidence/TASK-001/plan.md", "plan", "builder")
        laos.record_evidence(self.project, "TASK-001", "Evidence/TASK-001/tests.md", "test", "builder")
        laos.advance_task(self.project, "TASK-001", "EVIDENCED", "builder", None)
        laos.record_review(self.project, "TASK-001", "PASS", "reviewer", "Evidence/TASK-001/review.md", None)
        laos.advance_task(self.project, "TASK-001", "REVIEWED", "builder", None)
        with self.assertRaises(laos.LaosError):
            laos.advance_task(self.project, "TASK-001", "CLOSED", "builder", None)
        laos.side_effect_transition(self.project, "TASK-001", "op-1", "PROPOSED", "builder", "External operation", "idempotent-1", None, "Compensate")
        for state in ["AUTHORIZED", "PREPARED", "EXECUTED", "EXTERNALLY_VERIFIED", "COMMITTED"]:
            laos.side_effect_transition(self.project, "TASK-001", "op-1", state, "builder", None, None, None, None)
        laos.advance_task(self.project, "TASK-001", "CLOSED", "builder", None)
        self.assertEqual(laos.audit(self.project)["status"], "PASS")

    def test_scope_gate_rejects_forbidden_change(self):
        laos.refresh_ready(self.project)
        laos.claim_task(self.project, "TASK-001", "builder")
        laos.start_task(self.project, "TASK-001", "builder")
        (self.project / "forbidden").mkdir()
        (self.project / "forbidden" / "bad.txt").write_text("bad", encoding="utf-8")
        subprocess.run(["git", "add", "forbidden/bad.txt"], cwd=self.project, check=True)
        with self.assertRaises(laos.LaosError):
            laos.advance_task(self.project, "TASK-001", "IMPLEMENTED", "builder", None)

    def test_event_chain_detects_tamper(self):
        events = self.project / ".laos/state/events.jsonl"
        events.write_text(events.read_text(encoding="utf-8").replace("PACK_COMPILED", "PACK_CHANGED", 1), encoding="utf-8")
        result = laos.doctor(self.project)
        self.assertEqual(result["status"], "FAIL")
        self.assertFalse(result["event_chain"]["ok"])


    def test_existing_project_compiler_adds_reconciliation_and_templates(self):
        bp = self.base / "existing.json"
        data = {
            "engagement_mode": "existing_project_feature",
            "project_name": "Existing Project Feature",
            "project_summary": "Add a feature safely to an existing app.",
            "requirements": [{"id": "REQ-001", "text": "Feature works.", "acceptance": ["Verified"]}],
            "tasks": [{
                "id": "TASK-001", "title": "Implement feature", "description": "Implement after reconciliation.",
                "requirements": ["REQ-001"], "dependencies": [], "allowed_paths": ["src/**", "Evidence/**"],
                "forbidden_paths": [".git/**", ".laos/runtime/**", "spec/**"],
                "acceptance_criteria": ["Feature works"],
                "checks": [{"id": "CHECK-OK", "command": f'"{sys.executable}" -c "print(1)"'}]
            }]
        }
        bp.write_text(json.dumps(data), encoding="utf-8")
        out = self.base / "existing_project"
        cp = subprocess.run([sys.executable, str(COMPILER), str(bp), str(out)], text=True, capture_output=True, timeout=30)
        self.assertEqual(cp.returncode, 0, cp.stderr)
        graph = json.loads((out / "work/task_graph.json").read_text(encoding="utf-8"))
        tasks = {t["id"]: t for t in graph["tasks"]}
        self.assertIn("TASK-000", tasks)
        self.assertIn("TASK-000", tasks["TASK-001"]["dependencies"])
        for rel in [
            "PROJECT_ENTRY_CONTEXT.md", "REPOSITORY_BASELINE.md", "EXISTING_WORK_INVENTORY.md",
            "SPEC_RECONCILIATION.md", "CHANGE_BOUNDARY.md", "DEPLOYMENT_STATE.md",
            "PRIOR_WORK_HANDOFF.md", "TECHNICAL_DEBT_AND_KNOWN_ISSUES.md",
            "ASSUMPTIONS_AND_UNKNOWNS.md", "MID_BUILD_RESUME_PLAN.md",
            ".laos/templates/intake/REPOSITORY_RECONCILIATION.md",
            ".laos/templates/evidence/claim_to_evidence.md"
        ]:
            self.assertTrue((out / rel).is_file(), rel)

    def test_uncommitted_harness_import_is_ignored_but_modified_harness_is_not(self):
        bp = self.base / "import.json"
        data = {
            "engagement_mode": "new_project", "include_reconciliation_task": False,
            "project_name": "Import Scope Test", "project_summary": "Test imported harness scope.",
            "requirements": [{"id": "REQ-001", "text": "Create allowed file.", "acceptance": ["File exists"]}],
            "tasks": [{
                "id": "TASK-001", "title": "Create allowed file", "description": "Create a file in notes.",
                "requirements": ["REQ-001"], "dependencies": [], "allowed_paths": ["notes/**", "Evidence/**"],
                "forbidden_paths": [".git/**", ".laos/runtime/**", "spec/**"],
                "acceptance_criteria": ["Allowed file exists"], "checks": [], "review_required": False
            }]
        }
        bp.write_text(json.dumps(data), encoding="utf-8")
        out = self.base / "import_project"
        cp = subprocess.run([sys.executable, str(COMPILER), str(bp), str(out)], text=True, capture_output=True, timeout=30)
        self.assertEqual(cp.returncode, 0, cp.stderr)
        subprocess.run(["git", "init", "-q"], cwd=out, check=True)
        laos.refresh_ready(out)
        laos.claim_task(out, "TASK-001", "builder")
        laos.start_task(out, "TASK-001", "builder")
        (out / "notes").mkdir()
        (out / "notes" / "ok.txt").write_text("real change", encoding="utf-8")
        laos.advance_task(out, "TASK-001", "IMPLEMENTED", "builder", None)

        # A changed harness file no longer matches the compiler manifest and must be scope-checked.
        (out / "START_HERE.md").write_text("tampered\n", encoding="utf-8")
        task = json.loads((out / "work/task_graph.json").read_text(encoding="utf-8"))["tasks"][0]
        state = json.loads((out / ".laos/state/current_state.json").read_text(encoding="utf-8"))["task_states"]["TASK-001"]
        with self.assertRaises(laos.LaosError):
            laos.validate_changed_files(out, task, state)

    def test_artifact_verification_and_lock(self):
        src = self.project / "artifact_source"
        src.mkdir()
        (src / "a.txt").write_text("artifact data", encoding="utf-8")
        artifact = self.project / "release.zip"
        laos.artifact_build(self.project, "artifact_source", "release.zip")
        result = laos.artifact_verify(self.project, "release.zip", "artifact_source", None)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(laos.artifact_lock_check(artifact)["status"], "PASS")
        with artifact.open("ab") as f:
            f.write(b"mutation")
        self.assertEqual(laos.artifact_lock_check(artifact)["status"], "FAIL")


if __name__ == "__main__":
    unittest.main(verbosity=2)
