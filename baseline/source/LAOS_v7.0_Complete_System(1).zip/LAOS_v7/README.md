# LAOS v7.0 - Long-Horizon Agent Operating System

LAOS is a reusable master system for turning an approved app discussion into a self-contained pack that a weaker coding agent can execute with far less skipping, drift, unsupported completion, context loss and repository damage.

LAOS v7 has two equal primary missions:

1. **New build:** compile a complete implementation pack for a weaker agent to create a new app.
2. **Existing or mid-build app:** compile a capture-only pack that makes a weaker agent return one evidence-backed `App_Intelligence_Return.zip`; then compile that returned truth into a continuation, repair, feature, audit or deployment pack.

The master ZIP is the factory. It is not normally the assignment given to the implementation agent.

## Begin here

- Nilhan: `START_HERE_FOR_NILHAN.md`
- ChatGPT or another lead AI: `FOR_CHATGPT_PACK_COMPILER.md`
- Full guide: `docs/LAOS_v7_MASTER_GUIDE.md`
- Exact two-mission workflow: `docs/TWO_MISSION_WORKFLOW.md`
- Tool map: `LAOS_CONTENTS_MAP.md`

## Main executable tools

- `tools/compile_project_pack.py` - new-build or direct implementation pack compiler
- `tools/compile_capture_pack.py` - existing-app capture pack compiler
- `tools/capture_runtime.py` - read-only repository inspection and App Intelligence finalizer
- `tools/validate_return_pack.py` - validates returned App Intelligence ZIPs
- `tools/compile_continuation_pack.py` - turns a valid return ZIP plus an approved change request into the next implementation pack
- `laos_runtime.py` - task, evidence, checkpoint, review, side-effect, recovery and final-acceptance enforcement copied into implementation packs

## Truth boundary

No harness can literally give a weaker model the raw reasoning ability of a stronger model or guarantee zero errors. LAOS improves practical performance by making the correct process explicit, bounded, persistent, checkable, recoverable and difficult to bypass. It requires unsupported claims and unresolved unknowns to remain visible.
