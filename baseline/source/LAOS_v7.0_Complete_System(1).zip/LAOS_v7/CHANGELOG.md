# Changelog

## 7.0.0

- Reframed LAOS around two equal missions: new-build implementation and existing-app capture-to-continuation.
- Added first-class Existing-App Capture Pack compiler.
- Added safe automatic repository inspection and App Intelligence Return ZIP finalizer.
- Added formal return-pack schemas, validation and secret-aware source snapshotting.
- Added automatic continuation compiler with capture provenance, repository fingerprint and stale-baseline gate.
- Expanded new-build specification into roles, permissions, journeys, data, security, privacy, UI, quality, operations, deployment and preservation contracts.
- Added source-fingerprint freshness for checks and evidence.
- Added test-change protection, exact check commands, command timeout/output/env controls and repeated-failure escalation.
- Added independent review enforcement, lock leases, heartbeats, restorable checkpoints, recovery, stale-lock handling and task reopening.
- Added idempotency-key uniqueness, side-effect rollback requirements, amendments, event anchoring and final acceptance.
- Expanded roles, adapters and executable operating Skills.
- Added comprehensive capture/continuation and runtime tests.

## 6.0.0

First executable LAOS implementation pack compiler and portable task/evidence runtime.
