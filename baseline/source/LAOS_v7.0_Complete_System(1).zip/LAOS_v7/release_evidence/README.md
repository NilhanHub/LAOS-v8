# LAOS v7.0 internal release evidence

This folder records the checks performed before the master ZIP was frozen.

- `self_tests.txt`: fourteen executable tests covering the runtime, compiler audits and capture-to-continuation round trip.
- `master_validation.json`: required-file, JSON, Python, new-build and capture smoke validation.
- `docx_visual_qa.json`: visual inspection of all nineteen rendered guide pages.
- `docx_a11y_audit.json`: document accessibility audit.
- `secret_scan.json`: conservative plaintext secret-pattern scan.
- `build_verification.json`: concise release summary.
- `CONTENT_INTEGRITY_MANIFEST.json`: generated last and excludes itself to avoid self-reference.

The final ZIP hash and extraction comparison are calculated externally after the ZIP is built. The ZIP is not modified after that verification.
