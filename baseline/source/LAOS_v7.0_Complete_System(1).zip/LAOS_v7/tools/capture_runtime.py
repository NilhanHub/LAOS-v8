#!/usr/bin/env python3
"""LAOS v7 existing-application capture runtime.

This tool performs a read-only repository inspection, creates a structured App
Intelligence working directory, validates the investigator's completed records,
and produces one self-contained App Intelligence Return ZIP.

It uses only the Python standard library and is intentionally conservative:
secret-bearing files, dependency caches, VCS internals, and large generated
artifacts are excluded from the source snapshot by default.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import uuid
import zipfile
from pathlib import Path
from typing import Any, Iterable

VERSION = "7.0.0"
TEXT_EXTENSIONS = {
    ".txt", ".md", ".json", ".jsonc", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".java", ".kt", ".kts",
    ".go", ".rs", ".rb", ".php", ".cs", ".cpp", ".c", ".h", ".hpp", ".sql",
    ".html", ".htm", ".css", ".scss", ".sass", ".less", ".xml", ".graphql",
    ".gql", ".sh", ".ps1", ".bat", ".cmd", ".dockerfile", ".properties",
}
DEFAULT_EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", "node_modules", ".venv", "venv", "env", "__pycache__",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox", ".next", ".nuxt",
    "dist", "build", "out", "target", "coverage", ".coverage", ".turbo", ".cache",
    ".idea", ".vscode", ".DS_Store", "Pods", "vendor", "bin", "obj",
    "App_Intelligence_Working", "Evidence",
}
SENSITIVE_NAMES = {
    ".env", ".env.local", ".env.production", ".env.development", ".npmrc", ".pypirc",
    "credentials.json", "service-account.json", "service_account.json", "secrets.json",
    "id_rsa", "id_ed25519", "known_hosts", "authorized_keys", "key.pem", "cert.pem",
}
SENSITIVE_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".jks", ".keystore", ".sqlite", ".db"}
SECRET_PATTERNS = [
    ("AWS_ACCESS_KEY", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("PRIVATE_KEY", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("OPENAI_STYLE_KEY", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b")),
    ("GITHUB_TOKEN", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b")),
    ("GENERIC_SECRET_ASSIGNMENT", re.compile(r"(?i)\b(api[_-]?key|secret|token|password|passwd)\s*[:=]\s*['\"]?[^\s'\"]{10,}")),
]
REQUIRED_FILES = [
    "RETURN_START_HERE.md",
    "APP_INTELLIGENCE_MANIFEST.json",
    "PROJECT_EXECUTIVE_SUMMARY.md",
    "REPOSITORY_IDENTITY.json",
    "SOURCE_MANIFEST.json",
    "ENVIRONMENT_MANIFEST.json",
    "ARCHITECTURE_MAP.md",
    "FEATURE_STATUS_MATRIX.json",
    "UI_INVENTORY.json",
    "API_INVENTORY.json",
    "DATA_AND_MIGRATION_MAP.json",
    "AUTHORIZATION_MAP.md",
    "INTEGRATIONS_INVENTORY.json",
    "COMMAND_BASELINE.json",
    "TEST_BASELINE.json",
    "DEPLOYMENT_TRUTH.json",
    "DEPENDENCY_AND_LICENSE_REPORT.json",
    "PRIOR_AGENT_CLAIMS.json",
    "KNOWN_ISSUES.json",
    "PROTECTED_AREAS.json",
    "ASSUMPTIONS_AND_UNKNOWNS.json",
    "RECOMMENDED_RESUME_PLAN.md",
    "EVIDENCE_INDEX.json",
]
NARRATIVE_MIN_BYTES = {
    "RETURN_START_HERE.md": 120,
    "PROJECT_EXECUTIVE_SUMMARY.md": 300,
    "ARCHITECTURE_MAP.md": 300,
    "AUTHORIZATION_MAP.md": 150,
    "RECOMMENDED_RESUME_PLAN.md": 250,
}

class CaptureError(RuntimeError):
    pass


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        if default is not None:
            return default
        raise CaptureError(f"Missing JSON file: {path}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise CaptureError(f"Invalid JSON in {path}: {exc}") from exc


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_rel(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def run_command(args: list[str], cwd: Path, timeout: int = 20) -> dict[str, Any]:
    try:
        cp = subprocess.run(args, cwd=cwd, text=True, capture_output=True, timeout=timeout, shell=False)
        output = ((cp.stdout or "") + ("\n" + cp.stderr if cp.stderr else "")).strip()
        return {"command": args, "exit_code": cp.returncode, "output": output[:20000], "timed_out": False}
    except FileNotFoundError:
        return {"command": args, "exit_code": None, "output": "command not found", "timed_out": False}
    except subprocess.TimeoutExpired as exc:
        return {"command": args, "exit_code": None, "output": str(exc), "timed_out": True}


def sanitize_remote(url: str) -> str:
    # Remove credentials from https://user:token@host/path and similar URLs.
    url = re.sub(r"(https?://)[^/@\s]+@", r"\1[REDACTED]@", url)
    return url


def git_identity(repo: Path) -> dict[str, Any]:
    inside = run_command(["git", "rev-parse", "--is-inside-work-tree"], repo)
    if inside["exit_code"] != 0 or inside["output"].strip() != "true":
        return {"git_available": False, "captured_at": utc_now(), "repository_root": str(repo)}

    def git(*args: str, timeout: int = 20) -> dict[str, Any]:
        return run_command(["git", "-c", "core.quotepath=false", *args], repo, timeout=timeout)

    remotes = []
    r = git("remote", "-v")
    if r["exit_code"] == 0:
        for line in r["output"].splitlines():
            parts = line.split()
            if len(parts) >= 2:
                remotes.append({"name": parts[0], "url": sanitize_remote(parts[1]), "kind": parts[2].strip("()") if len(parts) > 2 else ""})
    status = git("status", "--porcelain=v1", "--untracked-files=all")
    branches = git("branch", "--format=%(refname:short)|%(objectname)")
    tags = git("tag", "--list", "--sort=-creatordate")
    submodules = git("submodule", "status", "--recursive", timeout=60)
    lfs = run_command(["git", "lfs", "ls-files"], repo, timeout=30)
    return {
        "git_available": True,
        "captured_at": utc_now(),
        "repository_root": str(repo.resolve()),
        "branch": git("branch", "--show-current")["output"].strip(),
        "head_commit": git("rev-parse", "HEAD")["output"].strip(),
        "head_commit_short": git("rev-parse", "--short", "HEAD")["output"].strip(),
        "head_tree": git("rev-parse", "HEAD^{tree}")["output"].strip(),
        "status_porcelain": status["output"].splitlines() if status["exit_code"] == 0 and status["output"] else [],
        "is_dirty": bool(status["output"].strip()) if status["exit_code"] == 0 else None,
        "remotes": remotes,
        "branches": [dict(zip(["name", "commit"], line.split("|", 1))) for line in branches["output"].splitlines() if "|" in line] if branches["exit_code"] == 0 else [],
        "recent_tags": tags["output"].splitlines()[:100] if tags["exit_code"] == 0 else [],
        "submodules": submodules["output"].splitlines() if submodules["exit_code"] == 0 and submodules["output"] else [],
        "git_lfs_files": lfs["output"].splitlines() if lfs["exit_code"] == 0 and lfs["output"] else [],
    }


def is_sensitive_name(path: Path) -> bool:
    lower_name = path.name.lower()
    if lower_name in SENSITIVE_NAMES or path.suffix.lower() in SENSITIVE_SUFFIXES:
        return True
    if lower_name.startswith(".env") and lower_name not in {".env.example", ".env.sample", ".env.template"}:
        return True
    return any(token in lower_name for token in ["secret", "credential", "private-key", "private_key"]) and path.suffix.lower() in {".json", ".yaml", ".yml", ".txt"}


def likely_text(path: Path) -> bool:
    if path.name in {"Dockerfile", "Makefile", "Procfile", "Gemfile", "Rakefile"}:
        return True
    return path.suffix.lower() in TEXT_EXTENSIONS


def scan_text_for_secrets(text: str) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    for label, pattern in SECRET_PATTERNS:
        match = pattern.search(text)
        if match:
            line = text.count("\n", 0, match.start()) + 1
            hits.append({"type": label, "line": line})
    return hits


def iter_repo_files(repo: Path, excluded_dirs: set[str]) -> Iterable[Path]:
    for root, dirs, files in os.walk(repo):
        root_path = Path(root)
        dirs[:] = [d for d in dirs if d not in excluded_dirs and not d.startswith(".laos_capture")]
        for name in files:
            path = root_path / name
            try:
                if path.is_symlink() or not path.is_file():
                    continue
            except OSError:
                continue
            yield path


def repository_manifest(repo: Path, snapshot_dir: Path | None, config: dict[str, Any]) -> dict[str, Any]:
    excluded_dirs = set(DEFAULT_EXCLUDED_DIRS) | set(config.get("additional_excluded_directories", []))
    max_file_bytes = int(config.get("max_snapshot_file_bytes", 10 * 1024 * 1024))
    max_total_bytes = int(config.get("max_snapshot_total_bytes", 500 * 1024 * 1024))
    include_snapshot = bool(config.get("include_safe_source_snapshot", True))
    entries: list[dict[str, Any]] = []
    exclusions: list[dict[str, Any]] = []
    secret_findings: list[dict[str, Any]] = []
    total_included = 0
    if snapshot_dir and include_snapshot:
        snapshot_dir.mkdir(parents=True, exist_ok=True)
    for path in iter_repo_files(repo, excluded_dirs):
        rel = safe_rel(path, repo)
        try:
            size = path.stat().st_size
        except OSError as exc:
            exclusions.append({"path": rel, "reason": f"stat failed: {exc}"})
            continue
        entry = {"path": rel, "bytes": size, "suffix": path.suffix.lower(), "sha256": None, "snapshot_included": False}
        if is_sensitive_name(path):
            exclusions.append({"path": rel, "reason": "sensitive filename or file type"})
            entry["exclusion_reason"] = "sensitive filename or file type"
            entries.append(entry)
            continue
        if size > max_file_bytes:
            exclusions.append({"path": rel, "reason": f"larger than max_snapshot_file_bytes={max_file_bytes}"})
            entry["exclusion_reason"] = "oversized"
            entries.append(entry)
            continue
        try:
            entry["sha256"] = sha256_file(path)
        except OSError as exc:
            exclusions.append({"path": rel, "reason": f"hash failed: {exc}"})
            entry["exclusion_reason"] = "hash failed"
            entries.append(entry)
            continue
        secret_hits: list[dict[str, Any]] = []
        if likely_text(path) and size <= 5 * 1024 * 1024:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
                secret_hits = scan_text_for_secrets(text)
            except OSError:
                pass
        if secret_hits:
            secret_findings.append({"path": rel, "findings": secret_hits})
            exclusions.append({"path": rel, "reason": "possible secret detected; content not copied"})
            entry["exclusion_reason"] = "possible secret detected"
            entry["secret_findings"] = secret_hits
            entries.append(entry)
            continue
        if include_snapshot and snapshot_dir:
            if total_included + size > max_total_bytes:
                exclusions.append({"path": rel, "reason": "snapshot total byte limit reached"})
                entry["exclusion_reason"] = "snapshot total byte limit reached"
            else:
                destination = snapshot_dir / rel
                destination.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(path, destination)
                    entry["snapshot_included"] = True
                    total_included += size
                except OSError as exc:
                    exclusions.append({"path": rel, "reason": f"copy failed: {exc}"})
                    entry["exclusion_reason"] = "copy failed"
        entries.append(entry)
    fingerprint_input = "\n".join(f"{e['path']}|{e.get('sha256') or 'NOHASH'}|{e['bytes']}" for e in sorted(entries, key=lambda x: x["path"]))
    fingerprint = hashlib.sha256(fingerprint_input.encode("utf-8")).hexdigest()
    return {
        "captured_at": utc_now(),
        "repository_root": str(repo.resolve()),
        "file_count": len(entries),
        "snapshot_included_file_count": sum(1 for e in entries if e.get("snapshot_included")),
        "snapshot_included_bytes": total_included,
        "repository_content_fingerprint": fingerprint,
        "entries": entries,
        "exclusions": exclusions,
        "possible_secret_findings": secret_findings,
        "policy": {
            "include_safe_source_snapshot": include_snapshot,
            "max_snapshot_file_bytes": max_file_bytes,
            "max_snapshot_total_bytes": max_total_bytes,
            "excluded_directories": sorted(excluded_dirs),
        },
    }


def detect_environment(repo: Path) -> dict[str, Any]:
    tools = {
        "python": [sys.executable, "--version"],
        "git": ["git", "--version"],
        "node": ["node", "--version"],
        "npm": ["npm", "--version"],
        "pnpm": ["pnpm", "--version"],
        "yarn": ["yarn", "--version"],
        "bun": ["bun", "--version"],
        "deno": ["deno", "--version"],
        "docker": ["docker", "--version"],
        "dotnet": ["dotnet", "--version"],
        "java": ["java", "-version"],
        "go": ["go", "version"],
        "rustc": ["rustc", "--version"],
        "cargo": ["cargo", "--version"],
        "php": ["php", "--version"],
        "ruby": ["ruby", "--version"],
    }
    results = {name: run_command(cmd, repo, timeout=12) for name, cmd in tools.items()}
    env_names = sorted(name for name in os.environ if any(token in name.upper() for token in ["API", "KEY", "TOKEN", "SECRET", "PASSWORD", "DATABASE", "URL", "HOST", "PORT", "ENV", "PROJECT", "REGION"]))
    manifests = []
    known = ["package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lockb", "pyproject.toml", "requirements.txt", "poetry.lock", "Pipfile", "Pipfile.lock", "Cargo.toml", "Cargo.lock", "go.mod", "go.sum", "pom.xml", "build.gradle", "build.gradle.kts", "Gemfile", "Gemfile.lock", "composer.json", "composer.lock", "Dockerfile", "docker-compose.yml", "docker-compose.yaml", "Makefile"]
    for name in known:
        for path in repo.rglob(name):
            if any(part in DEFAULT_EXCLUDED_DIRS for part in path.relative_to(repo).parts):
                continue
            manifests.append(safe_rel(path, repo))
    return {
        "captured_at": utc_now(),
        "platform": {"system": platform.system(), "release": platform.release(), "version": platform.version(), "machine": platform.machine(), "python": platform.python_version()},
        "tools": results,
        "environment_variable_names_only": env_names,
        "package_and_build_manifests": sorted(set(manifests)),
        "values_redacted": True,
    }


def parse_package_json(repo: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    commands: list[dict[str, Any]] = []
    dependencies: list[dict[str, Any]] = []
    for path in repo.rglob("package.json"):
        if any(part in DEFAULT_EXCLUDED_DIRS for part in path.relative_to(repo).parts):
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        rel = safe_rel(path, repo)
        for name, command in (data.get("scripts") or {}).items():
            commands.append({"source": rel, "name": name, "command": command, "verified": False, "result": "NOT_RUN_BY_AUTOMATIC_CAPTURE"})
        for kind in ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"]:
            for name, version in (data.get(kind) or {}).items():
                dependencies.append({"source": rel, "name": name, "declared_version": version, "kind": kind, "license": "UNKNOWN", "vulnerability_status": "NOT_CHECKED"})
    return commands, dependencies


def heuristic_inventories(repo: Path) -> dict[str, Any]:
    ui: list[dict[str, Any]] = []
    api: list[dict[str, Any]] = []
    data: list[dict[str, Any]] = []
    integration_signals: list[dict[str, Any]] = []
    deployment: list[dict[str, Any]] = []
    test_files: list[str] = []
    architecture_signals: list[str] = []
    ui_markers = {"pages", "app", "routes", "screens", "views", "components"}
    api_patterns = [re.compile(r"\b(app|router)\.(get|post|put|patch|delete)\s*\("), re.compile(r"@(app|router)\.(get|post|put|patch|delete)\s*\("), re.compile(r"export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE)\b")]
    integration_tokens = ["stripe", "firebase", "supabase", "openai", "anthropic", "twilio", "sendgrid", "aws", "gcp", "azure", "postgres", "mysql", "mongodb", "redis", "salesforce", "hubspot", "slack", "whatsapp"]
    deployment_names = {"Dockerfile", "docker-compose.yml", "docker-compose.yaml", "vercel.json", "netlify.toml", "firebase.json", "cloudbuild.yaml", "app.yaml", "render.yaml", "railway.json", "fly.toml", "serverless.yml", "serverless.yaml"}
    for path in iter_repo_files(repo, DEFAULT_EXCLUDED_DIRS):
        rel = safe_rel(path, repo)
        lower = rel.lower()
        parts = set(p.lower() for p in Path(rel).parts)
        if any(part in ui_markers for part in parts) and path.suffix.lower() in {".tsx", ".jsx", ".vue", ".svelte", ".html", ".dart"}:
            ui.append({"path": rel, "route_or_screen": "TO_BE_VERIFIED", "status": "UNKNOWN", "evidence": []})
        if "test" in path.stem.lower() or "spec" in path.stem.lower() or any(p in {"tests", "test", "__tests__", "e2e"} for p in parts):
            test_files.append(rel)
        if path.name in deployment_names or any(p in {"terraform", "k8s", "kubernetes", ".github"} for p in parts):
            deployment.append({"path": rel, "kind": "deployment_or_infrastructure_signal", "status": "NOT_VERIFIED"})
        if any(token in lower for token in ["schema", "migration", "prisma", "model", "entity", "database", "db/"]):
            data.append({"path": rel, "kind": "data_or_migration_signal", "status": "NOT_VERIFIED"})
        if likely_text(path) and path.stat().st_size <= 2 * 1024 * 1024:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pattern in api_patterns:
                if pattern.search(text):
                    api.append({"path": rel, "method_and_route": "TO_BE_EXTRACTED", "authentication": "UNKNOWN", "status": "UNKNOWN", "evidence": []})
                    break
            found = sorted({token for token in integration_tokens if token in text.lower() or token in lower})
            for token in found:
                integration_signals.append({"provider_or_system": token, "source_path": rel, "configured": "UNKNOWN", "tested": "UNKNOWN", "live": "UNKNOWN"})
            if any(marker in text for marker in ["createRoot(", "NextResponse", "FastAPI(", "Flask(", "express(", "NestFactory", "SpringApplication.run", "WebApplication.CreateBuilder"]):
                architecture_signals.append(rel)
    def dedupe(items: list[dict[str, Any]], keys: tuple[str, ...]) -> list[dict[str, Any]]:
        seen = set(); out = []
        for item in items:
            marker = tuple(item.get(k) for k in keys)
            if marker not in seen:
                seen.add(marker); out.append(item)
        return out
    return {
        "ui": dedupe(ui, ("path",)),
        "api": dedupe(api, ("path",)),
        "data": dedupe(data, ("path",)),
        "integrations": dedupe(integration_signals, ("provider_or_system", "source_path")),
        "deployment": dedupe(deployment, ("path",)),
        "test_files": sorted(set(test_files)),
        "architecture_signals": sorted(set(architecture_signals)),
    }


def command_baseline(repo: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    commands, dependencies = parse_package_json(repo)
    makefile = repo / "Makefile"
    if makefile.exists():
        commands.append({"source": "Makefile", "name": "make targets", "command": "Inspect Makefile", "verified": False, "result": "NOT_RUN_BY_AUTOMATIC_CAPTURE"})
    common = []
    if (repo / "pyproject.toml").exists() or (repo / "requirements.txt").exists():
        common.extend([
            {"source": "heuristic", "name": "python tests", "command": "pytest", "verified": False, "result": "CANDIDATE_ONLY"},
            {"source": "heuristic", "name": "python module", "command": f"{sys.executable} -m pytest", "verified": False, "result": "CANDIDATE_ONLY"},
        ])
    commands.extend(common)
    return {
        "captured_at": utc_now(),
        "commands": commands,
        "instructions": "The investigator must execute safe relevant commands, record exact exit codes, and distinguish verified commands from candidates.",
    }, {
        "captured_at": utc_now(),
        "dependencies": dependencies,
        "license_analysis_complete": False,
        "vulnerability_analysis_complete": False,
        "notes": ["Automatic capture reads declarations only. The investigator must run project-appropriate authoritative tools when available."],
    }


def markdown_template(title: str, sections: list[tuple[str, str]]) -> str:
    lines = [f"# {title}", "", f"Generated by LAOS v{VERSION} at `{utc_now()}`.", "", "> Replace every `TO_BE_COMPLETED` marker with verified information or an explicit `UNKNOWN` entry with the reason and evidence boundary.", ""]
    for heading, body in sections:
        lines.extend([f"## {heading}", "", body, ""])
    return "\n".join(lines).rstrip() + "\n"


def initialise(repo: Path, working: Path, contract: dict[str, Any]) -> dict[str, Any]:
    if working.exists() and any(working.iterdir()):
        raise CaptureError(f"Working directory is not empty: {working}")
    working.mkdir(parents=True, exist_ok=True)
    (working / "Evidence").mkdir()
    snapshot = working / "Repository_Snapshot"
    append_log(working, "CAPTURE_INITIALISED", {"repo": str(repo), "contract": contract})
    identity = git_identity(repo)
    source = repository_manifest(repo, snapshot, contract)
    environment = detect_environment(repo)
    heuristics = heuristic_inventories(repo)
    commands, dependencies = command_baseline(repo)
    project_id = contract.get("project_id") or str(uuid.uuid4())
    capture_id = str(uuid.uuid4())
    manifest = {
        "schema_version": "1.0",
        "laos_version": VERSION,
        "pack_type": "APP_INTELLIGENCE_RETURN",
        "project_id": project_id,
        "capture_id": capture_id,
        "parent_capture_pack_id": contract.get("capture_pack_id"),
        "project_name": contract.get("project_name", repo.name),
        "repository_root_at_capture": str(repo.resolve()),
        "capture_started_at": utc_now(),
        "capture_completed_at": None,
        "completion_state": "IN_PROGRESS",
        "repository_content_fingerprint": source["repository_content_fingerprint"],
        "git_head_commit": identity.get("head_commit"),
        "git_dirty_at_capture": identity.get("is_dirty"),
        "requested_change_context": contract.get("requested_change_context", ""),
        "authoritative_files": REQUIRED_FILES,
        "known_limits": [],
        "required_next_action": "Complete the investigation records, evidence, and final validation.",
    }
    write_json(working / "APP_INTELLIGENCE_MANIFEST.json", manifest)
    write_json(working / "REPOSITORY_IDENTITY.json", identity)
    write_json(working / "SOURCE_MANIFEST.json", source)
    write_json(working / "ENVIRONMENT_MANIFEST.json", environment)
    write_json(working / "COMMAND_BASELINE.json", commands)
    write_json(working / "DEPENDENCY_AND_LICENSE_REPORT.json", dependencies)
    write_json(working / "UI_INVENTORY.json", {"schema_version": "1.0", "items": heuristics["ui"], "inventory_complete": False, "browser_verification_performed": False})
    write_json(working / "API_INVENTORY.json", {"schema_version": "1.0", "items": heuristics["api"], "inventory_complete": False})
    write_json(working / "DATA_AND_MIGRATION_MAP.json", {"schema_version": "1.0", "items": heuristics["data"], "migration_state": "UNKNOWN", "inventory_complete": False})
    write_json(working / "INTEGRATIONS_INVENTORY.json", {"schema_version": "1.0", "items": heuristics["integrations"], "inventory_complete": False})
    write_json(working / "DEPLOYMENT_TRUTH.json", {"schema_version": "1.0", "signals": heuristics["deployment"], "environments": [], "repository_matches_production": "UNKNOWN", "inventory_complete": False})
    write_json(working / "FEATURE_STATUS_MATRIX.json", {"schema_version": "1.0", "allowed_statuses": ["WORKING_AND_VERIFIED", "WORKING_BUT_NOT_RERUN", "PARTIAL", "BROKEN", "MISSING", "DUPLICATED", "DISCONNECTED", "SIMULATED", "DEAD_CODE", "UNKNOWN"], "features": [], "inventory_complete": False})
    write_json(working / "TEST_BASELINE.json", {"schema_version": "1.0", "discovered_test_files": heuristics["test_files"], "executions": [], "coverage": "NOT_MEASURED", "flaky_tests": [], "disabled_or_skipped_tests": [], "critical_untested_behaviour": [], "baseline_complete": False})
    write_json(working / "PRIOR_AGENT_CLAIMS.json", {"schema_version": "1.0", "claims": [], "reconciliation_complete": False})
    write_json(working / "KNOWN_ISSUES.json", {"schema_version": "1.0", "issues": [], "inventory_complete": False})
    write_json(working / "PROTECTED_AREAS.json", {"schema_version": "1.0", "areas": [], "working_behaviour_to_preserve": [], "inventory_complete": False})
    write_json(working / "ASSUMPTIONS_AND_UNKNOWNS.json", {"schema_version": "1.0", "assumptions": [], "unknowns": [], "access_limitations": [], "inventory_complete": False})
    write_json(working / "EVIDENCE_INDEX.json", {"schema_version": "1.0", "items": [], "index_complete": False})
    write_text(working / "PROJECT_EXECUTIVE_SUMMARY.md", markdown_template("Project Executive Summary", [
        ("What this application is", "TO_BE_COMPLETED"),
        ("Current practical condition", "TO_BE_COMPLETED"),
        ("What is working", "TO_BE_COMPLETED"),
        ("What is broken or uncertain", "TO_BE_COMPLETED"),
        ("Safest next move", "TO_BE_COMPLETED"),
    ]))
    write_text(working / "ARCHITECTURE_MAP.md", markdown_template("Architecture Map", [
        ("System overview", "TO_BE_COMPLETED"),
        ("Entry points and major components", "Automatic signals: " + ", ".join(heuristics["architecture_signals"][:50]) + "\n\nTO_BE_COMPLETED"),
        ("Data flow", "TO_BE_COMPLETED"),
        ("Frontend, backend and service boundaries", "TO_BE_COMPLETED"),
        ("Background jobs, queues and schedules", "TO_BE_COMPLETED"),
        ("Architecture risks or violations", "TO_BE_COMPLETED"),
    ]))
    write_text(working / "AUTHORIZATION_MAP.md", markdown_template("Authentication and Authorization Map", [
        ("Authentication method", "TO_BE_COMPLETED"),
        ("Roles and permissions", "TO_BE_COMPLETED"),
        ("Protected routes and backend enforcement", "TO_BE_COMPLETED"),
        ("Data isolation and tenant behaviour", "TO_BE_COMPLETED"),
        ("Known weaknesses", "TO_BE_COMPLETED"),
    ]))
    write_text(working / "RECOMMENDED_RESUME_PLAN.md", markdown_template("Recommended Safe Resume Plan", [
        ("Last known safe baseline", "TO_BE_COMPLETED"),
        ("First safe implementation task", "TO_BE_COMPLETED"),
        ("Required preservation checks", "TO_BE_COMPLETED"),
        ("Required regression tests", "TO_BE_COMPLETED"),
        ("Escalations or approvals", "TO_BE_COMPLETED"),
    ]))
    write_text(working / "RETURN_START_HERE.md", "# App Intelligence Return Pack\n\nRead `APP_INTELLIGENCE_MANIFEST.json` first, then repository identity, source manifest, executive summary, feature status, command/test baseline, deployment, integrations, protected areas, unknowns and resume plan. Facts are authoritative only where they cite direct evidence or exact command results. Reported or inferred facts must be labelled. Unknowns must remain explicit. This return pack describes a captured moment and does not authorize implementation.\n")
    write_json(working / "CAPTURE_CONTRACT.json", contract)
    append_log(working, "AUTOMATIC_INSPECTION_COMPLETED", {"source_file_count": source["file_count"], "fingerprint": source["repository_content_fingerprint"]})
    return {"working_directory": str(working), "project_id": project_id, "capture_id": capture_id, "repository_fingerprint": source["repository_content_fingerprint"]}


def append_log(working: Path, event: str, details: dict[str, Any]) -> None:
    path = working / "CAPTURE_LOG.jsonl"
    rec = {"timestamp": utc_now(), "event": event, "details": details}
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")


def evidence_index_from_directory(working: Path) -> dict[str, Any]:
    evidence_root = working / "Evidence"
    items = []
    if evidence_root.exists():
        for path in sorted(p for p in evidence_root.rglob("*") if p.is_file()):
            items.append({"path": safe_rel(path, working), "bytes": path.stat().st_size, "sha256": sha256_file(path), "kind": "investigation_evidence", "description": path.stem.replace("_", " ").replace("-", " ")})
    return {"schema_version": "1.0", "items": items, "index_complete": True}


def validate_working(working: Path, strict: bool = True) -> dict[str, Any]:
    issues: list[str] = []
    warnings: list[str] = []
    for rel in REQUIRED_FILES:
        path = working / rel
        if not path.is_file():
            issues.append(f"missing required file: {rel}")
            continue
        if path.stat().st_size == 0:
            issues.append(f"empty required file: {rel}")
        if rel.endswith(".json"):
            try:
                read_json(path)
            except CaptureError as exc:
                issues.append(str(exc))
    for rel, min_bytes in NARRATIVE_MIN_BYTES.items():
        path = working / rel
        if path.exists() and path.stat().st_size < min_bytes:
            issues.append(f"narrative file too small to be useful: {rel} ({path.stat().st_size} < {min_bytes})")
    for path in working.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".pdf", ".zip"}:
            continue
        if path.stat().st_size > 5 * 1024 * 1024:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        secret_hits = scan_text_for_secrets(text)
        if secret_hits:
            rel = safe_rel(path, working)
            # SOURCE_MANIFEST deliberately describes secret-pattern findings without values.
            if rel != "SOURCE_MANIFEST.json":
                issues.append(f"possible secret-like content in return pack: {rel}")
        if strict and "TO_BE_COMPLETED" in text:
            issues.append(f"unresolved TO_BE_COMPLETED marker: {safe_rel(path, working)}")
    manifest_path = working / "APP_INTELLIGENCE_MANIFEST.json"
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        state = manifest.get("completion_state")
        if state not in {"COMPLETE", "PARTIAL", "BLOCKED"}:
            issues.append("APP_INTELLIGENCE_MANIFEST.completion_state must be COMPLETE, PARTIAL or BLOCKED before finalization")
        if state in {"PARTIAL", "BLOCKED"} and not manifest.get("known_limits"):
            issues.append("PARTIAL or BLOCKED return packs must list known_limits")
    matrix = read_json(working / "FEATURE_STATUS_MATRIX.json", default={})
    if strict and not matrix.get("features"):
        issues.append("FEATURE_STATUS_MATRIX contains no features")
    if strict and not matrix.get("inventory_complete"):
        issues.append("FEATURE_STATUS_MATRIX.inventory_complete is not true")

    completion_flags = {
        "UI_INVENTORY.json": "inventory_complete",
        "API_INVENTORY.json": "inventory_complete",
        "DATA_AND_MIGRATION_MAP.json": "inventory_complete",
        "INTEGRATIONS_INVENTORY.json": "inventory_complete",
        "DEPLOYMENT_TRUTH.json": "inventory_complete",
        "KNOWN_ISSUES.json": "inventory_complete",
        "PROTECTED_AREAS.json": "inventory_complete",
        "ASSUMPTIONS_AND_UNKNOWNS.json": "inventory_complete",
        "TEST_BASELINE.json": "baseline_complete",
        "PRIOR_AGENT_CLAIMS.json": "reconciliation_complete",
    }
    if strict:
        for rel, flag in completion_flags.items():
            if not read_json(working / rel, default={}).get(flag):
                issues.append(f"{rel}.{flag} is not true")
        dep = read_json(working / "DEPENDENCY_AND_LICENSE_REPORT.json", default={})
        if not dep.get("license_analysis_complete"):
            issues.append("DEPENDENCY_AND_LICENSE_REPORT.license_analysis_complete is not true")
        if not dep.get("vulnerability_analysis_complete"):
            issues.append("DEPENDENCY_AND_LICENSE_REPORT.vulnerability_analysis_complete is not true")

    evidence_index = read_json(working / "EVIDENCE_INDEX.json", default={})
    evidence_items = evidence_index.get("items", [])
    if strict and not evidence_items:
        warnings.append("EVIDENCE_INDEX contains no evidence items; this is acceptable only for genuinely evidence-free static projects")
    seen_evidence: set[str] = set()
    for item in evidence_items:
        rel = str(item.get("path", ""))
        if not rel or rel in seen_evidence:
            issues.append(f"invalid or duplicate evidence index path: {rel!r}")
            continue
        seen_evidence.add(rel)
        path = working / rel
        try:
            resolved = path.resolve()
            if working.resolve() not in resolved.parents:
                issues.append(f"evidence path escapes return root: {rel}")
                continue
        except OSError:
            issues.append(f"invalid evidence path: {rel}")
            continue
        if not path.is_file():
            issues.append(f"evidence index path does not exist: {rel}")
            continue
        if item.get("bytes") != path.stat().st_size or item.get("sha256") != sha256_file(path):
            issues.append(f"stale evidence index metadata: {rel}")
        if not str(item.get("description", "")).strip():
            issues.append(f"evidence item has no description: {rel}")

    # Evidence references inside feature records must resolve to indexed or real files.
    for feature in matrix.get("features", []):
        for rel in feature.get("evidence", []):
            if isinstance(rel, dict):
                rel = rel.get("path", "")
            if rel and not (working / str(rel)).is_file():
                issues.append(f"feature {feature.get('id', feature.get('name', 'UNKNOWN'))} references missing evidence: {rel}")

    source = read_json(working / "SOURCE_MANIFEST.json", default={})
    snapshot_root = working / "Repository_Snapshot"
    for entry in source.get("entries", []):
        if entry.get("snapshot_included"):
            snap = snapshot_root / entry.get("path", "")
            if not snap.is_file():
                issues.append(f"source manifest snapshot file missing: {entry.get('path')}")
            elif entry.get("sha256") and sha256_file(snap) != entry.get("sha256"):
                issues.append(f"source snapshot hash mismatch: {entry.get('path')}")
    return {"status": "PASS" if not issues else "FAIL", "issues": sorted(set(issues)), "warnings": sorted(set(warnings)), "checked_at": utc_now()}


def safe_zip_check(path: Path) -> list[str]:
    issues = []
    with zipfile.ZipFile(path, "r") as zf:
        names = set()
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or ".." in Path(name).parts:
                issues.append(f"unsafe path: {name}")
            if "\\" in info.filename:
                issues.append(f"backslash path: {info.filename}")
            if name in names:
                issues.append(f"duplicate path: {name}")
            names.add(name)
    return issues


def content_manifest(root: Path, exclude: set[str] | None = None) -> dict[str, Any]:
    exclude = exclude or set()
    items = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = safe_rel(path, root)
        if rel in exclude:
            continue
        items.append({"path": rel, "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    digest = hashlib.sha256("\n".join(f"{i['path']}|{i['bytes']}|{i['sha256']}" for i in items).encode("utf-8")).hexdigest()
    return {"created_at": utc_now(), "file_count": len(items), "content_digest": digest, "files": items}


def finalize(repo: Path, working: Path, output: Path) -> dict[str, Any]:
    # Refresh evidence index and manifest completion timestamp before strict validation.
    write_json(working / "EVIDENCE_INDEX.json", evidence_index_from_directory(working))
    manifest = read_json(working / "APP_INTELLIGENCE_MANIFEST.json")
    manifest["capture_completed_at"] = utc_now()
    manifest["required_next_action"] = "Lead AI validates this return pack, then compiles a continuation, repair, feature or audit implementation pack."
    write_json(working / "APP_INTELLIGENCE_MANIFEST.json", manifest)
    contract = read_json(working / "CAPTURE_CONTRACT.json", default={})
    current = fingerprint(repo, contract)
    if current.get("repository_content_fingerprint") != manifest.get("repository_content_fingerprint"):
        raise CaptureError("Repository changed materially after capture initialization. Re-run capture init or reconcile the changes before finalization.")
    validation = validate_working(working, strict=True)
    write_json(working / "RETURN_PACK_VALIDATION.json", validation)
    if validation["status"] != "PASS":
        raise CaptureError("Return pack validation failed:\n- " + "\n- ".join(validation["issues"]))
    manifest_data = content_manifest(working, exclude={"RETURN_PACK_CONTENT_MANIFEST.json", "RETURN_PACK_FINALIZATION.json"})
    write_json(working / "RETURN_PACK_CONTENT_MANIFEST.json", manifest_data)
    finalization = {
        "laos_version": VERSION,
        "finalized_at": utc_now(),
        "repository_root": str(repo.resolve()),
        "project_id": manifest.get("project_id"),
        "capture_id": manifest.get("capture_id"),
        "repository_content_fingerprint": manifest.get("repository_content_fingerprint"),
        "content_digest": manifest_data["content_digest"],
        "status": "READY_TO_PACKAGE",
    }
    write_json(working / "RETURN_PACK_FINALIZATION.json", finalization)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(p for p in working.rglob("*") if p.is_file()):
            zf.write(path, safe_rel(path, working))
    zip_issues = safe_zip_check(output)
    with tempfile.TemporaryDirectory(prefix="laos_return_verify_") as tmp:
        extracted = Path(tmp)
        with zipfile.ZipFile(output, "r") as zf:
            zf.extractall(extracted)
        expected = {i["path"]: (i["bytes"], i["sha256"]) for i in content_manifest(working)["files"]}
        actual = {i["path"]: (i["bytes"], i["sha256"]) for i in content_manifest(extracted)["files"]}
        if expected != actual:
            zip_issues.append("extracted ZIP content differs from working directory")
    report = {
        "status": "PASS" if not zip_issues else "FAIL",
        "output": str(output.resolve()),
        "bytes": output.stat().st_size,
        "sha256": sha256_file(output),
        "entry_count": len(content_manifest(working)["files"]),
        "issues": zip_issues,
        "verified_at": utc_now(),
    }
    if zip_issues:
        raise CaptureError("Final ZIP verification failed: " + "; ".join(zip_issues))
    append_log(working, "RETURN_ZIP_FINALIZED", report)
    return report


def fingerprint(repo: Path, config: dict[str, Any]) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="laos_fingerprint_") as tmp:
        result = repository_manifest(repo, None, {**config, "include_safe_source_snapshot": False})
    identity = git_identity(repo)
    return {
        "captured_at": utc_now(),
        "repository_root": str(repo.resolve()),
        "repository_content_fingerprint": result["repository_content_fingerprint"],
        "file_count": result["file_count"],
        "git_head_commit": identity.get("head_commit"),
        "git_dirty": identity.get("is_dirty"),
    }


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="LAOS v7 existing-app capture runtime")
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="Create the App Intelligence working directory from a read-only repository inspection")
    init.add_argument("--repo", default=".")
    init.add_argument("--working", default="App_Intelligence_Working")
    init.add_argument("--contract", default="CAPTURE_CONTRACT.json")
    val = sub.add_parser("validate", help="Validate the completed working directory")
    val.add_argument("--working", default="App_Intelligence_Working")
    val.add_argument("--allow-placeholders", action="store_true")
    fin = sub.add_parser("finalize", help="Build and verify the one-file App Intelligence Return ZIP")
    fin.add_argument("--repo", default=".")
    fin.add_argument("--working", default="App_Intelligence_Working")
    fin.add_argument("--output", default="App_Intelligence_Return.zip")
    fp = sub.add_parser("fingerprint", help="Print a current repository fingerprint")
    fp.add_argument("--repo", default=".")
    fp.add_argument("--contract", default="CAPTURE_CONTRACT.json")
    return p


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "init":
            repo = Path(args.repo).resolve()
            contract_path = Path(args.contract).resolve()
            contract = read_json(contract_path, default={})
            working = Path(args.working)
            if not working.is_absolute():
                working = repo / working
            print(json.dumps(initialise(repo, working.resolve(), contract), indent=2)); return 0
        if args.command == "validate":
            result = validate_working(Path(args.working).resolve(), strict=not args.allow_placeholders)
            print(json.dumps(result, indent=2)); return 0 if result["status"] == "PASS" else 2
        if args.command == "finalize":
            result = finalize(Path(args.repo).resolve(), Path(args.working).resolve(), Path(args.output).resolve())
            print(json.dumps(result, indent=2)); return 0
        if args.command == "fingerprint":
            config = read_json(Path(args.contract).resolve(), default={})
            print(json.dumps(fingerprint(Path(args.repo).resolve(), config), indent=2)); return 0
        raise CaptureError(f"Unknown command {args.command}")
    except CaptureError as exc:
        print(f"LAOS CAPTURE ERROR: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("Capture interrupted. Existing working files were not deleted.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
