#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
cmd=[sys.executable,'-m','unittest','discover','-s',str(root/'tests'),'-p','test_laos_v7.py','-v']
raise SystemExit(subprocess.run(cmd,cwd=root).returncode)
