#!/usr/bin/env python3
"""Validate an extracted LAOS v7 master release without third-party dependencies."""
from __future__ import annotations
import argparse, json, py_compile, subprocess, sys, tempfile
from pathlib import Path

REQUIRED = [
    'README.md', 'START_HERE_FOR_NILHAN.md', 'HOW_TO_USE_LAOS_IN_PLAIN_ENGLISH.md',
    'WHAT_TO_UPLOAD_AND_WHEN.md', 'MASTER_ZIP_VS_PROJECT_PACK.md',
    'FOR_CHATGPT_PACK_COMPILER.md', 'docs/LAOS_v7_MASTER_GUIDE.md',
    'docs/TWO_MISSION_WORKFLOW.md', 'docs/APP_INTELLIGENCE_RETURN_STANDARD.md',
    'tools/compile_project_pack.py', 'tools/compile_capture_pack.py',
    'tools/capture_runtime.py', 'tools/validate_return_pack.py',
    'tools/compile_continuation_pack.py', 'laos_runtime.py',
    'schemas/project_blueprint.schema.json',
    'schemas/app_intelligence/app_intelligence_manifest.schema.json',
    'templates/requests/existing_app_capture_request.template.json',
    'templates/requests/continuation_request.template.json',
    'templates/product_definition/NEW_BUILD_DISCOVERY_WORKSHEET.md',
    'templates/checklists/APP_INTELLIGENCE_COMPLETION_CHECKLIST.md',
    'project_pack_assets/roles/capture_investigator.md',
    'project_pack_assets/skills/repository-capture/SKILL.md',
    'tests/test_laos_v7.py',
]


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument('--skip-tests', action='store_true')
    args=ap.parse_args(); root=args.root.resolve()
    result={'root':str(root),'missing':[],'invalid_json':[],'python_compile_errors':[],
            'new_build_smoke':None,'capture_smoke':None,'self_tests':None}
    result['missing']=[p for p in REQUIRED if not (root/p).is_file()]
    for p in root.rglob('*.json'):
        if 'legacy' in p.parts or '__pycache__' in p.parts or 'release_evidence' in p.parts:
            continue
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: result['invalid_json'].append({'path':str(p.relative_to(root)),'error':str(e)})
    for p in root.rglob('*.py'):
        if 'legacy' in p.parts or '__pycache__' in p.parts:
            continue
        try: py_compile.compile(str(p), doraise=True)
        except Exception as e: result['python_compile_errors'].append({'path':str(p.relative_to(root)),'error':str(e)})
    with tempfile.TemporaryDirectory(prefix='laos_v7_master_validate_') as td:
        td=Path(td)
        out=td/'compiled'
        cp=subprocess.run([sys.executable,str(root/'tools/compile_project_pack.py'),str(root/'examples/project_blueprint.example.json'),str(out)],text=True,capture_output=True,timeout=90)
        if cp.returncode==0:
            doc=subprocess.run([sys.executable,str(out/'.laos/runtime/laos.py'),'--root',str(out),'doctor'],text=True,capture_output=True,timeout=30)
            audit=json.loads((out/'PACK_COMPILATION_AUDIT.json').read_text())
            result['new_build_smoke']={'compiler_exit':0,'doctor_exit':doc.returncode,'audit_status':audit.get('status')}
        else:
            result['new_build_smoke']={'compiler_exit':cp.returncode,'stderr':cp.stderr[-4000:]}
        capture_request=td/'capture_request.json'
        capture_request.write_text(json.dumps({'project_name':'Validation Existing App','include_safe_source_snapshot':True}),encoding='utf-8')
        capture_out=td/'capture_pack'
        cap=subprocess.run([sys.executable,str(root/'tools/compile_capture_pack.py'),str(capture_request),str(capture_out)],text=True,capture_output=True,timeout=60)
        result['capture_smoke']={'compiler_exit':cap.returncode,'start_file':(capture_out/'CAPTURE_START_HERE.md').is_file(),'runtime':(capture_out/'capture_runtime.py').is_file()}
    if not args.skip_tests:
        cp=subprocess.run([sys.executable,'-m','unittest','-v','tests.test_laos_v7'],cwd=root,text=True,capture_output=True,timeout=240)
        result['self_tests']={'exit':cp.returncode,'tail':(cp.stdout+'\n'+cp.stderr)[-10000:]}
    smoke=result['new_build_smoke'] or {}; cap=result['capture_smoke'] or {}
    ok=(not result['missing'] and not result['invalid_json'] and not result['python_compile_errors']
        and smoke.get('compiler_exit')==0 and smoke.get('doctor_exit')==0 and smoke.get('audit_status')=='PASS'
        and cap.get('compiler_exit')==0 and cap.get('start_file') and cap.get('runtime')
        and (args.skip_tests or result['self_tests'].get('exit')==0))
    result['status']='PASS' if ok else 'FAIL'
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return 0 if ok else 1

if __name__=='__main__':
    raise SystemExit(main())
