#!/usr/bin/env python3
"""Validate a LAOS v7 App Intelligence Return ZIP before a lead AI relies on it."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, shutil, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CAPTURE_RUNTIME = ROOT / "tools" / "capture_runtime.py"
spec = importlib.util.spec_from_file_location("capture_runtime", CAPTURE_RUNTIME)
cap = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(cap)

def safe_extract(zf: zipfile.ZipFile, destination: Path) -> None:
    infos = zf.infolist()
    if len(infos) > 100000:
        raise RuntimeError(f"Return ZIP has too many entries: {len(infos)}")
    total_uncompressed = sum(i.file_size for i in infos)
    if total_uncompressed > 2 * 1024 * 1024 * 1024:
        raise RuntimeError(f"Return ZIP uncompressed size is too large: {total_uncompressed}")
    names: set[str] = set()
    for info in infos:
        name = info.filename.replace("\\", "/")
        if name.startswith("/") or ".." in Path(name).parts or "\\" in info.filename:
            raise RuntimeError(f"Unsafe ZIP entry: {info.filename}")
        if name in names:
            raise RuntimeError(f"Duplicate ZIP entry: {name}")
        names.add(name)
        # Unix symlink bits are not allowed in a portable return pack.
        if ((info.external_attr >> 16) & 0o170000) == 0o120000:
            raise RuntimeError(f"Symlink ZIP entry is not allowed: {name}")
        if info.compress_size and info.file_size / max(info.compress_size, 1) > 10000 and info.file_size > 10 * 1024 * 1024:
            raise RuntimeError(f"Suspicious compression ratio for ZIP entry: {name}")
        target = (destination / name).resolve()
        if destination.resolve() not in target.parents and target != destination.resolve():
            raise RuntimeError(f"ZIP path escapes destination: {info.filename}")
    zf.extractall(destination)

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def validate(zip_path: Path) -> dict:
    issues=[]; warnings=[]
    if not zip_path.is_file():
        return {"status":"FAIL","issues":[f"file does not exist: {zip_path}"]}
    try:
        with tempfile.TemporaryDirectory(prefix="laos_return_validate_") as tmp:
            extracted=Path(tmp)
            with zipfile.ZipFile(zip_path,'r') as zf:
                safe_extract(zf, extracted)
            validation=cap.validate_working(extracted, strict=True)
            issues.extend(validation["issues"]); warnings.extend(validation["warnings"])
            manifest_path=extracted/"RETURN_PACK_CONTENT_MANIFEST.json"
            if not manifest_path.exists():
                issues.append("RETURN_PACK_CONTENT_MANIFEST.json is missing")
            else:
                recorded=cap.read_json(manifest_path)
                actual=cap.content_manifest(extracted, exclude={"RETURN_PACK_CONTENT_MANIFEST.json", "RETURN_PACK_FINALIZATION.json", "CAPTURE_LOG.jsonl"})
                # The finalization record and log can change after manifest generation; all other files must match.
                rec_map={i["path"]:(i["bytes"],i["sha256"]) for i in recorded.get("files",[]) if i.get("path") != "CAPTURE_LOG.jsonl"}
                act_map={i["path"]:(i["bytes"],i["sha256"]) for i in actual.get("files",[])}
                if rec_map != act_map:
                    missing=sorted(set(rec_map)-set(act_map)); extra=sorted(set(act_map)-set(rec_map)); changed=sorted(k for k in set(rec_map)&set(act_map) if rec_map[k]!=act_map[k])
                    if missing: issues.append("content manifest missing actual files: " + ", ".join(missing[:20]))
                    if extra: issues.append("unmanifested files in return pack: " + ", ".join(extra[:20]))
                    if changed: issues.append("manifest hash/size mismatch: " + ", ".join(changed[:20]))
            manifest=cap.read_json(extracted/"APP_INTELLIGENCE_MANIFEST.json", default={})
            source=cap.read_json(extracted/"SOURCE_MANIFEST.json", default={})
            if manifest.get("repository_content_fingerprint") != source.get("repository_content_fingerprint"):
                issues.append("repository fingerprint differs between manifest and source manifest")
            report={
                "status":"PASS" if not issues else "FAIL",
                "zip":str(zip_path.resolve()),
                "zip_bytes":zip_path.stat().st_size,
                "zip_sha256":sha(zip_path),
                "project_id":manifest.get("project_id"),
                "capture_id":manifest.get("capture_id"),
                "project_name":manifest.get("project_name"),
                "completion_state":manifest.get("completion_state"),
                "repository_content_fingerprint":manifest.get("repository_content_fingerprint"),
                "git_head_commit":manifest.get("git_head_commit"),
                "issues":sorted(set(issues)),
                "warnings":sorted(set(warnings)),
            }
            return report
    except Exception as exc:
        return {"status":"FAIL","zip":str(zip_path.resolve()),"issues":[str(exc)],"warnings":[]}

def main() -> int:
    p=argparse.ArgumentParser(description="Validate a LAOS v7 App Intelligence Return ZIP")
    p.add_argument("return_zip")
    p.add_argument("--report")
    args=p.parse_args()
    result=validate(Path(args.return_zip).resolve())
    text=json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)
    print(text)
    if args.report: Path(args.report).write_text(text+"\n",encoding="utf-8")
    return 0 if result["status"]=="PASS" else 2

if __name__=="__main__": raise SystemExit(main())
