#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
raise SystemExit(subprocess.call([sys.executable,'-B','-m','unittest','discover','-s',str(root/'tests'),'-p','test_*.py','-v'],cwd=root))
