#!/usr/bin/env python3
"""Compile a project-specific LAOS v7 implementation pack from an approved blueprint JSON."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import uuid
from pathlib import Path
from typing import Any

VERSION = "7.0.0"
ENGAGEMENT_MODES = {
    "new_project",
    "existing_project_feature",
    "existing_project_takeover",
    "repair_and_recovery",
    "audit_only",
    "deployment_only",
}
EXISTING_PROJECT_MODES = ENGAGEMENT_MODES - {"new_project"}
PACK_PURPOSES = {
    "new_build_implementation",
    "existing_project_continuation",
    "repair_implementation",
    "audit_execution",
    "deployment_execution",
}
DISCOVERY_KINDS = {"repository_reconciliation", "discovery", "audit", "capture"}


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def canon(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path: Path, obj: Any) -> None:
    write(path, json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True) + "\n")


def fail(msg: str) -> None:
    raise SystemExit(f"BLUEPRINT ERROR: {msg}")


def md_list(items: list[Any], empty: str = "None") -> str:
    if not items:
        return f"- {empty}\n"
    out: list[str] = []
    for item in items:
        if isinstance(item, dict):
            label = item.get("id", "")
            body = item.get("text") or item.get("description") or item.get("name") or json.dumps(item, ensure_ascii=False)
            out.append(f"- `{label}` {body}" if label else f"- {body}")
        else:
            out.append(f"- {item}")
    return "\n".join(out) + "\n"


def table_rows(items: list[Any], columns: list[tuple[str, str]], empty: str = "No verified entries yet.") -> str:
    header = "| " + " | ".join(title for title, _ in columns) + " |\n"
    divider = "|" + "|".join("---" for _ in columns) + "|\n"
    if not items:
        return header + divider + "| " + " | ".join([empty] + [""] * (len(columns) - 1)) + " |\n"
    rows = []
    for item in items:
        if not isinstance(item, dict):
            item = {columns[0][1]: str(item)}
        vals = [str(item.get(key, "")).replace("\n", " ") for _, key in columns]
        rows.append("| " + " | ".join(vals) + " |")
    return header + divider + "\n".join(rows) + "\n"


def reconciliation_task() -> dict[str, Any]:
    return {
        "id": "TASK-000",
        "kind": "repository_reconciliation",
        "title": "Reconcile current repository and establish the safe implementation baseline",
        "description": (
            "Before changing product code, verify the actual repository root, Git state, architecture, commands, "
            "tests, current features, prior-agent claims, deployment, external systems, risks, protected areas, "
            "and exact next safe action. Resolve material discovery markers through evidence or propose an amendment/escalation."
        ),
        "priority": 0,
        "dependencies": [],
        "requirements": [],
        "allowed_paths": [
            "Evidence/**",
            "PROJECT_ENTRY_CONTEXT.md",
            "REPOSITORY_BASELINE.md",
            "EXISTING_WORK_INVENTORY.md",
            "SPEC_RECONCILIATION.md",
            "CHANGE_BOUNDARY.md",
            "DEPLOYMENT_STATE.md",
            "PRIOR_WORK_HANDOFF.md",
            "TECHNICAL_DEBT_AND_KNOWN_ISSUES.md",
            "ASSUMPTIONS_AND_UNKNOWNS.md",
            "MID_BUILD_RESUME_PLAN.md",
            "ARCHITECTURE.md",
            "COMMANDS.md",
            "DECISIONS.md",
            "OPEN_RISKS.md",
            "INTEGRATIONS.md",
            "RUN_STATE.md",
            "NEXT_ACTIONS.md",
            "spec/amendments/**",
        ],
        "forbidden_paths": [
            ".git/**",
            ".laos/runtime/**",
            "src/**",
            "app/**",
            "server/**",
            "backend/**",
            "frontend/**",
        ],
        "no_code_change": True,
        "acceptance_criteria": [
            "The actual repository root, branch, full commit, dirty state, untracked files, and uncommitted work are recorded.",
            "Current entry points, architecture, data flows, and relevant conventions are documented from direct inspection.",
            "Install, build, test, lint, type-check, run, and smoke-test commands are verified where available, with exact boundaries where unavailable.",
            "Working, partial, broken, missing, duplicated, and unverified behavior relevant to the approved scope is mapped.",
            "Previous-agent claims are classified against current evidence rather than accepted as narrative truth.",
            "Deployment and external-system state, permissions, side effects, and rollback boundaries are recorded.",
            "Protected areas, existing behavior to preserve, technical debt, risks, assumptions, and unresolved questions are explicit.",
            "Material discovery markers affecting implementation are resolved or a proposed amendment/escalation is created before product-code work begins.",
            "The exact next safe task and resume action are unambiguous.",
            "No product code is changed during repository reconciliation.",
        ],
        "checks": [
            {
                "id": "CHECK-TASK-000-DOCTOR",
                "command": "python .laos/runtime/laos.py doctor",
                "stage": "TESTED",
                "required": True,
                "evidence_path": "Evidence/TASK-000/checks/CHECK-TASK-000-DOCTOR.txt",
            }
        ],
        "evidence_required": [
            {"path": "Evidence/TASK-000/context_intake.md", "stage": "IMPLEMENTED", "min_bytes": 80},
            {"path": "Evidence/TASK-000/repository_reconciliation.md", "stage": "EVIDENCED", "min_bytes": 120},
            {"path": "Evidence/TASK-000/baseline_test_results.md", "stage": "EVIDENCED", "min_bytes": 80},
            {"path": "Evidence/TASK-000/spec_vs_repo_reconciliation.md", "stage": "EVIDENCED", "min_bytes": 80},
            {"path": "Evidence/TASK-000/review.md", "stage": "REVIEWED", "min_bytes": 40},
        ],
        "review_required": True,
        "side_effects_required": [],
        "stop_conditions": [
            "Repository root or Git truth cannot be established",
            "Current source contradicts the approved scope in a material way",
            "A required destructive or external action lacks authorization",
            "Material executable commands remain unresolved",
            "Current project state cannot be preserved safely",
        ],
    }


def normalize(bp: dict[str, Any]) -> dict[str, Any]:
    for key in ("project_name", "project_summary", "requirements", "tasks"):
        if key not in bp:
            fail(f"missing required field {key}")
    if not isinstance(bp["requirements"], list) or not bp["requirements"]:
        fail("requirements must be a non-empty list")
    if not isinstance(bp["tasks"], list) or not bp["tasks"]:
        fail("tasks must be a non-empty list")

    bp.setdefault("engagement_mode", "existing_project_feature")
    if bp["engagement_mode"] not in ENGAGEMENT_MODES:
        fail(f"engagement_mode must be one of {sorted(ENGAGEMENT_MODES)}")
    bp.setdefault("project_root", "<DISCOVER_CURRENT_REPO_ROOT>")
    bp.setdefault("target_agent", "generic-desktop-agent")
    bp.setdefault("operating_system", "auto-detect")
    bp.setdefault("stack", [])
    bp.setdefault("non_goals", [])
    bp.setdefault("architecture", [])
    bp.setdefault("commands", [])
    bp.setdefault("permissions", ["READ_REPO", "WRITE_APPROVED_PATHS", "RUN_LOCAL_COMMANDS"])
    bp.setdefault("integrations", [])
    bp.setdefault("decisions", [])
    bp.setdefault("risks", [])
    bp.setdefault("current_repo_state", "Not yet reconciled by the implementation agent.")
    bp.setdefault("source_discussion_summary", bp["project_summary"])
    bp.setdefault("evidence_level", 3)
    bp.setdefault("spec_version", "1.0.0")
    default_purpose = {
        "new_project": "new_build_implementation",
        "existing_project_feature": "existing_project_continuation",
        "existing_project_takeover": "existing_project_continuation",
        "repair_and_recovery": "repair_implementation",
        "audit_only": "audit_execution",
        "deployment_only": "deployment_execution",
    }[bp["engagement_mode"]]
    bp.setdefault("pack_purpose", default_purpose)
    if bp["pack_purpose"] not in PACK_PURPOSES:
        fail(f"pack_purpose must be one of {sorted(PACK_PURPOSES)}")
    bp.setdefault("allow_discovery_markers", False)
    bp.setdefault("project_definition", {})
    bp.setdefault("user_roles", [])
    bp.setdefault("permission_matrix", [])
    bp.setdefault("user_journeys", [])
    bp.setdefault("data_model", [])
    bp.setdefault("security_requirements", [])
    bp.setdefault("privacy_and_retention", [])
    bp.setdefault("ui_contract", {})
    bp.setdefault("quality_budgets", {})
    bp.setdefault("operational_requirements", [])
    bp.setdefault("architecture_decisions", [])
    bp.setdefault("deployment_contract", {})
    bp.setdefault("acceptance_model", {})
    bp.setdefault("provenance", {})
    bp.setdefault("expected_repository_fingerprint", None)
    bp.setdefault("expected_git_commit", None)
    bp.setdefault("preservation_contract", [])
    bp.setdefault("regression_contract", [])
    bp.setdefault("risk_level", "MODERATE")
    bp.setdefault("model_profile", {"target": bp.get("target_agent", "generic-desktop-agent"), "task_granularity": "bounded_vertical_slice", "checkpoint_frequency": "after_each_meaningful_substep"})
    bp.setdefault("repository_intake_complete", False)
    bp.setdefault("include_reconciliation_task", bp["engagement_mode"] in EXISTING_PROJECT_MODES)
    ctx = bp.setdefault("existing_project_context", {})
    for key, default in {
        "repository_access": "Not yet recorded.",
        "known_repo_state": [],
        "prior_agent_claims": [],
        "known_working_behavior": [],
        "known_partial_or_broken_behavior": [],
        "known_commands": [],
        "known_test_baseline": [],
        "deployment_state": [],
        "external_systems": [],
        "protected_areas": [],
        "technical_debt": [],
        "unresolved_questions": [],
        "source_materials": [],
    }.items():
        ctx.setdefault(key, default)

    req_ids: set[str] = set()
    for i, req in enumerate(bp["requirements"], 1):
        if not req.get("text"):
            fail(f"requirement {i} has no text")
        req.setdefault("id", f"REQ-{i:03d}")
        req.setdefault("priority", "MUST")
        req.setdefault("acceptance", [])
        req.setdefault("source", "approved project discussion")
        if req["id"] in req_ids:
            fail(f"duplicate ID {req['id']}")
        req_ids.add(req["id"])

    for i, inv in enumerate(bp.get("invariants", []), 1):
        inv.setdefault("id", f"INV-{i:03d}")
        if not inv.get("text"):
            fail(f"invariant {i} has no text")

    tasks = [dict(t) for t in bp["tasks"]]
    has_reconciliation = any(t.get("id") == "TASK-000" or t.get("kind") == "repository_reconciliation" for t in tasks)
    should_insert = (
        bp["engagement_mode"] in EXISTING_PROJECT_MODES
        and bool(bp.get("include_reconciliation_task", True))
        and not bool(bp.get("repository_intake_complete", False))
        and not has_reconciliation
    )
    if should_insert:
        rec = reconciliation_task()
        for task in tasks:
            deps = list(task.get("dependencies", []))
            if not deps:
                deps = ["TASK-000"]
            task["dependencies"] = deps
            task["priority"] = int(task.get("priority", 1)) + 1
        tasks.insert(0, rec)
    bp["tasks"] = tasks

    task_ids: list[str] = []
    for i, task in enumerate(bp["tasks"], 1):
        for key in ("title", "description", "acceptance_criteria"):
            if not task.get(key):
                fail(f"task {i} missing {key}")
        task.setdefault("id", f"TASK-{i:03d}")
        task.setdefault("kind", "implementation")
        task.setdefault("priority", i)
        task.setdefault("dependencies", [])
        task.setdefault("requirements", [])
        task.setdefault("allowed_paths", ["**"])
        task.setdefault("forbidden_paths", [".git/**", ".laos/runtime/**", "spec/**"])
        task.setdefault("checks", [])
        task.setdefault(
            "evidence_required",
            [
                {"path": f"Evidence/{task['id']}/plan_contract.md", "stage": "IMPLEMENTED", "min_bytes": 20},
                {"path": f"Evidence/{task['id']}/test_results.md", "stage": "EVIDENCED", "min_bytes": 20},
                {"path": f"Evidence/{task['id']}/claim_to_evidence.md", "stage": "EVIDENCED", "min_bytes": 20},
                {"path": f"Evidence/{task['id']}/review.md", "stage": "REVIEWED", "min_bytes": 20},
            ],
        )
        task.setdefault("review_required", True)
        task.setdefault("review_level", "INDEPENDENT_FRESH_CONTEXT" if bp.get("risk_level") in {"HIGH", "CRITICAL"} else "FRESH_CONTEXT")
        task.setdefault("allow_test_changes", False)
        task.setdefault("required_permissions", [])
        task.setdefault("timeout_seconds", 1800)
        task.setdefault("preserve", bp.get("preservation_contract", []))
        task.setdefault("regression_checks", bp.get("regression_contract", []))
        task.setdefault("side_effects_required", [])
        task.setdefault(
            "stop_conditions",
            ["Any global LAOS stop condition", "Required tests or evidence fail", "Scope or specification contradiction"],
        )
        if task["id"] in task_ids:
            fail(f"duplicate task id {task['id']}")
        task_ids.append(task["id"])

    valid_task = set(task_ids)
    for task in bp["tasks"]:
        unknown_req = set(task["requirements"]) - req_ids
        if unknown_req:
            fail(f"{task['id']} references unknown requirements {sorted(unknown_req)}")
        unknown_dep = set(task["dependencies"]) - valid_task
        if unknown_dep:
            fail(f"{task['id']} references unknown dependencies {sorted(unknown_dep)}")
        if task["id"] in task["dependencies"]:
            fail(f"{task['id']} depends on itself")
        for c_i, check in enumerate(task["checks"], 1):
            check.setdefault("id", f"CHECK-{task['id']}-{c_i:02d}")
            check.setdefault("stage", "TESTED")
            check.setdefault("required", True)
            check.setdefault("evidence_path", f"Evidence/{task['id']}/checks/{check['id']}.txt")
            if not check.get("command"):
                fail(f"{task['id']} check {c_i} has no command")
    return bp



def _walk_strings(value: Any, path: str = "") -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    if isinstance(value, str):
        found.append((path, value))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            found.extend(_walk_strings(item, f"{path}[{i}]"))
    elif isinstance(value, dict):
        for key, item in value.items():
            found.extend(_walk_strings(item, f"{path}.{key}" if path else str(key)))
    return found


def compilation_audit(bp: dict[str, Any]) -> dict[str, Any]:
    """Perform deterministic completeness and traceability checks before pack creation."""
    errors: list[str] = []
    warnings: list[str] = []
    reqs = {r["id"]: r for r in bp["requirements"]}
    tasks = {t["id"]: t for t in bp["tasks"]}
    coverage: dict[str, list[str]] = {rid: [] for rid in reqs}
    for task in bp["tasks"]:
        for rid in task.get("requirements", []):
            coverage.setdefault(rid, []).append(task["id"])
    for rid, req in reqs.items():
        if req.get("priority", "MUST") == "MUST" and not coverage.get(rid):
            errors.append(f"MUST requirement {rid} is not linked to any task")
        if req.get("priority", "MUST") == "MUST" and not req.get("acceptance"):
            errors.append(f"MUST requirement {rid} has no observable acceptance conditions")

    visiting: set[str] = set(); visited: set[str] = set()
    def visit(task_id: str, chain: list[str]) -> None:
        if task_id in visiting:
            errors.append("Task dependency cycle: " + " -> ".join(chain + [task_id]))
            return
        if task_id in visited:
            return
        visiting.add(task_id)
        for dep in tasks[task_id].get("dependencies", []):
            visit(dep, chain + [task_id])
        visiting.remove(task_id); visited.add(task_id)
    for task_id in tasks:
        visit(task_id, [])

    check_ids: set[str] = set(); evidence_paths: set[str] = set()
    for task in bp["tasks"]:
        if task.get("kind") not in DISCOVERY_KINDS and not task.get("checks"):
            errors.append(f"{task['id']} is substantive but has no executable checks")
        if task.get("review_required") and not any(e.get("stage") == "REVIEWED" for e in task.get("evidence_required", [])):
            errors.append(f"{task['id']} requires review but has no REVIEWED-stage evidence")
        for check in task.get("checks", []):
            cid = check["id"]
            if cid in check_ids:
                errors.append(f"Duplicate check ID {cid}")
            check_ids.add(cid)
        for evidence in task.get("evidence_required", []):
            ep = evidence.get("path", "")
            if not ep:
                errors.append(f"{task['id']} contains an evidence requirement without a path")
            elif ep in evidence_paths:
                errors.append(f"Duplicate evidence path {ep}")
            evidence_paths.add(ep)
        if task.get("no_code_change") and any(p in {"**", "src/**", "app/**", "backend/**", "frontend/**"} for p in task.get("allowed_paths", [])):
            errors.append(f"{task['id']} is marked no_code_change but has broad product-code access")
        if bp.get("risk_level") in {"HIGH", "CRITICAL"} and task.get("kind") not in DISCOVERY_KINDS and task.get("review_level") != "INDEPENDENT_FRESH_CONTEXT":
            errors.append(f"{task['id']} is high-risk but lacks independent fresh-context review")
        if task.get("allowed_paths") == ["**"]:
            warnings.append(f"{task['id']} permits the whole repository; narrow this where practical")

    marker_tokens = ("TO_BE_COMPLETED", "<REPLACE", "<REAL_", "<APPROVED_", "<FEATURE_", "<OBSERVABLE_", "<NARROW_", "<VERIFIED_", "<PROJECT_")
    if not bp.get("allow_discovery_markers"):
        for path, text in _walk_strings(bp):
            if path == "project_root" or path.startswith("existing_project_context.repository_access"):
                continue
            if any(token in text for token in marker_tokens):
                errors.append(f"Unresolved compilation marker at {path}: {text[:120]}")

    if bp["engagement_mode"] == "new_project":
        if not bp.get("project_definition"):
            errors.append("New-build pack requires project_definition")
        if not bp.get("user_journeys"):
            errors.append("New-build pack requires at least one user journey")
        if not bp.get("acceptance_model"):
            errors.append("New-build pack requires an explicit acceptance_model")
        if not bp.get("deployment_contract"):
            warnings.append("New-build pack has no deployment_contract; mark deployment explicitly out of scope if intentional")

    if bp.get("pack_purpose") == "existing_project_continuation":
        if not bp.get("expected_repository_fingerprint"):
            errors.append("Continuation pack requires expected_repository_fingerprint from validated App Intelligence")
        if not bp.get("provenance", {}).get("capture_id"):
            errors.append("Continuation pack requires capture provenance")

    report = {
        "laos_version": VERSION,
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "warnings": warnings,
        "requirement_task_coverage": coverage,
        "counts": {
            "requirements": len(reqs), "tasks": len(tasks), "checks": len(check_ids),
            "evidence_requirements": len(evidence_paths), "warnings": len(warnings), "errors": len(errors),
        },
    }
    if errors:
        fail("compilation audit failed:\n- " + "\n- ".join(errors))
    return report

def build_midproject_files(bp: dict[str, Any], out: Path) -> None:
    ctx = bp["existing_project_context"]
    mode = bp["engagement_mode"]
    write(
        out / "PROJECT_ENTRY_CONTEXT.md",
        f"""# PROJECT ENTRY CONTEXT\n\n## Engagement mode\n`{mode}`\n\n## Approved objective\n{bp['project_summary']}\n\n## Repository access\n{ctx['repository_access']}\n\n## Source materials\n{md_list(ctx['source_materials'], 'No source materials recorded yet.')}\n## Intake status\n- Repository intake already complete: `{bool(bp.get('repository_intake_complete'))}`\n- Reconciliation task included: `{any(t.get('id') == 'TASK-000' for t in bp['tasks'])}`\n\nFor existing-project modes, current repository and reproducible behavior outrank old narrative.\n""",
    )
    write(
        out / "REPOSITORY_BASELINE.md",
        "# REPOSITORY BASELINE\n\n## Blueprint-known repository state\n"
        + md_list(ctx["known_repo_state"], "Not yet verified.")
        + "\n## Known commands\n"
        + md_list(ctx["known_commands"], "Not yet verified.")
        + "\n## Known test baseline\n"
        + md_list(ctx["known_test_baseline"], "Not yet verified.\n")
        + "\n## Required reconciliation\nRecord the actual root, branch, full commit, dirty state, untracked files, uncommitted work, entry points, architecture, and exact command results.\n",
    )
    write(
        out / "EXISTING_WORK_INVENTORY.md",
        "# EXISTING WORK INVENTORY\n\n## Verified or reported working behavior\n"
        + md_list(ctx["known_working_behavior"], "Not yet classified.")
        + "\n## Partial, broken, or uncertain behavior\n"
        + md_list(ctx["known_partial_or_broken_behavior"], "Not yet classified.")
        + "\nClassify each material area as VERIFIED_CURRENT, PARTIAL, BROKEN, MISSING, DUPLICATED, or UNVERIFIED and cite current evidence.\n",
    )
    write(
        out / "SPEC_RECONCILIATION.md",
        "# SPECIFICATION VS REPOSITORY RECONCILIATION\n\n"
        "| Requirement | Current repository status | Evidence | Disposition |\n"
        "|---|---|---|---|\n"
        + "\n".join(f"| {r['id']} | UNVERIFIED | Not yet recorded | Map during reconciliation |" for r in bp["requirements"])
        + "\n\nThe builder may not rewrite requirements to match the repository. Material contradictions require an amendment or escalation.\n",
    )
    write(
        out / "CHANGE_BOUNDARY.md",
        "# CHANGE BOUNDARY\n\n## Protected areas and systems\n"
        + md_list(ctx["protected_areas"], "No protected areas recorded yet; this is not permission to change everything.")
        + "\n## Existing behavior to preserve\n"
        + md_list(ctx["known_working_behavior"], "Identify and test relevant preservation behavior before implementation.")
        + "\n## Non-goals\n"
        + md_list(bp["non_goals"], "None declared.")
        + "\nTask-specific allowed and forbidden paths remain authoritative.\n",
    )
    write(
        out / "DEPLOYMENT_STATE.md",
        "# DEPLOYMENT AND EXTERNAL SYSTEM STATE\n\n## Deployment state\n"
        + md_list(ctx["deployment_state"], "Not yet verified.")
        + "\n## External systems\n"
        + md_list(ctx["external_systems"], "Not yet inventoried.")
        + "\nNo deployment or external write may be claimed from a plan or command alone. Record external verification, authorization, idempotency, and rollback.\n",
    )
    write(
        out / "PRIOR_WORK_HANDOFF.md",
        "# PRIOR WORK AND AGENT HANDOFF RECONCILIATION\n\n## Prior claims\n"
        + md_list(ctx["prior_agent_claims"], "No prior claims supplied.")
        + "\nClassify each important claim as VERIFIED_CURRENT, SUPPORTED_BUT_NOT_RERUN, STALE_OR_SUPERSEDED, CONTRADICTED, or UNVERIFIED.\n",
    )
    write(
        out / "TECHNICAL_DEBT_AND_KNOWN_ISSUES.md",
        "# TECHNICAL DEBT AND KNOWN ISSUES\n\n"
        + md_list(ctx["technical_debt"], "No debt recorded yet; inspect before assuming none exists.")
        + "\nDo not broaden the approved scope merely because unrelated debt is discovered. Record it and classify its effect on the current work.\n",
    )
    write(
        out / "ASSUMPTIONS_AND_UNKNOWNS.md",
        "# ASSUMPTIONS AND UNKNOWNS\n\n"
        + md_list(ctx["unresolved_questions"], "No unresolved questions recorded yet.")
        + "\nUnknowns must be discovered, amended, authorized, or escalated. They must not be converted into invented facts.\n",
    )
    write(
        out / "MID_BUILD_RESUME_PLAN.md",
        "# MID-BUILD RESUME PLAN\n\n"
        "This file is continuously updated at safe checkpoints and handoffs.\n\n"
        "## Current safe state\nNot yet established.\n\n"
        "## Current legal task\nRun `python .laos/runtime/laos.py refresh` and `python .laos/runtime/laos.py next`.\n\n"
        "## Failed approaches not to repeat\nNone recorded yet.\n\n"
        "## Side effects already executed\nSee `.laos/state/side_effect_journal.jsonl`.\n\n"
        "## Exact resume action\nRun `python .laos/runtime/laos.py doctor`, compare this file with current Git and machine state, then continue only the legal task.\n",
    )


def build_files(bp: dict[str, Any], out: Path, dist: Path) -> None:
    pack_id = str(uuid.uuid4())
    created = now()
    out.mkdir(parents=True, exist_ok=False)
    audit = compilation_audit(bp)
    save(out / "PACK_COMPILATION_AUDIT.json", audit)
    for d in [
        "spec/amendments",
        "work",
        "roles",
        "skills",
        "adapters",
        "Evidence",
        ".laos/runtime",
        ".laos/schemas",
        ".laos/policies",
        ".laos/state/checkpoints",
        ".laos/state/baselines",
        ".laos/state/locks",
        ".laos/state/task_packets",
        ".laos/templates",
        "scripts",
    ]:
        (out / d).mkdir(parents=True, exist_ok=True)

    shutil.copy2(dist / "laos_runtime.py", out / ".laos/runtime/laos.py")
    for p in (dist / "schemas").glob("*.json"):
        shutil.copy2(p, out / ".laos/schemas" / p.name)
    shutil.copytree(dist / "project_pack_assets/roles", out / "roles", dirs_exist_ok=True)
    shutil.copytree(dist / "project_pack_assets/skills", out / "skills", dirs_exist_ok=True)
    shutil.copytree(dist / "project_pack_assets/adapters", out / "adapters", dirs_exist_ok=True)
    shutil.copytree(dist / "templates", out / ".laos/templates", dirs_exist_ok=True)

    reqs = {"schema_version": "1.0", "spec_version": bp["spec_version"], "requirements": bp["requirements"]}
    invariants = {"schema_version": "1.0", "invariants": bp.get("invariants", [])}
    graph = {
        "schema_version": "1.0",
        "project_name": bp["project_name"],
        "engagement_mode": bp["engagement_mode"],
        "tasks": bp["tasks"],
    }
    trace = {"schema_version": "1.0", "requirements": []}
    for req in bp["requirements"]:
        related = [task["id"] for task in bp["tasks"] if req["id"] in task["requirements"]]
        trace["requirements"].append(
            {"requirement_id": req["id"], "tasks": related, "status": "PLANNED" if related else "UNMAPPED"}
        )
    save(out / "spec/requirements.json", reqs)
    save(out / "spec/invariants.json", invariants)
    save(out / "spec/non_goals.json", {"non_goals": bp["non_goals"]})
    save(out / "spec/architecture.json", {"architecture": bp["architecture"], "stack": bp["stack"]})
    save(out / "spec/integrations.json", {"integrations": bp["integrations"]})
    save(out / "spec/traceability_map.json", trace)
    save(out / "spec/engagement_context.json", {"engagement_mode": bp["engagement_mode"], "pack_purpose": bp["pack_purpose"], "existing_project_context": bp["existing_project_context"], "provenance": bp["provenance"]})
    save(out / "spec/project_definition.json", bp["project_definition"])
    save(out / "spec/user_roles.json", {"roles": bp["user_roles"], "permission_matrix": bp["permission_matrix"]})
    save(out / "spec/user_journeys.json", {"journeys": bp["user_journeys"]})
    save(out / "spec/data_model.json", {"entities": bp["data_model"]})
    save(out / "spec/security_and_privacy.json", {"security_requirements": bp["security_requirements"], "privacy_and_retention": bp["privacy_and_retention"]})
    save(out / "spec/ui_contract.json", bp["ui_contract"])
    save(out / "spec/quality_budgets.json", bp["quality_budgets"])
    save(out / "spec/operational_requirements.json", {"requirements": bp["operational_requirements"]})
    save(out / "spec/architecture_decisions.json", {"decisions": bp["architecture_decisions"]})
    save(out / "spec/deployment_contract.json", bp["deployment_contract"])
    save(out / "spec/acceptance_model.json", bp["acceptance_model"])
    save(out / "spec/preservation_contract.json", {"behaviour": bp["preservation_contract"], "regression_contract": bp["regression_contract"]})
    save(out / "spec/repository_baseline_expectation.json", {"expected_repository_fingerprint": bp["expected_repository_fingerprint"], "expected_git_commit": bp["expected_git_commit"], "provenance": bp["provenance"]})
    save(out / "work/task_graph.json", graph)
    save(out / "work/outcome_ledger.json", {"tasks": [{"task_id": t["id"], "status": "DEFINED"} for t in bp["tasks"]]})
    save(out / "work/permissions.json", {"granted": bp["permissions"], "default": "DENY_UNDECLARED"})

    state = {"schema_version": "1.0", "acceptance_state": "PARTIAL / NOT FINAL", "created_at": created, "task_states": {}}
    for task in bp["tasks"]:
        state["task_states"][task["id"]] = {
            "status": "DEFINED",
            "claimed_by": None,
            "claimed_at": None,
            "started_at": None,
            "updated_at": created,
            "notes": [],
            "changed_files": [],
            "review": None,
            "baseline_fingerprint": None,
            "last_heartbeat_at": None,
        }
    save(out / ".laos/state/current_state.json", state)
    save(out / ".laos/state/check_results.json", {"results": []})
    save(out / ".laos/state/evidence_index.json", {"items": []})
    write(out / ".laos/state/side_effect_journal.jsonl", "")
    write(out / ".laos/state/failed_approaches.jsonl", "")
    genesis = {
        "event_id": str(uuid.uuid4()),
        "timestamp": created,
        "event_type": "PACK_COMPILED",
        "task_id": None,
        "actor": "LAOS Project Pack Compiler",
        "details": {"pack_id": pack_id, "project_name": bp["project_name"], "engagement_mode": bp["engagement_mode"]},
        "previous_hash": "GENESIS",
    }
    genesis["event_hash"] = sha_text(canon(genesis))
    write(out / ".laos/state/events.jsonl", json.dumps(genesis, ensure_ascii=False, sort_keys=True) + "\n")

    config = {
        "laos_version": VERSION,
        "schema_version": "1.0",
        "require_git": True,
        "evidence_root": "Evidence",
        "engagement_mode": bp["engagement_mode"],
        "repository_intake_complete_at_compile_time": bool(bp.get("repository_intake_complete")),
        "instruction_priority": [
            "safety_and_permission",
            "no_fake_functionality",
            "project_invariants",
            "current_task_contract",
            "evidence_and_artifact_truth",
            "convenience",
        ],
        "task_state_machine": [
            "DEFINED",
            "READY",
            "CLAIMED",
            "IN_PROGRESS",
            "IMPLEMENTED",
            "TESTED",
            "EVIDENCED",
            "REVIEWED",
            "CLOSED",
        ],
        "default_permission": "DENY_UNDECLARED",
        "target_agent": bp["target_agent"],
        "pack_purpose": bp["pack_purpose"],
        "risk_level": bp["risk_level"],
        "check_freshness_required": True,
        "evidence_hash_revalidation_required": True,
        "reviewer_independence_required": True,
        "lock_lease_minutes": 60,
        "command_timeout_seconds": 1800,
        "max_captured_command_output_bytes": 200000,
        "allow_check_command_override": False,
        "inherit_nonsecret_environment": True,
        "mandatory_escalation_after_same_failure": 3,
        "required_event_anchor_on_finalization": True,
        "expected_repository_fingerprint": bp["expected_repository_fingerprint"],
        "expected_git_commit": bp["expected_git_commit"],
    }
    save(out / ".laos/config.json", config)
    policies = {
        "instruction_priority.json": {"priority": config["instruction_priority"]},
        "permissions.json": {"granted": bp["permissions"], "default": "DENY_UNDECLARED"},
        "escalation.json": {
            "triggers": [
                "same failure twice without progress",
                "contradictory specification",
                "security or authorization uncertainty",
                "unexplained data loss",
                "unapproved external side effect",
                "scope expansion required",
                "evidence contradicts implementation",
                "material repository truth remains unresolved after reconciliation",
            ],
            "action": "Create NEEDS_ESCALATION state and compact escalation packet.",
        },
        "retries.json": {"same_failure_warning": 1, "failed_approach_required": 2, "mandatory_escalation": 3},
        "acceptance.json": {
            "levels": [
                "ACCEPTED",
                "ACCEPTED WITH KNOWN NON-BLOCKERS",
                "CONDITIONAL ACCEPTANCE",
                "REJECTED",
                "PARTIAL / NOT FINAL",
            ]
        },
        "existing_project_entry.json": {
            "modes": sorted(EXISTING_PROJECT_MODES),
            "default_gate": "TASK-000 repository reconciliation unless verified intake is complete",
            "no_product_code_before_baseline": True,
        },
    }
    for name, data in policies.items():
        save(out / ".laos/policies" / name, data)

    manifest = {
        "laos_version": VERSION,
        "schema_version": "1.0",
        "pack_id": pack_id,
        "project_name": bp["project_name"],
        "engagement_mode": bp["engagement_mode"],
        "pack_purpose": bp["pack_purpose"],
        "project_id": bp.get("provenance", {}).get("project_id") or str(uuid.uuid4()),
        "parent_capture_id": bp.get("provenance", {}).get("capture_id"),
        "parent_pack_id": bp.get("provenance", {}).get("parent_pack_id"),
        "expected_repository_fingerprint": bp["expected_repository_fingerprint"],
        "expected_git_commit": bp["expected_git_commit"],
        "spec_version": bp["spec_version"],
        "created_at": created,
        "target_agent": bp["target_agent"],
        "operating_system": bp["operating_system"],
        "project_root": bp["project_root"],
        "blueprint_sha256": sha_text(canon(bp)),
        "source_of_truth_order": [
            "current source and Git truth",
            "reproducible tests and observable running behavior",
            "approved spec and amendments",
            "verified deployment and external-system truth",
            "machine state and event ledger",
            "current task packet",
            "registered evidence",
            "old chat, memory, or prior-agent narrative only when non-conflicting",
        ],
    }

    existing = bp["engagement_mode"] in EXISTING_PROJECT_MODES
    start_extra = (
        "8. Do not change product code before `TASK-000` is legally closed. Reconcile the existing repository first.\n"
        if any(t.get("id") == "TASK-000" for t in bp["tasks"])
        else "8. Begin only the task returned by the runtime.\n"
    )
    write(
        out / "START_HERE.md",
        f"""# START HERE - {bp['project_name']}\n\nThis is a **compiled LAOS v7 project-specific implementation pack**. It is the assignment for this exact job, not the reusable master LAOS ZIP.\n\n## Engagement mode\n`{bp['engagement_mode']}`\n\n## Your mission\nImplement the entire approved scope truthfully. Preserve verified existing behavior. Do not skip tasks, invent completion, weaken tests, create fake production functionality, or silently change the specification.\n\n## First actions\n1. Identify and confirm the actual repository root. The blueprint records `{bp['project_root']}`. Do not assume a path.\n2. Place or extract this project pack at the root of the current working repository. The `Evidence/` folder must be at that root.\n3. Read, in order: `HARNESS_MANIFEST.json`, `AGENTS.md`, `PROJECT_ENTRY_CONTEXT.md`, `MASTER_SPEC.md`, `REPOSITORY_BASELINE.md`, `RUN_STATE.md`, `NEXT_ACTIONS.md`, `OPEN_RISKS.md`, `COMMANDS.md`, and `IMPLEMENTATION_DIRECTIVE.md`.\n4. Run: `python .laos/runtime/laos.py doctor`\n5. Run: `python .laos/runtime/laos.py refresh`\n6. Run: `python .laos/runtime/laos.py next`\n7. Read the generated task packet and execute only that legal task.\n{start_extra}\n## Mandatory state sequence\n`DEFINED -> READY -> CLAIMED -> IN_PROGRESS -> IMPLEMENTED -> TESTED -> EVIDENCED -> REVIEWED -> CLOSED`\n\nYou may propose a transition. The runtime decides whether the gate passes. Never manually mark a task closed.\n\n## Existing-project truth rule\n{"This repository already contains meaningful project state. Current source, Git, reproducible tests, running behavior, and verified deployment outrank old narrative. Previous-agent claims must be reconciled." if existing else "This is a new-project engagement. Do not invent existing infrastructure, credentials, integrations, or deployment state."}\n\n## Core truth rules\n- Real behavior, not plans, wrappers, simulations, or placeholders.\n- Test-only mocks may exist only in isolated test paths and may never be presented as production capability.\n- Every required check must be run and recorded.\n- Every required evidence file must exist and be non-empty.\n- External writes require authorization, an idempotency key, external verification, and rollback or compensation notes.\n- A task cannot close while required side effects are unresolved.\n- If a required tool is unavailable, record the failed attempt and exact verification boundary. No silent fallback.\n- Stop honestly on a failed gate.\n- Required checks and evidence expire when relevant source changes; rerun and rerecord them.\n- Do not weaken, delete, skip, or rewrite tests merely to achieve a passing result.\n- A continuation pack must pass the repository freshness gate before product-code work.\n""",
    )
    write(
        out / "AGENTS.md",
        f"""# AGENTS - LAOS v7 router\n\nProject: **{bp['project_name']}**\nEngagement mode: `{bp['engagement_mode']}`\n\nRead `START_HERE.md` before any implementation. The compact routing order is:\n1. `PROJECT_ENTRY_CONTEXT.md`, `MASTER_SPEC.md`, and `spec/*` for approved truth.\n2. Existing-project baseline and continuity files for current repository truth.\n3. `RUN_STATE.md` and `.laos/state/*` for current execution state.\n4. `NEXT_ACTIONS.md` and generated task packet for current legal work.\n5. `COMMANDS.md` for canonical commands.\n6. `skills/*/SKILL.md` only when triggered.\n7. `EVIDENCE_REQUIREMENTS.md` for proof rules.\n\nDo not put unique project requirements into vendor-specific agent configuration. Do not accept prior-agent narrative over current evidence.\n""",
    )
    req_lines = "\n".join(
        f"### {r['id']} - {r['priority']}\n{r['text']}\n\nAcceptance:\n" + md_list(r.get("acceptance", []), "Defined by linked tasks")
        for r in bp["requirements"]
    )
    inv_lines = "\n".join(f"- `{x['id']}` {x['text']}" for x in bp.get("invariants", [])) or "- None declared."
    write(
        out / "MASTER_SPEC.md",
        f"""# MASTER SPECIFICATION\n\n## Project\n**{bp['project_name']}**\n\n## Engagement mode\n`{bp['engagement_mode']}`\n\n## Approved purpose\n{bp['project_summary']}\n\n## Discussion-derived context\n{bp['source_discussion_summary']}\n\n## Technology stack\n{md_list(bp['stack'])}\n## Non-goals\n{md_list(bp['non_goals'])}\n## Invariants\n{inv_lines}\n\n## Requirements\n{req_lines}\n\n## Specification change control\nThe builder may not rewrite this specification to match its implementation or the current repository. Any material change requires a proposed amendment under `spec/amendments/`, impact analysis, and explicit approval.\n""",
    )
    write(out / "ARCHITECTURE.md", "# ARCHITECTURE\n\n" + md_list(bp["architecture"], "Architecture must be discovered and documented before implementation when an existing repository is involved."))
    cmd_lines: list[str] = []
    for cmd in bp["commands"]:
        cmd_lines.append(
            f"## {cmd.get('id', cmd.get('name', 'COMMAND'))}\nPurpose: {cmd.get('purpose', '')}\n\n```text\n{cmd.get('command', '')}\n```\nExpected: {cmd.get('expected', 'Exit 0 and behavior-specific proof.')}\n"
        )
    write(
        out / "COMMANDS.md",
        "# COMMANDS\n\nUse exact commands where provided. Run task checks through the LAOS runtime so exit codes and evidence are captured. Existing-project commands must be verified against the current repository.\n\n"
        + ("\n".join(cmd_lines) if cmd_lines else "Project-specific commands are defined in task checks or must be reconciled before implementation. Discovering commands does not authorize changing the specification.\n"),
    )
    write(out / "PRODUCT_DEFINITION.md", "# PRODUCT DEFINITION\n\n" + json.dumps(bp["project_definition"], indent=2, ensure_ascii=False) + "\n")
    write(out / "USER_ROLES_AND_PERMISSIONS.md", "# USER ROLES AND PERMISSIONS\n\n## Roles\n" + md_list(bp["user_roles"], "No roles supplied; this must be resolved before authentication or authorization work.") + "\n## Permission matrix\n" + table_rows(bp["permission_matrix"], [("Role", "role"), ("Resource or screen", "resource"), ("Allowed actions", "actions"), ("Data boundary", "data_boundary")]))
    write(out / "USER_JOURNEYS.md", "# USER JOURNEYS\n\n" + md_list(bp["user_journeys"], "No journeys supplied; the lead AI must define or explicitly mark them out of scope."))
    write(out / "DATA_MODEL_AND_RULES.md", "# DATA MODEL AND RULES\n\n" + md_list(bp["data_model"], "No data model supplied; do not invent persistence rules silently."))
    write(out / "SECURITY_PRIVACY_AND_RETENTION.md", "# SECURITY, PRIVACY AND RETENTION\n\n## Security\n" + md_list(bp["security_requirements"], "No project-specific security requirements supplied; global secure defaults still apply.") + "\n## Privacy and retention\n" + md_list(bp["privacy_and_retention"], "No project-specific retention rules supplied."))
    write(out / "UI_AND_EXPERIENCE_CONTRACT.md", "# UI AND EXPERIENCE CONTRACT\n\n" + json.dumps(bp["ui_contract"], indent=2, ensure_ascii=False) + "\n")
    write(out / "QUALITY_AND_OPERATIONS_CONTRACT.md", "# QUALITY AND OPERATIONS CONTRACT\n\n## Quality budgets\n```json\n" + json.dumps(bp["quality_budgets"], indent=2, ensure_ascii=False) + "\n```\n\n## Operational requirements\n" + md_list(bp["operational_requirements"], "No project-specific operational requirements supplied."))
    write(out / "PRESERVATION_AND_REGRESSION_CONTRACT.md", "# PRESERVATION AND REGRESSION CONTRACT\n\n## Behaviour that must remain working\n" + md_list(bp["preservation_contract"], "No behaviour declared yet; existing-project reconciliation must identify it before implementation.") + "\n## Mandatory regression checks\n" + md_list(bp["regression_contract"], "Defined by task checks and reconciliation."))
    write(out / "REPOSITORY_FRESHNESS_GATE.md", f"# REPOSITORY FRESHNESS GATE\n\nExpected content fingerprint: `{bp['expected_repository_fingerprint'] or 'NOT_SUPPLIED'}`\n\nExpected Git commit: `{bp['expected_git_commit'] or 'NOT_SUPPLIED'}`\n\nFor continuation packs, implementation must stop and reconcile if the current repository materially differs from the captured baseline. Minor harness extraction files do not count as product changes; source, configuration, test, migration, and deployment differences do.\n")

    write(
        out / "IMPLEMENTATION_DIRECTIVE.md",
        f"""# IMPLEMENTATION DIRECTIVE\n\n## Finish line\nAll mandatory requirements are implemented, every task is legally `CLOSED`, required reviews pass, evidence is complete, side effects reconcile, final artifacts verify, Git truth matches the report, existing working behavior is preserved, and known limitations are disclosed.\n\n## Permissions granted\n{md_list(bp['permissions'])}\nAnything not granted is denied until explicitly authorized.\n\n## No-fake rule\nNo fake, simulated, demo, placeholder, mock, dry-run, planned-but-not-built, or local-contract-only capability may appear as production functionality.\n\n## Existing-project rule\nFor existing-project modes, do not begin product-code work before the repository baseline is verified or `TASK-000` is legally closed. Current evidence outranks previous-agent claims.\n\n## Task discipline\nComplete one meaningful bounded task at a time. A task is not complete because an agent says so; it closes only when the runtime's checks, evidence, review, side-effect, scope, and state gates pass.\n""",
    )
    write(
        out / "EVIDENCE_REQUIREMENTS.md",
        """# EVIDENCE REQUIREMENTS\n\nAll evidence belongs under the `Evidence/` folder at the verified repository root and must be registered with `record-evidence`. Evidence must be reviewable, current, non-empty, secret-free, and tied to task and requirement IDs.\n\nMinimum major-task evidence: context and plan, diff intent, command transcripts, test and failure-path results, critical source proof, negative evidence, claim-to-evidence map, review, and final task truth.\n\nFor existing-project intake, also evidence Git state, baseline commands and tests, previous-claim reconciliation, deployment and external-system boundaries, existing behavior to preserve, and the exact safe resume point.\n\nEvidence maturity: 0 assertion only; 1 source/docs; 2 command/test; 3 end-to-end/API/UI; 4 independent rerun. Final behavior acceptance normally requires level 3, and high-risk work requires level 4.\n""",
    )
    write(out / "DECISIONS.md", "# DECISIONS\n\nAppend-only. Do not rewrite old decisions; supersede them.\n\n" + md_list(bp["decisions"]))
    write(out / "OPEN_RISKS.md", "# OPEN RISKS\n\n" + md_list(bp["risks"]))
    write(out / "INTEGRATIONS.md", "# INTEGRATIONS\n\n" + md_list(bp["integrations"]))
    write(out / "RUN_STATE.md", "# RUN_STATE\n\nGenerated after first `laos status`. Current accepted state: PARTIAL / NOT FINAL.\n")
    write(out / "NEXT_ACTIONS.md", "# NEXT_ACTIONS\n\nRun `python .laos/runtime/laos.py refresh` and then `python .laos/runtime/laos.py next`.\n")
    build_midproject_files(bp, out)
    write(
        out / "Evidence/README.md",
        """# Evidence\n\nThis folder is the authoritative proof store at the root of the current working repository. Create task folders such as `Evidence/TASK-001/`. Do not store secrets. Templates are under `.laos/templates/evidence/`. Do not create final ZIP verification inside the ZIP it verifies.\n""",
    )
    write(out / "scripts/laos.ps1", 'param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Args)\npython "$PSScriptRoot/../.laos/runtime/laos.py" @Args\nexit $LASTEXITCODE\n')
    write(out / "scripts/laos.cmd", '@echo off\npython "%~dp0..\\.laos\\runtime\\laos.py" %*\nexit /b %ERRORLEVEL%\n')
    write(out / "scripts/laos.sh", '#!/usr/bin/env sh\npython3 "$(dirname "$0")/../.laos/runtime/laos.py" "$@"\n')
    os.chmod(out / "scripts/laos.sh", 0o755)
    write(out / ".gitignore", ".laos/runtime/__pycache__/\n*.pyc\n")
    write(out / "CLAUDE.md", "# CLAUDE.md\n\nRead `START_HERE.md` and follow the universal LAOS files. This file is only a router.\n")
    (out / ".cursor/rules").mkdir(parents=True, exist_ok=True)
    write(
        out / ".cursor/rules/laos.mdc",
        "---\ndescription: Route all work through LAOS v7\nalwaysApply: true\n---\nRead START_HERE.md before editing. Use .laos/runtime/laos.py for task state, checks, evidence, and closure.\n",
    )
    write(
        out / "COPY_PASTE_AGENT_ENTRY_PROMPT.txt",
        f"You are the implementation agent for {bp['project_name']}. Read START_HERE.md in full, run the LAOS preflight and repository reconciliation, and implement the entire approved specification task by task. Preserve verified existing behavior. Do not skip tasks, manually close tasks, weaken tests, change the specification without an approved amendment, create fake production functionality, or claim anything without evidence. Continue until every mandatory task is legally CLOSED or a genuine stop condition is documented.\n",
    )

    inventory = []
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name != "HARNESS_MANIFEST.json":
            inventory.append(
                {
                    "path": str(p.relative_to(out)).replace("\\", "/"),
                    "bytes": p.stat().st_size,
                    "sha256": sha_file(p),
                }
            )
    manifest["files"] = inventory
    save(out / "HARNESS_MANIFEST.json", manifest)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("blueprint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    bp = normalize(json.loads(args.blueprint.read_text(encoding="utf-8")))
    out = args.output.resolve()
    if out.exists():
        if not args.force:
            fail(f"output exists: {out}")
        shutil.rmtree(out)
    dist = Path(__file__).resolve().parents[1]
    build_files(bp, out, dist)
    print(
        json.dumps(
            {
                "status": "PASS",
                "output": str(out),
                "project": bp["project_name"],
                "engagement_mode": bp["engagement_mode"],
                "tasks": len(bp["tasks"]),
                "requirements": len(bp["requirements"]),
                "repository_reconciliation_task": any(t.get("id") == "TASK-000" for t in bp["tasks"]),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
