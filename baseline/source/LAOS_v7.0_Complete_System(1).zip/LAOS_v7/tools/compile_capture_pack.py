#!/usr/bin/env python3
"""Compile a project-specific LAOS v7 existing-application capture pack."""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, shutil, sys, uuid
from pathlib import Path
from typing import Any

VERSION = "7.0.0"
ROOT = Path(__file__).resolve().parents[1]

def now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()

def load(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"CAPTURE REQUEST ERROR: {exc}")
    if not data.get("project_name"):
        raise SystemExit("CAPTURE REQUEST ERROR: project_name is required")
    return data

def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path: Path, value: Any) -> None:
    write(path, json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n")

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def main(argv: list[str] | None = None) -> int:
    p=argparse.ArgumentParser(description="Compile a LAOS v7 Existing-App Capture Pack")
    p.add_argument("request")
    p.add_argument("output_directory")
    args=p.parse_args(argv)
    request=load(Path(args.request).resolve())
    out=Path(args.output_directory).resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"Output directory is not empty: {out}")
    out.mkdir(parents=True, exist_ok=True)
    request.setdefault("schema_version", "1.0")
    request.setdefault("laos_version", VERSION)
    request.setdefault("pack_type", "EXISTING_APP_CAPTURE")
    request.setdefault("project_id", str(uuid.uuid4()))
    request.setdefault("capture_pack_id", str(uuid.uuid4()))
    request.setdefault("created_at", now())
    request.setdefault("target_agent", "generic-desktop-agent")
    request.setdefault("capture_depth", "deep")
    request.setdefault("include_safe_source_snapshot", True)
    request.setdefault("max_snapshot_file_bytes", 10 * 1024 * 1024)
    request.setdefault("max_snapshot_total_bytes", 500 * 1024 * 1024)
    request.setdefault("additional_excluded_directories", [])
    request.setdefault("requested_change_context", "No implementation is authorized during capture. The purpose is to understand the application before a later implementation pack is compiled.")
    request.setdefault("known_constraints", [])
    request.setdefault("known_live_urls", [])
    request.setdefault("known_documents", [])
    request.setdefault("owner_notes", [])
    save(out / "CAPTURE_CONTRACT.json", request)
    shutil.copy2(ROOT / "tools" / "capture_runtime.py", out / "capture_runtime.py")
    write(out / "CAPTURE_START_HERE.md", f"""# Start here: capture the current truth of {request['project_name']}

This is a **capture-only assignment**. Do not implement, repair, refactor, deploy, migrate, delete, email, or modify product behaviour.

Your job is to inspect the existing application, verify what can be verified, clearly mark what cannot be verified, and return one complete ZIP named `App_Intelligence_Return.zip`.

## Required sequence

1. Confirm the actual repository root. Do not assume it from this pack.
2. Read `CAPTURE_CONTRACT.json` and `RETURN_PACK_REQUIREMENTS.md`.
3. From the actual repository root, run:

   `python <path-to-this-pack>/capture_runtime.py init --repo . --working App_Intelligence_Working --contract <path-to-this-pack>/CAPTURE_CONTRACT.json`

4. Inspect the generated `App_Intelligence_Working` directory.
5. Investigate the application carefully. Run only safe read-only or test commands. Ask for approval before any action with external or destructive effects.
6. Replace every `TO_BE_COMPLETED` marker with direct findings or an explicit `UNKNOWN` plus the reason.
7. Populate the feature, UI, API, data, test, deployment, integration, authorization, issue, protected-area, prior-claim, and evidence records.
8. Put proof under `App_Intelligence_Working/Evidence/`.
9. Set `completion_state` in `APP_INTELLIGENCE_MANIFEST.json` to `COMPLETE`, `PARTIAL`, or `BLOCKED`. A partial or blocked return must list exact limitations.
10. Validate:

   `python <path-to-this-pack>/capture_runtime.py validate --working App_Intelligence_Working`

11. Finalize:

   `python <path-to-this-pack>/capture_runtime.py finalize --repo . --working App_Intelligence_Working --output App_Intelligence_Return.zip`

12. Give the user **only** the verified `App_Intelligence_Return.zip` as the main deliverable, with a short truthful summary of limitations.

## Non-negotiable rule

Do not mix capture with implementation. Discovering a defect does not authorize you to fix it. The lead AI will use the returned ZIP to create the separate continuation, repair, or feature pack.
""")
    write(out / "RETURN_PACK_REQUIREMENTS.md", """# App Intelligence Return ZIP requirements

The return ZIP must be sufficient for a lead AI that has not inspected the repository to understand its current state and safely compile the next implementation pack.

It must contain repository identity and dirty state, a safe source snapshot and file manifest, environment and command baselines, architecture, user-interface inventory, API inventory, data and migration map, authentication and authorization, integrations, tests, deployment truth, dependencies and licences, prior-agent claims, feature status, known issues, protected behaviour, assumptions and unknowns, evidence, and the recommended safe resume point.

Every claim must be one of:

- directly verified with evidence;
- inferred and clearly labelled as inference;
- reported from a prior source but not rerun;
- unknown with a precise reason.

The capture must not expose secret values, private keys, environment-file contents, production data, or credentials. Source files with possible secrets are excluded automatically and listed in the manifest.
""")
    write(out / "COPY_PASTE_INSTRUCTION_TO_CAPTURE_AGENT.txt", """Read CAPTURE_START_HERE.md in the attached LAOS Existing-App Capture Pack. This is a capture-only assignment: do not change product code or behaviour. Inspect the actual repository, run the safe automatic capture, complete every required App Intelligence record with evidence or explicit unknowns, validate the working directory, and return the single verified App_Intelligence_Return.zip. Do not repair, refactor, deploy, or claim unverified facts.""")
    write(out / "WHY_THIS_PACK_EXISTS.md", """# Why this pack exists

A continuation agent cannot safely work from polished handoff prose, an old specification, or a quick repository scan. Existing projects often contain uncommitted work, stale documentation, disconnected screens, simulated integrations, obsolete commands, live deployments that do not match source, and earlier agents' unsupported completion claims.

This pack separates **understanding** from **changing**. The weaker agent first returns a structured, evidence-backed App Intelligence ZIP. The lead AI then uses that ZIP to compile a separate continuation pack with the correct preservation boundaries, regression tests, repository fingerprint, and task graph.
""")
    write(out / "INVESTIGATION_CHECKLIST.md", """# Investigation checklist

- Establish repository root, branch, commit, dirty state, remotes, branches, tags, submodules and LFS.
- Explain every meaningful uncommitted and untracked file.
- Identify entry points, services, data flow, background work and deployment files.
- Verify install, build, run, lint, type-check, test and smoke-test commands where safe.
- Map every discoverable user-facing feature and screen.
- Map API routes, consumers, authentication and live status.
- Map storage, schemas, migrations, indexes, seeds, backups and data-loss risks.
- Map roles, permissions, protected routes and backend authorization.
- Map integrations and distinguish configured, tested, live, unavailable and assumed.
- Reconcile prior-agent claims against current proof.
- Record working behaviour that must not be damaged.
- Record technical debt, defects, risks, unknowns and missing access.
- Identify the last known safe baseline and first safe next task.
- Include evidence and do not expose secret values or private data.
""")
    # Include schemas and reusable return templates for transparency and offline use.
    schema_dir=out / "schemas"
    template_dir=out / "return_templates"
    schema_dir.mkdir(parents=True, exist_ok=True)
    template_dir.mkdir(parents=True, exist_ok=True)
    for source in sorted((ROOT / "schemas" / "app_intelligence").glob("*.json")) if (ROOT / "schemas" / "app_intelligence").exists() else []:
        shutil.copy2(source, schema_dir / source.name)
    if (ROOT / "templates" / "app_intelligence").exists():
        shutil.copytree(ROOT / "templates" / "app_intelligence", template_dir, dirs_exist_ok=True)
    files=[]
    for path in sorted(p for p in out.rglob('*') if p.is_file()):
        files.append({"path": path.relative_to(out).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)})
    save(out / "CAPTURE_PACK_MANIFEST.json", {"laos_version": VERSION, "pack_type": "EXISTING_APP_CAPTURE", "project_id": request["project_id"], "capture_pack_id": request["capture_pack_id"], "created_at": request["created_at"], "files": files})
    print(json.dumps({"status":"PASS","output":str(out),"file_count":len(files),"capture_pack_id":request["capture_pack_id"]}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
