#!/usr/bin/env python3
"""Compile a LAOS v7 continuation/repair/feature pack from an App Intelligence Return ZIP."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
VALIDATOR=ROOT/'tools'/'validate_return_pack.py'
COMPILER=ROOT/'tools'/'compile_project_pack.py'

def load(path: Path) -> dict[str, Any]:
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: raise SystemExit(f'CONTINUATION REQUEST ERROR: {exc}')

def safe_extract(zip_path: Path, out: Path) -> None:
    with zipfile.ZipFile(zip_path,'r') as zf:
        for info in zf.infolist():
            name=info.filename.replace('\\','/')
            if name.startswith('/') or '..' in Path(name).parts or '\\' in info.filename:
                raise SystemExit(f'UNSAFE RETURN ZIP ENTRY: {info.filename}')
        zf.extractall(out)

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def md_summary(data: Any, limit: int=50) -> list[Any]:
    if isinstance(data,list): return data[:limit]
    if isinstance(data,dict):
        for key in ['features','issues','items','claims','executions','areas','unknowns','environments']:
            if isinstance(data.get(key),list): return data[key][:limit]
    return []

def recalc_manifest(out: Path) -> None:
    path=out/'HARNESS_MANIFEST.json'
    manifest=json.loads(path.read_text(encoding='utf-8'))
    files=[]
    for p in sorted(x for x in out.rglob('*') if x.is_file() and x != path):
        files.append({'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    manifest['files']=files
    path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')

def main() -> int:
    p=argparse.ArgumentParser(description='Compile a LAOS v7 continuation pack from a validated App Intelligence Return ZIP')
    p.add_argument('return_zip')
    p.add_argument('continuation_request')
    p.add_argument('output_directory')
    p.add_argument('--force',action='store_true')
    args=p.parse_args()
    return_zip=Path(args.return_zip).resolve(); request_path=Path(args.continuation_request).resolve(); out=Path(args.output_directory).resolve()
    spec=importlib.util.spec_from_file_location('validator',VALIDATOR); mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
    validation=mod.validate(return_zip)
    if validation.get('status')!='PASS':
        raise SystemExit('RETURN ZIP VALIDATION FAILED:\n'+json.dumps(validation,indent=2))
    request=load(request_path)
    for key in ['project_name','requested_change','requirements','tasks']:
        if not request.get(key): raise SystemExit(f'CONTINUATION REQUEST ERROR: {key} is required')
    with tempfile.TemporaryDirectory(prefix='laos_continuation_') as tmp:
        ext=Path(tmp)/'return'; ext.mkdir(); safe_extract(return_zip,ext)
        manifest=load(ext/'APP_INTELLIGENCE_MANIFEST.json')
        identity=load(ext/'REPOSITORY_IDENTITY.json')
        source=load(ext/'SOURCE_MANIFEST.json')
        feature=load(ext/'FEATURE_STATUS_MATRIX.json')
        commands=load(ext/'COMMAND_BASELINE.json')
        tests=load(ext/'TEST_BASELINE.json')
        deployment=load(ext/'DEPLOYMENT_TRUTH.json')
        integrations=load(ext/'INTEGRATIONS_INVENTORY.json')
        issues=load(ext/'KNOWN_ISSUES.json')
        protected=load(ext/'PROTECTED_AREAS.json')
        prior=load(ext/'PRIOR_AGENT_CLAIMS.json')
        unknowns=load(ext/'ASSUMPTIONS_AND_UNKNOWNS.json')
        env=load(ext/'ENVIRONMENT_MANIFEST.json')
        architecture=(ext/'ARCHITECTURE_MAP.md').read_text(encoding='utf-8')
        resume=(ext/'RECOMMENDED_RESUME_PLAN.md').read_text(encoding='utf-8')
        summary=(ext/'PROJECT_EXECUTIVE_SUMMARY.md').read_text(encoding='utf-8')
        bp=dict(request)
        bp.setdefault('project_summary',request['requested_change'])
        bp.setdefault('engagement_mode','existing_project_feature')
        bp['pack_purpose']='existing_project_continuation'
        bp.setdefault('project_root',identity.get('repository_root','<DISCOVER_CURRENT_REPO_ROOT>'))
        bp.setdefault('target_agent','generic-desktop-agent')
        bp.setdefault('operating_system',(env.get('platform') or {}).get('system','auto-detect'))
        bp.setdefault('stack',[])
        bp.setdefault('non_goals',[])
        bp.setdefault('architecture',[architecture[:12000]])
        bp.setdefault('commands',commands.get('commands',[]))
        bp.setdefault('permissions',['READ_REPO','WRITE_APPROVED_PATHS','RUN_LOCAL_COMMANDS'])
        bp.setdefault('integrations',md_summary(integrations))
        bp.setdefault('decisions',[])
        bp.setdefault('risks',md_summary(issues))
        bp.setdefault('invariants',[])
        bp['repository_intake_complete']=True
        bp['include_reconciliation_task']=True
        bp['expected_repository_fingerprint']=source.get('repository_content_fingerprint')
        bp['expected_git_commit']=identity.get('head_commit')
        bp['provenance']={
            'project_id':manifest.get('project_id'),
            'capture_id':manifest.get('capture_id'),
            'parent_pack_id':manifest.get('parent_capture_pack_id'),
            'return_zip_sha256':validation.get('zip_sha256'),
            'capture_completion_state':manifest.get('completion_state'),
        }
        bp.setdefault('preservation_contract',protected.get('working_behaviour_to_preserve',[]))
        bp.setdefault('regression_contract',tests.get('critical_untested_behaviour',[]))
        bp['current_repo_state']=summary
        bp['source_discussion_summary']=request.get('source_discussion_summary',request['requested_change'])+'\n\nCaptured current-state summary:\n'+summary
        bp['existing_project_context']={
            'repository_access':identity.get('repository_root','Unknown'),
            'known_repo_state':[identity],
            'prior_agent_claims':md_summary(prior),
            'known_working_behavior':[x for x in feature.get('features',[]) if x.get('status') in {'WORKING_AND_VERIFIED','WORKING_BUT_NOT_RERUN'}],
            'known_partial_or_broken_behavior':[x for x in feature.get('features',[]) if x.get('status') not in {'WORKING_AND_VERIFIED','WORKING_BUT_NOT_RERUN'}],
            'known_commands':commands.get('commands',[]),
            'known_test_baseline':tests.get('executions',[]),
            'deployment_state':deployment.get('environments',[]),
            'external_systems':integrations.get('items',[]),
            'protected_areas':protected.get('areas',[])+protected.get('working_behaviour_to_preserve',[]),
            'technical_debt':issues.get('issues',[]),
            'unresolved_questions':unknowns.get('unknowns',[])+unknowns.get('access_limitations',[]),
            'source_materials':['Validated App Intelligence Return ZIP',f"capture_id={manifest.get('capture_id')}",f"repository_fingerprint={source.get('repository_content_fingerprint')}"]
        }
        blueprint=Path(tmp)/'blueprint.json'; blueprint.write_text(json.dumps(bp,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        cmd=[sys.executable,str(COMPILER),str(blueprint),str(out)]
        if args.force: cmd.append('--force')
        cp=subprocess.run(cmd,text=True,capture_output=True)
        if cp.returncode!=0: raise SystemExit(cp.stderr or cp.stdout)
        baseline=out/'CAPTURE_BASELINE'; baseline.mkdir(parents=True,exist_ok=True)
        keep=[
            'APP_INTELLIGENCE_MANIFEST.json','PROJECT_EXECUTIVE_SUMMARY.md','REPOSITORY_IDENTITY.json','SOURCE_MANIFEST.json','ENVIRONMENT_MANIFEST.json','ARCHITECTURE_MAP.md','FEATURE_STATUS_MATRIX.json','UI_INVENTORY.json','API_INVENTORY.json','DATA_AND_MIGRATION_MAP.json','AUTHORIZATION_MAP.md','INTEGRATIONS_INVENTORY.json','COMMAND_BASELINE.json','TEST_BASELINE.json','DEPLOYMENT_TRUTH.json','DEPENDENCY_AND_LICENSE_REPORT.json','PRIOR_AGENT_CLAIMS.json','KNOWN_ISSUES.json','PROTECTED_AREAS.json','ASSUMPTIONS_AND_UNKNOWNS.json','RECOMMENDED_RESUME_PLAN.md','EVIDENCE_INDEX.json','RETURN_PACK_VALIDATION.json','RETURN_PACK_FINALIZATION.json']
        for name in keep:
            src=ext/name
            if src.exists(): shutil.copy2(src,baseline/name)
        (baseline/'RETURN_ZIP_VALIDATION.json').write_text(json.dumps(validation,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
        (out/'BASELINE_IMPORT_NOTICE.md').write_text(f"""# Imported App Intelligence baseline

This continuation pack was compiled from capture `{manifest.get('capture_id')}` for project `{manifest.get('project_id')}`.

Expected repository content fingerprint: `{source.get('repository_content_fingerprint')}`

Expected Git commit: `{identity.get('head_commit')}`

Before product-code work, compare the current repository with this baseline. If source, tests, migrations, configuration, or deployment files materially changed after capture, stop and reconcile. Do not force the old plan onto a newer repository.

The imported baseline is under `CAPTURE_BASELINE/`. It is evidence about the captured moment, not permission to ignore new repository truth.
""",encoding='utf-8')
        recalc_manifest(out)
        print(json.dumps({'status':'PASS','output':str(out),'project_id':manifest.get('project_id'),'capture_id':manifest.get('capture_id'),'expected_repository_fingerprint':source.get('repository_content_fingerprint'),'return_zip_validation':validation},indent=2,ensure_ascii=False))
        return 0

if __name__=='__main__': raise SystemExit(main())
