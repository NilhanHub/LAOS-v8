# How to use LAOS in plain English

LAOS has three kinds of ZIP, but you normally handle only one at each moment.

## 1. Master LAOS ZIP

`LAOS_v7.0_Complete_System.zip`

You give this to the lead AI. It contains the factory, tools, templates and rules used to create project-specific packs.

## 2. Capture ZIP

Created only for an existing app. You give it to a weaker agent that can inspect the repository. The agent returns `App_Intelligence_Return.zip` and does not change product code.

## 3. Implementation ZIP

Created for a new build, feature, repair, continuation, audit repair or deployment. You give it to the weaker coding agent. It contains `START_HERE.md`, the exact specification, numbered tasks, runtime, checks and evidence rules.

## The simplest instructions

To me for a new app:

> Create the complete new-build implementation pack according to LAOS.

To me for an existing app that has not been fully captured:

> Create the LAOS existing-app capture pack. The agent must return one App Intelligence ZIP and must not implement anything.

To the capture agent:

> Read CAPTURE_START_HERE.md. Inspect and package the current app truth. Do not change product code. Return App_Intelligence_Return.zip.

Back to me:

> Validate this App Intelligence Return ZIP and create the continuation implementation pack for the change we agreed.

To the implementation agent:

> Read START_HERE.md and implement the complete approved scope through LAOS. Do not skip, simulate, weaken or falsely claim anything.
