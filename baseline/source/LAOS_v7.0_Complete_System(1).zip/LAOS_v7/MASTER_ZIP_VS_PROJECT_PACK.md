# Master ZIP versus project packs

| File type | Given to | Purpose |
|---|---|---|
| Master LAOS ZIP | Lead AI | Contains the reusable compiler, runtime, templates, capture system, validators and documentation. |
| Existing-app capture pack | Capture investigator | Produces a verified App Intelligence Return ZIP without changing the app. |
| App Intelligence Return ZIP | Lead AI | Supplies the current repository, architecture, feature, test, deployment and risk truth needed to plan safely. |
| New-build or continuation implementation pack | Weaker implementation agent | Contains the exact specification, task graph, runtime, checks, evidence and finish line for one assignment. |

The master ZIP is a factory. A project-specific pack is a job order produced by that factory.
