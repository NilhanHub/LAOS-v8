# Release integrity

The master ZIP is the single user-facing file. It includes source, documentation, templates, schemas, runtime, compilers, tests and internal release evidence.

The build process must:

1. remove generated caches;
2. validate required files and Python syntax;
3. run runtime tests and capture/continuation round-trip tests;
4. generate a content-hash manifest;
5. build the ZIP once from clean staging;
6. extract it externally and compare every file hash and size;
7. record final ZIP size, entry count and SHA-256 outside the ZIP during release construction;
8. not modify the ZIP after verification.

For normal use, Nilhan keeps only the final master ZIP. Internal verification evidence is already included for inspection, while the release SHA-256 is also stated when the file is delivered.
