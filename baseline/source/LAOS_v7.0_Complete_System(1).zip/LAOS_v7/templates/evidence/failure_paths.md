# Failure-Path Verification

| Failure path | Expected behavior | Observed behavior | Result | Evidence |
|---|---|---|---|---|
| <CASE> | <EXPECTED> | <OBSERVED> | PASS/FAIL | <PATH> |
