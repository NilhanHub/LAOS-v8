# Final Task Truth

Task: <TASK-ID>
Final state: <STATE>
Requirements disposition: <DISPOSITION>
Known limitations: <LIMITATIONS>
Evidence index: <REFERENCES>
