# Plan Contract

Task: <TASK-ID>
Objective: <OBJECTIVE>
Files expected to change: <PATHS>
Checks: <CHECKS>
Failure paths: <FAILURE_PATHS>
Stop conditions: <STOP_CONDITIONS>
