# Negative Evidence

Record what was checked and not found. Do not write "none" without describing the search or test.

- <CHECKED_AREA, METHOD, AND RESULT>
