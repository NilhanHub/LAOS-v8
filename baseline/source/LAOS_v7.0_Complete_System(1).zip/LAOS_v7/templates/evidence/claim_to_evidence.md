# Claim-to-Evidence Map

| Claim | Requirement/task | Evidence | Verification level |
|---|---|---|---|
| <CLAIM> | <ID> | <PATH> | source / test / end-to-end / independent rerun |
