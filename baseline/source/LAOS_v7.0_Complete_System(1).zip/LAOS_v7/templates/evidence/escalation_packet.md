# Escalation Packet

Task: <TASK-ID>
Exact blocker: <BLOCKER>
Attempts: <ATTEMPTS>
Failure signatures: <ERRORS>
Relevant files: <PATHS>
Evidence: <REFERENCES>
Decision required: <QUESTION>
