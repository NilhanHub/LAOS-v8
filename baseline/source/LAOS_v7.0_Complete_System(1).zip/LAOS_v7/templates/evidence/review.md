# Review

Reviewer: <IDENTITY_OR_FRESH_CONTEXT>
Verdict: PASS / PASS_WITH_NON_BLOCKERS / FAIL
Scope reviewed: <SCOPE>
Checks rerun: <CHECKS>
Findings: <FINDINGS>
