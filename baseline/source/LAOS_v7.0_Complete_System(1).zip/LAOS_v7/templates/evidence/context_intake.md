# Context Intake

Task: <TASK-ID>
Requirements: <REQ-IDS>
Sources inspected: <SOURCES>
Current facts: <FACTS>
Unknowns: <UNKNOWNS>
