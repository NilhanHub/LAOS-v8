# Lead AI Compilation Checklist

- [ ] Engagement mode is correct.
- [ ] Current repository was inspected when access exists.
- [ ] Requirements and invariants have stable IDs.
- [ ] Existing working behavior and protected areas are recorded.
- [ ] Material unknowns are explicit.
- [ ] Tasks are substantial, bounded, dependent, and traceable.
- [ ] Commands are real or an explicit reconciliation/escalation path exists.
- [ ] Failure paths and evidence are defined.
- [ ] External effects have authorization and rollback fields.
- [ ] Generated pack passes doctor and lint.
- [ ] One verified project ZIP is delivered.
