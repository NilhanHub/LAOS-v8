# App Intelligence completion checklist

A return ZIP is not complete merely because all required filenames exist.

- Repository root, commit, branch, dirty state, remotes, branches, tags, submodules, LFS and workspace structure are current.
- Every included source file has path, size and hash; every exclusion has a reason.
- No secrets, private keys, environment-file contents, production data or credentials are included.
- Runtime, package-manager, lockfile, tool and environment-variable-name baselines are recorded.
- Install, build, run, lint, type-check, test and smoke commands are classified as verified, failed, unavailable or obsolete.
- Architecture and data flow are understandable to a lead AI that has not seen the repository.
- Feature, screen, API, data, authorization, integration, deployment and test inventories are complete or explicitly bounded.
- Previous-agent claims are reconciled against current evidence.
- Working behaviour and fragile areas that must be preserved are explicit.
- Every unknown explains why it is unknown and what access or action would resolve it.
- The safe next task, last known good baseline and material risks are explicit.
- Evidence index entries resolve to real, non-empty, current files.
- Validation passes; final ZIP extracts and matches its internal manifest.
