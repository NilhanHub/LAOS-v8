# New-build compilation checklist

- Product purpose, users, roles, permissions and state-sharing model are explicit.
- Major user journeys include success, validation and failure behaviour.
- Data model, uniqueness, lifecycle, migrations, privacy and retention are explicit.
- UI inventory and all important states are explicit.
- Integrations are real contracts, not names or intentions.
- Security, quality budgets, operations, deployment and rollback are explicit or clearly out of scope.
- Non-goals prevent scope drift.
- Architecture decisions record reasons and consequences.
- Every MUST requirement has observable acceptance and task coverage.
- Tasks are bounded vertical slices with exact checks, evidence, review and stop conditions.
- No unresolved implementation placeholders remain.
- Compilation audit and runtime doctor pass before delivery.
