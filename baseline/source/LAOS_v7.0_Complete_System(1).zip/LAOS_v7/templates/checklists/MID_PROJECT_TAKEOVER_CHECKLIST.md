# Mid-Project Takeover Checklist

- [ ] Root, branch, commit, and dirty state are verified.
- [ ] Untracked and uncommitted work is understood.
- [ ] Previous claims are classified against current evidence.
- [ ] Baseline commands and tests are run or bounded.
- [ ] Working, partial, broken, missing, and unverified behavior is mapped.
- [ ] Deployment and external-system state is recorded.
- [ ] Protected areas and rollback are defined.
- [ ] The next safe task is unambiguous.
