# Continuation-pack compilation checklist

- Validate the App Intelligence Return ZIP before reading it as authority.
- Confirm project ID, capture ID, parent pack ID, Git commit and repository fingerprint.
- Separate captured facts, owner approvals, lead-AI decisions and unresolved unknowns.
- Classify each requested requirement as already satisfied, partial, missing, contradicted or unknown.
- Import the captured preservation, regression, integration, deployment and risk boundaries.
- Define a stale-capture stop gate before product-code work.
- Use exact verified commands from the capture, or create an explicit reconciliation task.
- Map every MUST requirement to tasks, checks and evidence.
- Include migration, rollback and side-effect controls where relevant.
- Require fresh independent review for high-risk changes.
- Compile, run doctor, inspect the compilation audit, and deliver one self-contained implementation ZIP.
