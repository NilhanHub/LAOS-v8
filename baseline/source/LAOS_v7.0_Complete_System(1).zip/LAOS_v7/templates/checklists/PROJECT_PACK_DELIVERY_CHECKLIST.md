# Project Pack Delivery Checklist

- [ ] `START_HERE.md` is clear.
- [ ] The project pack is self-contained.
- [ ] Master LAOS ZIP is not required by the implementation agent.
- [ ] No secrets are included.
- [ ] Required templates and runtime are present.
- [ ] All JSON validates.
- [ ] Doctor passes in a clean extraction.
- [ ] ZIP extraction and snapshot equality pass.
- [ ] Final ZIP is not modified after verification.
