# Specification Amendment

Amendment ID: <AMD-ID>
Status: PROPOSED / APPROVED / REJECTED / SUPERSEDED
Requested change: <CHANGE>
Reason: <REASON>
Affected requirements/tasks/tests: <IDS>
Architecture/data/security/deployment impact: <IMPACT>
Migration or compatibility impact: <IMPACT>
Approval: <AUTHORITY_AND_DATE>
