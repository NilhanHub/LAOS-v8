# LAOS v7 template library

These templates are used by the lead AI and compilers. Nilhan normally does not fill them manually.

- `product_definition/` - new-build discovery and specification completeness.
- `requests/` - existing-app capture and continuation requests.
- `blueprints/` - implementation, repair, takeover and audit input shapes.
- `app_intelligence/` - structured feature, API, issue and evidence records.
- `intake/` - existing-project reconciliation and continuity.
- `evidence/` - task proof structures.
- `handoff/` - session and agent continuity.
- `amendments/` - controlled specification change.
- `reports/` - status and final-truth reporting.
- `checklists/` - compilation, capture, continuation and delivery gates.

A compiled implementation pack contains filled project truth plus relevant blank templates under `.laos/templates/`. A capture pack contains only the capture contract, safe runtime, schemas and return templates needed for the investigation.
