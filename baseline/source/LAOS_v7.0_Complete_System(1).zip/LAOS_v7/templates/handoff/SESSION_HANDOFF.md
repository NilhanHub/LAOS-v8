# Session Handoff

Project: <PROJECT>
Task/state: <TASK_AND_STATE>
Git: <BRANCH_AND_COMMIT>
Completed: <ITEMS>
Pending: <ITEMS>
Latest checks: <RESULTS>
Last error: <ERROR_OR_NONE>
Side effects: <STATES>
Exact resume action: <ACTION>
