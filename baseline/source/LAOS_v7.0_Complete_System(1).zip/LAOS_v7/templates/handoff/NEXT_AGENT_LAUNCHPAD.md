# Next Agent Launchpad

Read first: <FILES>
Current legal task: <TASK>
Do not repeat: <FAILED_APPROACHES>
Protected areas: <PATHS>
Immediate command: <COMMAND>
Stop/escalate if: <CONDITIONS>
