# New-build discovery worksheet

The lead AI completes this before compiling a new-build implementation pack. Unknowns may remain only when they are explicitly deferred and cannot change the implementation contract.

## Product
- Problem being solved:
- Primary users:
- Business value:
- Exact finish line:
- Explicit non-goals:

## Roles and state
- User roles:
- Permission boundaries:
- Shared state versus user-specific state:
- Tenant model, if any:

## Journeys
For each important journey: starting state, user actions, visible outcome, stored-data outcome, validation, failure path, persistence after refresh/restart, and permission boundary.

## Data
Entities, fields, relationships, uniqueness, validation, lifecycle, deletion/archive, retention, migrations, backups, audit history, and sample-data policy.

## Experience
Pages/screens, navigation, forms, tables, dialogs, loading, empty and error states, responsiveness, accessibility, visual references, and behaviour that must not be improvised.

## Integrations
Provider, real purpose, authentication, credential names, operations, request/response shape, timeouts, rate limits, retries, duplicate handling, sandbox/live boundary, failure behaviour, verification, and rollback.

## Quality and operations
Security, privacy, performance, reliability, browser/device support, logging, health checks, monitoring, backups, deployment, rollback, environment separation, and final acceptance.
