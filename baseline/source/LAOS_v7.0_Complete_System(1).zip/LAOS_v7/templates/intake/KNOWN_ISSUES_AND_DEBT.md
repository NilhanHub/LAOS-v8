# Known Issues and Technical Debt

| ID | Issue | Impact | Evidence | In current scope? |
|---|---|---|---|---|
| DEBT-001 | <ISSUE> | <IMPACT> | <REFERENCE> | YES / NO |
