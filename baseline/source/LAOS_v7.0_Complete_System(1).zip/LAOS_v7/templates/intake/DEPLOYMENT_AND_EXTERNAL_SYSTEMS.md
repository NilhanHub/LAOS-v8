# Deployment and External Systems

## Current deployment
- Environment: <ENVIRONMENT>
- Revision/version: <VERIFIED_REVISION>
- Repository match: <MATCH_OR_MISMATCH>

## External systems
| System | Purpose | Read/write boundary | Authorization | Rollback/compensation |
|---|---|---|---|---|
| <SYSTEM> | <PURPOSE> | <BOUNDARY> | <STATUS> | <METHOD> |
