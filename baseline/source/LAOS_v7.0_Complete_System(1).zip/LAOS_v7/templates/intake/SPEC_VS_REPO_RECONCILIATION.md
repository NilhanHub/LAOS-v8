# Specification vs Repository Reconciliation

| Requirement | Repository status | Evidence | Disposition |
|---|---|---|---|
| <REQ-ID> | VERIFIED / PARTIAL / MISSING / CONTRADICTED / UNKNOWN | <REFERENCE> | <TASK_OR_AMENDMENT> |
