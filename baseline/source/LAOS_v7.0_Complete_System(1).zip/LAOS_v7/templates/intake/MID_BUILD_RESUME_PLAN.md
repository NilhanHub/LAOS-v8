# Mid-Build Resume Plan

## Current safe state
<CURRENT_STATE>

## Current legal task
<TASK_ID_AND_STATE>

## Completed work
- <ITEM_AND_EVIDENCE>

## Pending work
- <ITEM>

## Failed approaches not to repeat
- <APPROACH_AND_FAILURE_SIGNATURE>

## Side effects already executed
- <OPERATION_AND_STATE>

## Exact next action
<COMMAND_OR_STEP>
