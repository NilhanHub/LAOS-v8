# Command and Test Baseline

| Purpose | Exact command | Result | Evidence |
|---|---|---|---|
| Install/setup | <COMMAND> | <RESULT> | <PATH> |
| Build | <COMMAND> | <RESULT> | <PATH> |
| Unit/integration tests | <COMMAND> | <RESULT> | <PATH> |
| End-to-end/smoke | <COMMAND> | <RESULT> | <PATH> |

Unavailable tools and exact boundaries:
- <BOUNDARY>
