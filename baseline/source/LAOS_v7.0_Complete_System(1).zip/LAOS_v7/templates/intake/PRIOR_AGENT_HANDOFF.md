# Prior Agent Handoff Reconciliation

| Prior claim | Current classification | Current evidence | Action |
|---|---|---|---|
| <CLAIM> | VERIFIED_CURRENT / SUPPORTED_NOT_RERUN / STALE / CONTRADICTED / UNVERIFIED | <REFERENCE> | <ACTION> |
