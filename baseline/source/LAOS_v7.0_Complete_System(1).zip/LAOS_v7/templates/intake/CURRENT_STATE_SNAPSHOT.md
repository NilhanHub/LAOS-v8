# Current State Snapshot

## Working
- <VERIFIED_WORKING_BEHAVIOR>

## Partial
- <PARTIAL_BEHAVIOR_AND_BOUNDARY>

## Broken
- <REPRODUCED_FAILURE>

## Missing
- <REQUIRED_BUT_ABSENT>

## Unverified
- <CLAIM_NOT_YET_PROVED>
