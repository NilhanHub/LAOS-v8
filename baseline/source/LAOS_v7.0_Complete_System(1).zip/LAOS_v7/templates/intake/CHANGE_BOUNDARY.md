# Change Boundary

## Allowed areas
- <PATH_OR_SYSTEM>

## Protected areas
- <PATH_OR_SYSTEM_AND_REASON>

## Existing behavior to preserve
- <BEHAVIOR_AND_REGRESSION_PROOF>

## Prohibited scope expansion
- <NON_GOAL>
