# Existing Project Intake

## Engagement mode
<MODE>

## Repository access
<HOW_CURRENT_SOURCE_IS_ACCESSED>

## Approved objective
<OBJECTIVE>

## Known current facts
- <FACT_AND_SOURCE>

## Claims requiring verification
- <CLAIM>

## Material unknowns
- <UNKNOWN_AND_WHY_IT_MATTERS>
