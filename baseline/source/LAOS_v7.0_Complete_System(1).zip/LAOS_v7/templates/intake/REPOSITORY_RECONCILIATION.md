# Repository Reconciliation

## Root, branch, and commit
- Root: <RESOLVED_ROOT>
- Branch: <BRANCH>
- Commit: <FULL_HASH>
- Dirty state: <CLEAN_OR_EXPLAINED>

## Entry points and architecture
<VERIFIED_DESCRIPTION>

## Uncommitted and untracked work
<INVENTORY_AND_DISPOSITION>

## Discrepancies
<REPO_VS_HANDOFF_OR_SPEC>
