# Project Status Report

Acceptance state: <STATE>
Closed tasks: <IDS>
Active task: <ID_AND_STATE>
Blocked/escalated: <IDS_AND_REASONS>
Checks: <SUMMARY>
Side effects: <SUMMARY>
Risks: <SUMMARY>
Next legal action: <ACTION>
