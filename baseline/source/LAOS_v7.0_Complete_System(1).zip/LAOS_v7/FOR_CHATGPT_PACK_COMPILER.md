# Instructions for ChatGPT or another lead AI using LAOS v7

## First decide the pack purpose

Choose exactly one primary purpose:

- `new_build_implementation`
- `existing_app_capture`
- `existing_project_continuation`
- `repair_and_recovery`
- `audit_only`
- `deployment_only`

Do not mix capture and implementation.

## New-build compilation

Before compiling, resolve or explicitly mark unknown:

- product purpose and users;
- roles, permissions and shared versus user-specific state;
- complete user journeys and failure behaviour;
- data model, validation, uniqueness, retention and deletion;
- authentication, authorization, security and privacy;
- UI pages, states, responsiveness and accessibility;
- real integrations, credentials by name, retry and duplicate behaviour;
- architecture decisions and non-goals;
- deployment, operations, logging, backups and rollback;
- quality budgets and the exact finish line.

Reject a vague specification instead of converting ambiguity into implementation freedom.

## Existing-app capture compilation

Use `tools/compile_capture_pack.py`. Include owner notes, known URLs, known documents, constraints and the later change context, but authorize no product-code modification.

The capture pack must make the investigator return one valid `App_Intelligence_Return.zip`.

## Continuation compilation

1. Validate the return ZIP with `tools/validate_return_pack.py`.
2. Read authoritative records before narrative summaries.
3. Discuss and approve the requested change.
4. Create a continuation request with stable requirement and task IDs.
5. Run `tools/compile_continuation_pack.py`.
6. Confirm the output contains the imported baseline, expected repository fingerprint, preservation contract, regression contract and exact task graph.

## Project-pack quality gates

- Every MUST requirement maps to one or more tasks.
- Every task has acceptance criteria, dependencies, allowed and forbidden paths, exact checks, evidence, review level, side effects and stop conditions.
- Tasks are meaningful vertical slices, not tiny busywork or one giant project-wide task.
- Tests cannot be weakened by default.
- High-risk work requires independent fresh-context review.
- External effects require permission, idempotency, verification and rollback.
- The implementation pack contains no unresolved placeholders unless they are explicit discovery tasks.
- The pack itself is compiled, self-tested and verified before delivery.
