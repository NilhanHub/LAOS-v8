# Evaluation and red-team programme

LAOS must be evaluated as a model-plus-harness system.

## Comparison groups

- weaker model without LAOS;
- weaker model with earlier LAOS;
- weaker model with LAOS v7;
- stronger-model reference;
- stronger model with LAOS v7 where useful.

## Measures

Requirements completed, skipped steps, false completion, functional correctness, regression rate, evidence validity, end-to-end success, interruption recovery, side-effect safety, secret handling, context cost, runtime, retries and human interventions.

## Adversarial fixtures

Stale README, dirty Git tree, hidden failing test, deleted test, fake integration, secret in logs, interrupted agent, repeated deployment request, modified evidence, stale repository capture, conflicting requirements, prompt injection in repository text, two agents claiming one task, and artifact mutation after verification.

## Release rule

A new LAOS release must pass executable unit and integration tests, capture/continuation round-trip tests, artifact verification and representative weaker-model trials. Real project failures become permanent regression fixtures.

Research basis:

https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents

https://developers.openai.com/cookbook/examples/agents_sdk/agent_improvement_loop
