# Existing-project takeover

The preferred v7 takeover path is:

`capture pack -> App Intelligence Return ZIP -> validation -> continuation pack`

A direct takeover implementation pack is allowed only when the lead AI already has an equivalent current, evidence-backed repository baseline. Otherwise, create a capture pack first.

The continuation pack must include capture provenance, expected repository fingerprint, expected Git commit, preservation contract, regression contract, imported baseline and a freshness gate. Material repository drift requires reconciliation before code changes.
