# Runtime enforcement

## Task state machine

`DEFINED -> READY -> CLAIMED -> IN_PROGRESS -> IMPLEMENTED -> TESTED -> EVIDENCED -> REVIEWED -> CLOSED`

Special states include `BLOCKED`, `FAILED`, `NEEDS_REPAIR`, `NEEDS_ESCALATION`, `DEFERRED` and `SUPERSEDED`.

## Important v7 enforcement

- per-task source baseline at claim time;
- path-scope and forbidden-file checks against the task baseline;
- test-file modification blocked unless explicitly allowed;
- exact check commands with no silent substitution;
- command timeout, output limits and environment-name filtering;
- check results tied to the current source fingerprint;
- registered evidence hashes and source freshness rechecked at closure;
- independent reviewer enforcement;
- lock leases, heartbeats and stale-lock recovery;
- restorable workspace checkpoints and dry-run recovery;
- unique idempotency keys and ordered side-effect lifecycle;
- repeated identical failure detection and mandatory escalation;
- specification amendment proposal and independent approval;
- final acceptance generated from current machine state;
- hash-chained event ledger and event anchor.

A weaker model may propose progress; the runtime decides whether the gates pass.
