# Known limits and human approvals

LAOS cannot guarantee zero defects, manufacture missing credentials, inspect an unavailable production system, prove a UI it cannot open, or make a weak model reason identically to a frontier model.

Human or stronger-model approval remains mandatory for materially ambiguous product decisions, irreversible data operations, production credentials, billing, payroll or financial correctness, authentication and authorization architecture, sensitive personal data, legal/compliance decisions, destructive migration, domain/DNS transfer, and acceptance of a repository that materially differs from its captured baseline.

The correct LAOS response to an unavailable proof path is an explicit boundary, blocker or escalation - never a confident substitute.
