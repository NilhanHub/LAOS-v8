# Existing-app capture system

## Purpose

The capture system creates a reliable information bridge between a repository and a lead AI that has not personally explored every file and running environment.

## Automatic capture

`capture_runtime.py init` safely records Git identity, file hashes, a filtered source snapshot, environment tool versions, package manifests, candidate commands, test files, UI/API/data/integration/deployment signals and possible secret locations without copying secret values.

Automatic heuristics are only leads. The investigator must verify, correct and complete them.

## Human/agent investigation

The investigator maps architecture, features, user journeys, UI screens, APIs, data and migrations, authentication and authorization, integrations, tests, deployment, dependencies, prior claims, issues, protected behaviour and unknowns. Evidence belongs under the return working directory's `Evidence/` folder.

## Capture-only boundary

Product code, behaviour, deployment and data must not be changed. If a safe test itself modifies data or external state, it requires prior authorization and must be recorded as a side effect. The normal capture pack should prefer read-only and isolated test actions.

## Return validation

Finalization rejects unresolved placeholders, missing required records, secret-like content, invalid JSON, insufficient narrative, missing feature inventory, unsafe ZIP paths and snapshot mismatch. A partial or blocked pack is valid only when exact limitations are listed.
