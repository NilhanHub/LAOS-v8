# Continuation compilation system

The continuation compiler consumes a validated App Intelligence Return ZIP and an approved change request.

It imports the captured repository identity, fingerprint, architecture, features, commands, tests, deployment, integrations, issues, protected areas and unknowns. It does not blindly accept these as timeless truth; it packages them as a captured baseline.

The resulting implementation pack contains:

- expected repository fingerprint and Git commit;
- capture provenance and validation report;
- preservation and regression contracts;
- current working and broken feature context;
- exact requested requirements and task graph;
- a freshness gate before product work;
- normal LAOS runtime, evidence, review and side-effect enforcement.

If the repository changed after capture, the agent must reconcile. It must not force an old plan onto a newer codebase.
