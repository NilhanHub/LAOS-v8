# Migration from v4.1, v5 or v6 to LAOS v7

1. Preserve existing specifications, evidence and Git state.
2. Do not mark old work complete merely because an earlier report says PASS.
3. For an existing repository, compile a v7 capture pack and create a validated App Intelligence baseline.
4. Convert approved requirements to stable IDs and reconcile them against current feature status.
5. Compile a v7 continuation pack with provenance and freshness gate.
6. Map old evidence only when it remains current and reproducible.
7. Archive old harness files that conflict with v7 rather than silently merging instruction systems.
8. Run v7 doctor, compilation audit and baseline verification before implementation.

Historical v4.1, v5 and v6 guides remain under `legacy/` for provenance, not operating authority.
