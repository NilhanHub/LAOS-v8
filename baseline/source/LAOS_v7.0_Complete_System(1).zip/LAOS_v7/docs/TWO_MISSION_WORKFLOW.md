# The two-mission LAOS workflow

## Mission A - create a new application

`Master LAOS ZIP -> approved product discussion -> compiled new-build implementation ZIP -> weaker agent builds -> LAOS verifies -> final truth report`

The lead AI must resolve product ambiguity before compiling. The new-build pack contains stable requirements, user roles, permission boundaries, journeys, data rules, UI contract, integrations, security, quality budgets, operational requirements, non-goals, architecture decisions, task graph, exact checks, evidence requirements, runtime and agent adapter.

## Mission B - enter an existing application safely

`Master LAOS ZIP -> capture pack -> weaker capture investigator -> App Intelligence Return ZIP -> lead-AI validation -> approved change discussion -> continuation pack -> weaker implementation agent -> verification -> refreshed app intelligence`

The capture agent's job is to understand, not change. This separation matters because premature repair destroys evidence, mixes old and new state, and forces the lead AI to trust a weaker agent's interpretation of what it changed.

## Why the return ZIP is a first-class product

An existing app may contain:

- uncommitted or untracked work;
- stale specifications and commands;
- disconnected, duplicated or simulated screens;
- migrations that do not match production;
- live deployments from another commit;
- hidden external services and credentials;
- tests that pass only because important paths are skipped;
- previous-agent reports that sound complete but are not current.

The App Intelligence Return ZIP records the current truth with direct evidence, explicit unknowns and a repository fingerprint. The continuation compiler imports this material and refuses to treat old capture information as current when the repository materially changed.

## The operating loop

For long-lived apps, the ideal cycle is:

`capture -> understand -> plan -> implement -> verify -> recapture or refresh baseline`

A major implementation round should leave the next agent with a newer, smaller, more accurate understanding burden than the previous round.
