# Template selection guide

- New application: `templates/blueprints/new_project_blueprint.template.json` and `templates/product_definition/NEW_BUILD_DISCOVERY_WORKSHEET.md`.
- Existing app not yet understood: `templates/requests/existing_app_capture_request.template.json`.
- Existing app with validated return ZIP: `templates/requests/continuation_request.template.json`.
- Narrow feature with equivalent baseline already available: `templates/blueprints/existing_project_feature.template.json`.
- Repair: `templates/blueprints/repair_and_recovery.template.json`.
- Audit: `templates/blueprints/audit_only.template.json`.
- Takeover: prefer capture then continuation; direct takeover template is a controlled fallback.

Nilhan normally does not fill these. The lead AI uses them to compile the project pack.
