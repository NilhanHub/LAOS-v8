# Research basis for LAOS v7

LAOS is framework-neutral, but its design incorporates current primary-source patterns:

- Incremental progress, machine-readable feature state, durable handoffs and end-to-end testing for long-running coding agents: https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents
- Harness design for long-running application development: https://www.anthropic.com/engineering/harness-design-long-running-apps
- Context engineering for long-horizon agents: https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
- Model-plus-harness evaluation: https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- Parallel-agent isolation and task locks: https://www.anthropic.com/engineering/building-c-compiler
- Agent containment and blast-radius limits: https://www.anthropic.com/engineering/how-we-contain-claude
- OpenAI Agents SDK orchestration and tracing: https://developers.openai.com/api/docs/guides/agents
- Separation of orchestration from stateful sandbox execution: https://developers.openai.com/api/docs/guides/agents/sandboxes
- Trace/evaluation improvement loops: https://developers.openai.com/cookbook/examples/agents_sdk/agent_improvement_loop
- Durable checkpoints and persistence: https://docs.langchain.com/oss/python/langgraph/persistence
- Durable human approvals and interrupts: https://docs.langchain.com/oss/python/langgraph/interrupts
- Idempotent external activities and at-least-once execution: https://docs.temporal.io/activity-definition
- Pre-production retry and replay testing: https://docs.temporal.io/best-practices/pre-production-testing

LAOS does not require these frameworks. It implements portable equivalents where practical and provides honest boundaries where a generic desktop agent cannot enforce a platform-level guarantee.
