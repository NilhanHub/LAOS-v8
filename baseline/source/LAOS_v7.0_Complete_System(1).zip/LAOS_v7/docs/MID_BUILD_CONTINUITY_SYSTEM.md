# Mid-build continuity system

Mid-build continuity is maintained through four connected records:

1. App Intelligence baseline - what the existing application was at capture time.
2. LAOS task/event state - what the current implementation round attempted and verified.
3. Evidence and checkpoints - reproducible proof and recoverable source state.
4. Refreshed baseline - what the application became after accepted work.

The next agent should begin from current machine state and verified evidence, not a long chat transcript. Major changes should trigger a refreshed capture or a formal reconciliation task.
