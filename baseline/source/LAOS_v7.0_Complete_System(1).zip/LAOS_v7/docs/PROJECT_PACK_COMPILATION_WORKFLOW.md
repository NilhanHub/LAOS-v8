# Project-pack compilation workflow

## New build

1. Complete the product discovery worksheet.
2. Build a real blueprint with stable IDs and exact commands.
3. Run `python tools/compile_project_pack.py blueprint.json output_directory`.
4. Inspect `PACK_COMPILATION_AUDIT.json`.
5. Run `python output_directory/.laos/runtime/laos.py --root output_directory doctor`.
6. Package the output from clean staging and verify it.

## Existing app

1. Compile a capture pack.
2. Receive and validate `App_Intelligence_Return.zip`.
3. Approve the change request.
4. Compile the continuation pack.
5. Confirm capture provenance and repository fingerprint.
6. Run doctor and package one implementation ZIP.
