# New-build compilation system

## Product completeness gate

A new-build pack must not be generated merely because a feature list exists. The compiler inputs should cover product purpose, users, roles, journeys, data, integrations, security, UI, operations, deployment, non-goals and acceptance. Missing information must become a discovery task or explicit owner decision, not a silent agent choice.

## Requirement system

Use stable IDs for functional requirements, business rules, invariants, security, privacy, non-functional requirements, journeys, data contracts, decisions, risks, tests, evidence and tasks. The human-readable master specification and machine-readable JSON files must agree.

## Task graph

Tasks should be substantial bounded vertical slices. Each task declares dependencies, permissions, file scope, preservation obligations, exact checks, evidence, review level, side effects, rollback and stop conditions.

## First working slice

Prefer an early thin vertical slice that proves the chosen architecture end to end: real input, validation, storage, retrieval, UI and deployment path where applicable. Do not build a wide collection of disconnected screens first.

## Completion

The project is complete only when all mandatory tasks close through the runtime, all evidence remains fresh for the final source, external effects reconcile, independent review passes, final acceptance is generated, and known limitations match the approved finish line.
