# App Intelligence Return standard

The return ZIP is a current-state product, not a loose handoff note.

## Required records

- return manifest and identity chain;
- executive summary;
- Git and repository identity;
- complete file manifest and safe source snapshot;
- environment and tool versions;
- architecture and data flow;
- feature-status matrix;
- UI and route inventory;
- API inventory;
- data, storage and migration map;
- authentication and authorization map;
- integration inventory;
- command and test baseline;
- deployment truth;
- dependency, licence and vulnerability report;
- prior-agent claim reconciliation;
- known issues and technical debt;
- protected areas and working behaviour;
- assumptions, unknowns and access limitations;
- recommended safe resume plan;
- evidence index, content manifest and finalization report.

## Truth labels

Facts should be labelled as directly verified, supported but not rerun, inferred, reported, unknown or contradicted. A polished statement without proof is not upgraded to a fact.

## Freshness identity

The pack records project ID, capture ID, parent pack ID, Git commit, dirty state and repository-content fingerprint. A continuation pack must stop when its current repository materially differs from the captured baseline unless a reconciliation task accepts the new state with evidence.
