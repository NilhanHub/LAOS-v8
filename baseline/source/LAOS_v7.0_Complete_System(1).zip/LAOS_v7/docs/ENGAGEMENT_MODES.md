# LAOS v7 engagement and pack purposes

LAOS separates **what kind of project situation exists** from **what pack is being created**.

## Pack purposes

- `new_build_implementation` - build a new application from an approved specification.
- `existing_app_capture` - inspect and package an existing app without product-code changes.
- `existing_project_continuation` - continue or extend a validated captured app.
- `repair_implementation` - reproduce, contain and repair an approved defect.
- `audit_execution` - investigate and report without unauthorized fixes.
- `deployment_execution` - perform a separately approved deployment with verification and rollback.

## Implementation engagement modes

- `new_project`
- `existing_project_feature`
- `existing_project_takeover`
- `repair_and_recovery`
- `audit_only`
- `deployment_only`

Capture is compiled by its own capture compiler and is intentionally not mixed into the implementation runtime.
