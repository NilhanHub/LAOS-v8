# LAOS v7 contents map

## User and lead-AI guidance

- `START_HERE_FOR_NILHAN.md`
- `FOR_CHATGPT_PACK_COMPILER.md`
- `HOW_TO_USE_LAOS_IN_PLAIN_ENGLISH.md`
- `WHAT_TO_UPLOAD_AND_WHEN.md`
- `docs/TWO_MISSION_WORKFLOW.md`

## New-build and implementation system

- `tools/compile_project_pack.py`
- `laos_runtime.py`
- `schemas/`
- `templates/blueprints/`
- `project_pack_assets/roles/`
- `project_pack_assets/skills/`
- `project_pack_assets/adapters/`

## Existing-app intelligence system

- `tools/compile_capture_pack.py`
- `tools/capture_runtime.py`
- `tools/validate_return_pack.py`
- `tools/compile_continuation_pack.py`
- `schemas/app_intelligence/`
- `templates/app_intelligence/`

## Verification and evaluation

- `tests/test_laos_v7.py`
- `tools/run_all_tests.py`
- `tools/validate_master_release.py`
- `docs/EVALUATION_AND_RED_TEAM.md`
- `release_evidence/`

## Historical reference

Earlier v4.1, v5.0 and v6.0 documents are under `legacy/` and are not the operating authority for new packs.
