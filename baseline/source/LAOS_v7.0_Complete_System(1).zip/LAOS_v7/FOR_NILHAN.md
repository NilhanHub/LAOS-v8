# Start here, Nilhan

You keep **one master file**:

`LAOS_v7.0_Complete_System.zip`

That master ZIP enables me to prepare the correct pack for either of your two normal situations.

## Situation 1 - a new app

1. Upload the master LAOS ZIP to me.
2. Discuss the app with me until the product, users, journeys, data, security, UI, integrations, deployment and finish line are clear.
3. Say: **Create the complete new-build implementation pack according to LAOS.**
4. I give you one project-specific ZIP.
5. Upload only that project-specific ZIP to the weaker agent.
6. Tell it to read `START_HERE.md` and implement the complete pack.

## Situation 2 - an existing or mid-build app

This normally has two separate weaker-agent assignments.

### Assignment A: understand and package the app

1. Upload the master LAOS ZIP to me.
2. Tell me what you know about the app and what you may later want changed.
3. Say: **Create the LAOS existing-app capture pack.**
4. I give you one capture ZIP.
5. Give that capture ZIP to a weaker agent that can access the actual repository.
6. The agent does not repair or modify the app. It investigates and returns one file: `App_Intelligence_Return.zip`.

### Assignment B: continue, repair or extend the app

1. Upload `App_Intelligence_Return.zip` to me, together with the master LAOS ZIP if it is not already available in the conversation.
2. Discuss the requested change with me.
3. Say: **Create the continuation implementation pack according to LAOS.**
4. I validate the returned app intelligence and create one continuation ZIP.
5. Give only that continuation ZIP to the weaker implementation agent.

## What not to do

- Do not give the master LAOS ZIP directly to a weaker agent and expect it to guess the app assignment.
- Do not combine capture and implementation in one existing-app assignment.
- Do not manually merge LAOS files.
- Do not upload separate audit files during normal use; the single master ZIP contains the complete system.
