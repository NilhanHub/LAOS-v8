import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

DIST = Path(__file__).resolve().parents[1]
COMPILER = DIST / "tools" / "compile_project_pack.py"
CAPTURE_COMPILER = DIST / "tools" / "compile_capture_pack.py"
CAPTURE_RUNTIME = DIST / "tools" / "capture_runtime.py"
RETURN_VALIDATOR = DIST / "tools" / "validate_return_pack.py"
CONTINUATION_COMPILER = DIST / "tools" / "compile_continuation_pack.py"
spec = importlib.util.spec_from_file_location("laos_runtime", DIST / "laos_runtime.py")
laos = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(laos)


def run(args, cwd=None, timeout=60):
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, timeout=timeout)


class LaosV7RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory(prefix="laos_v7_test_")
        self.base = Path(self.td.name)
        self.project = self.base / "project"
        bp = {
            "engagement_mode": "new_project",
            "include_reconciliation_task": False,
            "project_name": "Runtime Test Project",
            "project_summary": "Exercise LAOS v7 gates.",
            "risk_level": "MODERATE",
            "project_definition": {"problem": "Verify the LAOS runtime", "primary_users": ["test operator"], "finish_line": "All lifecycle gates pass"},
            "user_journeys": [{"id": "FLOW-001", "name": "Complete a verified task", "steps": ["claim", "implement", "test", "evidence", "review", "close"]}],
            "acceptance_model": {"required": "All mandatory tasks close through the runtime"},
            "deployment_contract": {"scope": "not applicable to runtime fixture"},
            "requirements": [{"id": "REQ-001", "text": "Complete the verified task.", "acceptance": ["Task closes through all gates"]}],
            "tasks": [{
                "id": "TASK-001", "title": "Verified task", "description": "Exercise lifecycle gates.",
                "requirements": ["REQ-001"], "dependencies": [],
                "allowed_paths": ["src/**", "notes/**", "Evidence/**"],
                "forbidden_paths": ["forbidden/**", ".laos/runtime/**", "spec/**"],
                "acceptance_criteria": ["Check passes", "Evidence exists", "Review passes"],
                "checks": [{"id": "CHECK-OK", "command": f'"{sys.executable}" -c "print(123)"', "stage": "TESTED", "required": True}],
                "evidence_required": [
                    {"path": "Evidence/TASK-001/plan.md", "stage": "EVIDENCED", "min_bytes": 20},
                    {"path": "Evidence/TASK-001/tests.md", "stage": "EVIDENCED", "min_bytes": 20},
                    {"path": "Evidence/TASK-001/review.md", "stage": "REVIEWED", "min_bytes": 20}
                ],
                "review_required": True,
                "side_effects_required": ["op-1"]
            }]
        }
        bp_path = self.base / "blueprint.json"
        bp_path.write_text(json.dumps(bp), encoding="utf-8")
        cp = run([sys.executable, str(COMPILER), str(bp_path), str(self.project)])
        self.assertEqual(cp.returncode, 0, cp.stderr)
        for cmd in (["git", "init", "-q"], ["git", "config", "user.email", "test@example.com"], ["git", "config", "user.name", "Test"], ["git", "add", "."], ["git", "commit", "-qm", "initial"]):
            cp = run(cmd, cwd=self.project)
            self.assertEqual(cp.returncode, 0, cp.stderr)
        (self.project / "src").mkdir(exist_ok=True)
        (self.project / "src" / "feature.txt").write_text("initial\n", encoding="utf-8")
        run(["git", "add", "src/feature.txt"], cwd=self.project)
        run(["git", "commit", "-qm", "source baseline"], cwd=self.project)

    def tearDown(self):
        self.td.cleanup()

    def create_evidence(self):
        ev = self.project / "Evidence" / "TASK-001"
        ev.mkdir(parents=True, exist_ok=True)
        (ev / "plan.md").write_text("A sufficiently detailed implementation plan.\n", encoding="utf-8")
        (ev / "tests.md").write_text("The required check executed successfully.\n", encoding="utf-8")
        (ev / "review.md").write_text("Independent fresh reviewer verdict: PASS.\n", encoding="utf-8")

    def begin(self):
        laos.refresh_ready(self.project)
        laos.claim_task(self.project, "TASK-001", "builder")
        laos.start_task(self.project, "TASK-001", "builder")
        (self.project / "src" / "feature.txt").write_text("implemented\n", encoding="utf-8")
        laos.advance_task(self.project, "TASK-001", "IMPLEMENTED", "builder", None)

    def test_compile_and_doctor(self):
        result = laos.doctor(self.project)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["version"], "7.0.0")
        self.assertTrue((self.project / "PRODUCT_DEFINITION.md").exists())

    def test_full_lifecycle_and_finalize(self):
        self.begin(); self.create_evidence()
        rec = laos.run_check(self.project, "TASK-001", "CHECK-OK", "builder", None)
        self.assertEqual(rec["exit_code"], 0)
        laos.advance_task(self.project, "TASK-001", "TESTED", "builder", None)
        for name, kind in [("plan.md", "plan"), ("tests.md", "test")]:
            laos.record_evidence(self.project, "TASK-001", f"Evidence/TASK-001/{name}", kind, "builder")
        laos.advance_task(self.project, "TASK-001", "EVIDENCED", "builder", None)
        laos.record_review(self.project, "TASK-001", "PASS", "reviewer", "Evidence/TASK-001/review.md", None, "fresh-review-1")
        laos.advance_task(self.project, "TASK-001", "REVIEWED", "builder", None)
        laos.side_effect_transition(self.project, "TASK-001", "op-1", "PROPOSED", "builder", "External operation", "idempotent-1", None, "Compensate")
        for state in ["AUTHORIZED", "PREPARED", "EXECUTED", "EXTERNALLY_VERIFIED", "COMMITTED"]:
            laos.side_effect_transition(self.project, "TASK-001", "op-1", state, "builder", None, None, None, None)
        laos.advance_task(self.project, "TASK-001", "CLOSED", "builder", None)
        final = laos.finalize_project(self.project, "acceptance-agent")
        self.assertEqual(final["acceptance"], "ACCEPTED")
        self.assertTrue((self.project / "Evidence/LAOS_EVENT_ANCHOR.json").exists())

    def test_check_becomes_stale_after_source_change(self):
        self.begin(); self.create_evidence()
        laos.run_check(self.project, "TASK-001", "CHECK-OK", "builder", None)
        (self.project / "src" / "feature.txt").write_text("changed after test\n", encoding="utf-8")
        with self.assertRaises(laos.LaosError):
            laos.advance_task(self.project, "TASK-001", "TESTED", "builder", None)

    def test_evidence_mutation_detected(self):
        self.begin(); self.create_evidence()
        laos.run_check(self.project, "TASK-001", "CHECK-OK", "builder", None)
        laos.advance_task(self.project, "TASK-001", "TESTED", "builder", None)
        laos.record_evidence(self.project, "TASK-001", "Evidence/TASK-001/plan.md", "plan", "builder")
        laos.record_evidence(self.project, "TASK-001", "Evidence/TASK-001/tests.md", "test", "builder")
        (self.project / "Evidence/TASK-001/plan.md").write_text("tampered after recording\n", encoding="utf-8")
        with self.assertRaises(laos.LaosError):
            laos.advance_task(self.project, "TASK-001", "EVIDENCED", "builder", None)

    def test_reviewer_must_be_independent(self):
        self.begin(); self.create_evidence()
        with self.assertRaises(laos.LaosError):
            laos.record_review(self.project, "TASK-001", "PASS", "builder", "Evidence/TASK-001/review.md", None, "same-session")

    def test_test_file_change_blocked(self):
        self.begin()
        (self.project / "tests").mkdir()
        (self.project / "tests/test_feature.py").write_text("assert True\n", encoding="utf-8")
        with self.assertRaises(laos.LaosError):
            laos.validate_changed_files(self.project, json.loads((self.project / "work/task_graph.json").read_text())["tasks"][0], json.loads((self.project / ".laos/state/current_state.json").read_text())["task_states"]["TASK-001"])

    def test_checkpoint_and_recovery(self):
        self.begin()
        checkpoint = laos.checkpoint(self.project, "TASK-001", "builder", "stable")
        (self.project / "src/feature.txt").write_text("bad later state\n", encoding="utf-8")
        dry = laos.recover_checkpoint(self.project, str(checkpoint), "recovery", confirm=False)
        self.assertEqual(dry["status"], "DRY_RUN")
        result = laos.recover_checkpoint(self.project, str(checkpoint), "recovery", confirm=True)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual((self.project / "src/feature.txt").read_text(), "implemented\n")

    def test_idempotency_key_unique(self):
        self.begin()
        laos.side_effect_transition(self.project, "TASK-001", "op-1", "PROPOSED", "builder", "one", "same-key", None, "rollback")
        with self.assertRaises(laos.LaosError):
            laos.side_effect_transition(self.project, "TASK-001", "op-2", "PROPOSED", "builder", "two", "same-key", None, "rollback")

    def test_event_chain_detects_tamper(self):
        events = self.project / ".laos/state/events.jsonl"
        events.write_text(events.read_text(encoding="utf-8").replace("PACK_COMPILED", "PACK_CHANGED", 1), encoding="utf-8")
        self.assertEqual(laos.doctor(self.project)["status"], "FAIL")

    def test_artifact_lock_detects_mutation(self):
        src = self.project / "artifact_source"; src.mkdir(); (src / "a.txt").write_text("data", encoding="utf-8")
        artifact = self.project / "release.zip"
        laos.artifact_build(self.project, "artifact_source", "release.zip")
        result = laos.artifact_verify(self.project, "release.zip", "artifact_source", None)
        self.assertEqual(result["status"], "PASS")
        with artifact.open("ab") as f: f.write(b"mutation")
        self.assertEqual(laos.artifact_lock_check(artifact)["status"], "FAIL")


class LaosV7CaptureTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory(prefix="laos_capture_test_")
        self.base = Path(self.td.name)
        self.repo = self.base / "repo"; self.repo.mkdir()
        (self.repo / "src").mkdir()
        (self.repo / "src/app.py").write_text("from fastapi import FastAPI\napp=FastAPI()\n@app.get('/health')\ndef health(): return {'ok':True}\n", encoding="utf-8")
        (self.repo / "tests").mkdir(); (self.repo / "tests/test_app.py").write_text("def test_ok(): assert True\n", encoding="utf-8")
        (self.repo / "requirements.txt").write_text("fastapi==1.0\n", encoding="utf-8")
        (self.repo / ".env").write_text("API_KEY=supersecretvalue123456\n", encoding="utf-8")
        for cmd in (["git", "init", "-q"], ["git", "config", "user.email", "test@example.com"], ["git", "config", "user.name", "Test"], ["git", "add", "src", "tests", "requirements.txt"], ["git", "commit", "-qm", "initial"]):
            cp = run(cmd, cwd=self.repo); self.assertEqual(cp.returncode, 0, cp.stderr)
        request = {"project_name": "Captured App", "project_id": "project-1", "include_safe_source_snapshot": True, "max_snapshot_total_bytes": 10000000}
        self.request = self.base / "capture_request.json"; self.request.write_text(json.dumps(request), encoding="utf-8")
        self.capture_pack = self.base / "capture_pack"
        cp = run([sys.executable, str(CAPTURE_COMPILER), str(self.request), str(self.capture_pack)])
        self.assertEqual(cp.returncode, 0, cp.stderr)

    def tearDown(self): self.td.cleanup()

    def complete_working(self, working: Path):
        for name in ["PROJECT_EXECUTIVE_SUMMARY.md", "ARCHITECTURE_MAP.md", "AUTHORIZATION_MAP.md", "RECOMMENDED_RESUME_PLAN.md"]:
            text=(working/name).read_text(encoding="utf-8").replace("TO_BE_COMPLETED", "Verified information from direct repository inspection with explicit evidence boundaries. This section is intentionally detailed enough to guide the next implementation pack.")
            (working/name).write_text(text, encoding="utf-8")
        manifest=json.loads((working/"APP_INTELLIGENCE_MANIFEST.json").read_text()); manifest["completion_state"]="COMPLETE"; (working/"APP_INTELLIGENCE_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
        features=json.loads((working/"FEATURE_STATUS_MATRIX.json").read_text()); features["features"]=[{"id":"FEATURE-001","name":"Health API","status":"WORKING_AND_VERIFIED","evidence":["Evidence/health.txt"]}]; features["inventory_complete"]=True; (working/"FEATURE_STATUS_MATRIX.json").write_text(json.dumps(features,indent=2)+"\n")
        for fname,key in [("UI_INVENTORY.json","inventory_complete"),("API_INVENTORY.json","inventory_complete"),("DATA_AND_MIGRATION_MAP.json","inventory_complete"),("INTEGRATIONS_INVENTORY.json","inventory_complete"),("DEPLOYMENT_TRUTH.json","inventory_complete"),("KNOWN_ISSUES.json","inventory_complete"),("PROTECTED_AREAS.json","inventory_complete"),("ASSUMPTIONS_AND_UNKNOWNS.json","inventory_complete")]:
            data=json.loads((working/fname).read_text()); data[key]=True
            # Remove automatic placeholder strings from heuristic items.
            raw=json.dumps(data).replace("TO_BE_EXTRACTED","UNKNOWN").replace("TO_BE_VERIFIED","UNKNOWN")
            (working/fname).write_text(json.dumps(json.loads(raw),indent=2)+"\n")
        test=json.loads((working/"TEST_BASELINE.json").read_text()); test["baseline_complete"]=True; test["executions"]=[{"command":"python -m pytest","status":"NOT_RUN","reason":"pytest unavailable in fixture"}]; (working/"TEST_BASELINE.json").write_text(json.dumps(test,indent=2)+"\n")
        prior=json.loads((working/"PRIOR_AGENT_CLAIMS.json").read_text()); prior["reconciliation_complete"]=True; (working/"PRIOR_AGENT_CLAIMS.json").write_text(json.dumps(prior,indent=2)+"\n")
        dep=json.loads((working/"DEPENDENCY_AND_LICENSE_REPORT.json").read_text()); dep["license_analysis_complete"]=True; dep["vulnerability_analysis_complete"]=True; (working/"DEPENDENCY_AND_LICENSE_REPORT.json").write_text(json.dumps(dep,indent=2)+"\n")
        evidence=working/"Evidence"; evidence.mkdir(exist_ok=True); (evidence/"health.txt").write_text("Health route verified from source and repository evidence.\n",encoding="utf-8")

    def test_capture_finalize_validate_and_continuation(self):
        working=self.repo/"App_Intelligence_Working"
        cp=run([sys.executable,str(CAPTURE_RUNTIME),"init","--repo",str(self.repo),"--working",str(working),"--contract",str(self.capture_pack/"CAPTURE_CONTRACT.json")],timeout=120)
        self.assertEqual(cp.returncode,0,cp.stderr)
        source=json.loads((working/"SOURCE_MANIFEST.json").read_text())
        env_entry=next(e for e in source["entries"] if e["path"]==".env")
        self.assertFalse(env_entry["snapshot_included"])
        self.complete_working(working)
        return_zip=self.base/"App_Intelligence_Return.zip"
        cp=run([sys.executable,str(CAPTURE_RUNTIME),"finalize","--repo",str(self.repo),"--working",str(working),"--output",str(return_zip)],timeout=120)
        self.assertEqual(cp.returncode,0,cp.stderr)
        cp=run([sys.executable,str(RETURN_VALIDATOR),str(return_zip)],timeout=120)
        self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
        request={"project_name":"Captured App","requested_change":"Add a real status endpoint.","requirements":[{"id":"REQ-001","text":"Status endpoint works","acceptance":["Returns current status"]}],"tasks":[{"id":"TASK-001","title":"Add status endpoint","description":"Implement endpoint after freshness gate.","requirements":["REQ-001"],"dependencies":[],"allowed_paths":["src/**","tests/**","Evidence/**"],"forbidden_paths":[".git/**",".laos/runtime/**","spec/**"],"allow_test_changes":True,"acceptance_criteria":["Endpoint works"],"checks":[{"id":"CHECK-PY","command":f'"{sys.executable}" -m py_compile src/app.py'}]}]}
        req=self.base/"continuation.json"; req.write_text(json.dumps(request),encoding="utf-8")
        output=self.base/"continuation_pack"
        cp=run([sys.executable,str(CONTINUATION_COMPILER),str(return_zip),str(req),str(output)],timeout=120)
        self.assertEqual(cp.returncode,0,cp.stderr)
        cfg=json.loads((output/".laos/config.json").read_text())
        self.assertEqual(cfg["expected_repository_fingerprint"],source["repository_content_fingerprint"])
        self.assertTrue((output/"CAPTURE_BASELINE/APP_INTELLIGENCE_MANIFEST.json").exists())


class LaosV7CompilerAuditTests(unittest.TestCase):
    def compile(self, blueprint):
        with tempfile.TemporaryDirectory(prefix="laos_compile_audit_") as td:
            td=Path(td); bp=td/"bp.json"; bp.write_text(json.dumps(blueprint),encoding="utf-8")
            return run([sys.executable,str(COMPILER),str(bp),str(td/"out")])

    def base(self):
        return {
            "engagement_mode":"new_project", "project_name":"Audit Fixture", "project_summary":"Compiler audit fixture",
            "project_definition":{"problem":"test","primary_users":["tester"],"finish_line":"verified"},
            "user_journeys":[{"id":"FLOW-001","steps":["run"]}],
            "acceptance_model":{"required":"checks pass"}, "deployment_contract":{"scope":"none"},
            "requirements":[{"id":"REQ-001","priority":"MUST","text":"Verified outcome","acceptance":["Observed"]}],
            "tasks":[{"id":"TASK-001","title":"Implement","description":"Implement verified outcome",
                "requirements":["REQ-001"],"dependencies":[],"allowed_paths":["src/**","Evidence/**"],
                "forbidden_paths":[".git/**",".laos/runtime/**","spec/**"],"acceptance_criteria":["Observed"],
                "checks":[{"id":"CHECK-001","command":f'"{sys.executable}" -c "print(1)"'}],
                "evidence_required":[{"path":"Evidence/TASK-001/results.md","stage":"EVIDENCED","min_bytes":20},{"path":"Evidence/TASK-001/review.md","stage":"REVIEWED","min_bytes":20}],
                "review_required":True}]
        }

    def test_rejects_uncovered_must_requirement(self):
        bp=self.base(); bp["requirements"].append({"id":"REQ-002","priority":"MUST","text":"Uncovered","acceptance":["Observed"]})
        cp=self.compile(bp); self.assertNotEqual(cp.returncode,0); self.assertIn("not linked to any task",cp.stderr)

    def test_rejects_dependency_cycle(self):
        bp=self.base(); bp["tasks"][0]["dependencies"]=["TASK-002"]
        bp["tasks"].append({"id":"TASK-002","title":"Second","description":"Second task","requirements":[],"dependencies":["TASK-001"],
            "allowed_paths":["src/**","Evidence/**"],"forbidden_paths":[".git/**"],"acceptance_criteria":["Done"],
            "checks":[{"id":"CHECK-002","command":f'"{sys.executable}" -c "print(1)"'}],
            "evidence_required":[{"path":"Evidence/TASK-002/results.md","stage":"EVIDENCED","min_bytes":20},{"path":"Evidence/TASK-002/review.md","stage":"REVIEWED","min_bytes":20}],"review_required":True})
        cp=self.compile(bp); self.assertNotEqual(cp.returncode,0); self.assertIn("dependency cycle",cp.stderr.lower())

    def test_rejects_unresolved_implementation_marker(self):
        bp=self.base(); bp["tasks"][0]["checks"][0]["command"]="<REAL_TEST_COMMAND>"
        cp=self.compile(bp); self.assertNotEqual(cp.returncode,0); self.assertIn("Unresolved compilation marker",cp.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
