#!/usr/bin/env python3
"""LAOS v7 portable enforcement runtime.

Standard-library only. Designed to be copied into a project at .laos/runtime/laos.py.
It enforces task sequencing, evidence gates, checkpoints, hash-chained state events,
side-effect journaling, command capture, and artifact verification.
"""
from __future__ import annotations

import argparse
import datetime as dt
import fnmatch
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import time
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

sys.dont_write_bytecode = True

VERSION = "7.0.0"
ACTIVE_STATES = {"CLAIMED", "IN_PROGRESS", "IMPLEMENTED", "TESTED", "EVIDENCED", "REVIEWED"}
TERMINAL_STATES = {"CLOSED", "BLOCKED", "FAILED", "SUPERSEDED", "DEFERRED"}
RECOVERY_STATES = {"NEEDS_REPAIR", "NEEDS_ESCALATION"}
ALL_STATES = {
    "DEFINED", "READY", "CLAIMED", "IN_PROGRESS", "IMPLEMENTED", "TESTED",
    "EVIDENCED", "REVIEWED", "CLOSED", "BLOCKED", "FAILED", "NEEDS_REPAIR",
    "NEEDS_ESCALATION", "SUPERSEDED", "DEFERRED"
}
NEXT_STATE = {
    "DEFINED": "READY",
    "READY": "CLAIMED",
    "CLAIMED": "IN_PROGRESS",
    "IN_PROGRESS": "IMPLEMENTED",
    "IMPLEMENTED": "TESTED",
    "TESTED": "EVIDENCED",
    "EVIDENCED": "REVIEWED",
    "REVIEWED": "CLOSED",
}
SIDE_EFFECT_STATES = ["PROPOSED", "AUTHORIZED", "PREPARED", "EXECUTED", "EXTERNALLY_VERIFIED", "COMMITTED"]
SIDE_EFFECT_TERMINAL = {"COMMITTED", "ABORTED", "COMPENSATED"}

SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*['\"]?[^\s'\"]{8,}"),
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{20,}"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
]

class LaosError(RuntimeError):
    pass


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_utc(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def harness_file_hashes(root: Path) -> dict[str, str]:
    manifest_path = root / "HARNESS_MANIFEST.json"
    if not manifest_path.exists():
        return {}
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return {str(item.get("path", "")).replace("\\", "/"): str(item.get("sha256", "")) for item in manifest.get("files", []) if isinstance(item, dict)}


def _ignore_runtime_path(rel: str) -> bool:
    parts = PurePosixPath(rel).parts
    ignored_dirs = {".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".venv", "venv", "dist", "build", "coverage", ".next", ".nuxt", ".cache"}
    if any(part in ignored_dirs for part in parts):
        return True
    if rel.startswith(".laos/state/") or rel.startswith("Evidence/"):
        return True
    if rel in {"RUN_STATE.md", "NEXT_ACTIONS.md"} or rel.endswith(".pyc"):
        return True
    return False


def project_manifest(root: Path, *, include_harness_changes: bool = True) -> dict[str, dict[str, Any]]:
    expected_harness = harness_file_hashes(root)
    result: dict[str, dict[str, Any]] = {}
    for path in root.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(root).as_posix()
        if _ignore_runtime_path(rel):
            continue
        try:
            digest = sha256_file(path)
            size = path.stat().st_size
        except OSError:
            continue
        if rel in expected_harness and digest == expected_harness[rel]:
            continue
        if not include_harness_changes and rel in expected_harness:
            continue
        result[rel] = {"sha256": digest, "bytes": size}
    return result


def manifest_digest(manifest: dict[str, dict[str, Any]]) -> str:
    payload = "\n".join(f"{path}|{meta.get('bytes')}|{meta.get('sha256')}" for path, meta in sorted(manifest.items()))
    return sha256_bytes(payload.encode("utf-8"))


def project_fingerprint(root: Path) -> str:
    return manifest_digest(project_manifest(root))


def baseline_path(root: Path, task_id: str) -> Path:
    return root / ".laos" / "state" / "baselines" / f"{task_id}.json"


def save_task_baseline(root: Path, task_id: str) -> dict[str, Any]:
    manifest = project_manifest(root)
    data = {"task_id": task_id, "captured_at": utc_now(), "project_fingerprint": manifest_digest(manifest), "files": manifest}
    save_json(baseline_path(root, task_id), data)
    return data


def changed_from_baseline(root: Path, task_id: str) -> dict[str, list[str]]:
    base = load_json(baseline_path(root, task_id), default={"files": {}}).get("files", {})
    current = project_manifest(root)
    before, after = set(base), set(current)
    modified = sorted(path for path in before & after if base[path] != current[path])
    return {"added": sorted(after - before), "modified": modified, "deleted": sorted(before - after)}


def task_scope_fingerprint(root: Path) -> str:
    return project_fingerprint(root)


def test_like(path: str) -> bool:
    lower = path.lower()
    name = PurePosixPath(lower).name
    parts = set(PurePosixPath(lower).parts)
    return any(part in {"test", "tests", "__tests__", "e2e", "spec"} for part in parts) or any(token in name for token in [".test.", ".spec.", "test_", "_test."])


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        if default is not None:
            return default
        raise LaosError(f"Missing required JSON file: {path}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise LaosError(f"Invalid JSON in {path}: {e}") from e


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def save_json(path: Path, obj: Any) -> None:
    atomic_write(path, json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True) + "\n")


def find_root(explicit: str | None = None) -> Path:
    if explicit:
        root = Path(explicit).expanduser().resolve()
        if not (root / ".laos").exists():
            raise LaosError(f"Not a LAOS project root: {root}")
        return root
    current = Path.cwd().resolve()
    for candidate in [current, *current.parents]:
        if (candidate / ".laos").is_dir():
            return candidate
    raise LaosError("Could not find .laos directory. Run from the project root or pass --root.")


def paths(root: Path) -> dict[str, Path]:
    return {
        "config": root / ".laos" / "config.json",
        "state": root / ".laos" / "state" / "current_state.json",
        "events": root / ".laos" / "state" / "events.jsonl",
        "locks": root / ".laos" / "state" / "locks",
        "checkpoints": root / ".laos" / "state" / "checkpoints",
        "baselines": root / ".laos" / "state" / "baselines",
        "checks": root / ".laos" / "state" / "check_results.json",
        "evidence_index": root / ".laos" / "state" / "evidence_index.json",
        "side_effects": root / ".laos" / "state" / "side_effect_journal.jsonl",
        "task_graph": root / "work" / "task_graph.json",
        "requirements": root / "spec" / "requirements.json",
        "manifest": root / "HARNESS_MANIFEST.json",
        "evidence": root / "Evidence",
        "run_state_md": root / "RUN_STATE.md",
        "next_actions_md": root / "NEXT_ACTIONS.md",
        "event_anchor": root / "Evidence" / "LAOS_EVENT_ANCHOR.json",
        "amendments": root / "spec" / "amendments",
    }


def load_project(root: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    p = paths(root)
    cfg = load_json(p["config"])
    graph = load_json(p["task_graph"])
    state = load_json(p["state"])
    return cfg, graph, state


def task_map(graph: dict[str, Any]) -> dict[str, dict[str, Any]]:
    tasks = graph.get("tasks")
    if not isinstance(tasks, list):
        raise LaosError("work/task_graph.json must contain a tasks array")
    result: dict[str, dict[str, Any]] = {}
    for task in tasks:
        tid = task.get("id")
        if not isinstance(tid, str) or not tid:
            raise LaosError("Every task requires a non-empty id")
        if tid in result:
            raise LaosError(f"Duplicate task id: {tid}")
        result[tid] = task
    return result


def append_event(root: Path, event_type: str, *, task_id: str | None = None,
                 actor: str = "unknown", details: dict[str, Any] | None = None) -> dict[str, Any]:
    p = paths(root)
    p["events"].parent.mkdir(parents=True, exist_ok=True)
    prev_hash = "GENESIS"
    if p["events"].exists():
        lines = [line for line in p["events"].read_text(encoding="utf-8").splitlines() if line.strip()]
        if lines:
            prev_hash = json.loads(lines[-1]).get("event_hash", "BROKEN")
    base = {
        "event_id": str(uuid.uuid4()),
        "timestamp": utc_now(),
        "event_type": event_type,
        "task_id": task_id,
        "actor": actor,
        "details": details or {},
        "previous_hash": prev_hash,
    }
    base["event_hash"] = sha256_bytes(canonical(base).encode("utf-8"))
    with p["events"].open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(base, ensure_ascii=False, sort_keys=True) + "\n")
    return base


def verify_event_chain(root: Path) -> tuple[bool, str]:
    event_path = paths(root)["events"]
    if not event_path.exists():
        return False, "events.jsonl is missing"
    prev = "GENESIS"
    count = 0
    for line_no, line in enumerate(event_path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        count += 1
        try:
            event = json.loads(line)
        except json.JSONDecodeError as e:
            return False, f"line {line_no} invalid JSON: {e}"
        stored = event.pop("event_hash", None)
        if event.get("previous_hash") != prev:
            return False, f"line {line_no} previous_hash mismatch"
        calculated = sha256_bytes(canonical(event).encode("utf-8"))
        if stored != calculated:
            return False, f"line {line_no} event hash mismatch"
        prev = stored
    return True, f"{count} events verified"


def dependency_cycle(tasks: dict[str, dict[str, Any]]) -> list[str] | None:
    visiting: set[str] = set()
    visited: set[str] = set()
    stack: list[str] = []

    def visit(tid: str) -> list[str] | None:
        if tid in visiting:
            idx = stack.index(tid)
            return stack[idx:] + [tid]
        if tid in visited:
            return None
        visiting.add(tid)
        stack.append(tid)
        for dep in tasks[tid].get("dependencies", []):
            if dep not in tasks:
                raise LaosError(f"Task {tid} depends on missing task {dep}")
            cycle = visit(dep)
            if cycle:
                return cycle
        stack.pop()
        visiting.remove(tid)
        visited.add(tid)
        return None

    for tid in tasks:
        cycle = visit(tid)
        if cycle:
            return cycle
    return None


def ensure_state_shape(graph: dict[str, Any], state: dict[str, Any]) -> None:
    tasks = task_map(graph)
    state.setdefault("schema_version", "1.0")
    state.setdefault("task_states", {})
    for tid in tasks:
        state["task_states"].setdefault(tid, {
            "status": "DEFINED",
            "claimed_by": None,
            "claimed_at": None,
            "started_at": None,
            "updated_at": utc_now(),
            "notes": [],
            "changed_files": [],
            "review": None,
            "baseline_fingerprint": None,
            "last_heartbeat_at": None,
        })
    unknown = set(state["task_states"]) - set(tasks)
    if unknown:
        raise LaosError(f"State contains unknown tasks: {sorted(unknown)}")


def refresh_ready(root: Path, *, actor: str = "harness") -> list[str]:
    cfg, graph, state = load_project(root)
    ensure_state_shape(graph, state)
    tasks = task_map(graph)
    changed: list[str] = []
    for tid, task in tasks.items():
        ts = state["task_states"][tid]
        if ts["status"] == "DEFINED":
            deps = task.get("dependencies", [])
            if all(state["task_states"][dep]["status"] == "CLOSED" for dep in deps):
                ts["status"] = "READY"
                ts["updated_at"] = utc_now()
                changed.append(tid)
                append_event(root, "TASK_READY", task_id=tid, actor=actor, details={"dependencies": deps})
    save_json(paths(root)["state"], state)
    render_state_docs(root, graph, state)
    return changed


def get_task(graph: dict[str, Any], state: dict[str, Any], task_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    tasks = task_map(graph)
    if task_id not in tasks:
        raise LaosError(f"Unknown task: {task_id}")
    return tasks[task_id], state["task_states"][task_id]


def match_any(path: str, patterns: Iterable[str]) -> bool:
    normalized = path.replace("\\", "/")
    return any(fnmatch.fnmatch(normalized, p) or normalized.startswith(p.rstrip("*").rstrip("/")) for p in patterns)


def git_info(root: Path) -> dict[str, Any]:
    def run(*args: str) -> tuple[int, str]:
        cp = subprocess.run(["git", "-c", "core.quotepath=false", *args], cwd=root, text=True, capture_output=True)
        return cp.returncode, (cp.stdout or cp.stderr).rstrip()
    code, inside = run("rev-parse", "--is-inside-work-tree")
    if code != 0 or inside != "true":
        return {"available": False}
    _, branch = run("branch", "--show-current")
    _, full = run("rev-parse", "HEAD")
    _, short = run("rev-parse", "--short", "HEAD")
    _, status = run("status", "--porcelain=v1", "--untracked-files=all")
    _, diff_names = run("diff", "--name-only")
    _, staged_names = run("diff", "--cached", "--name-only")
    changed = set((diff_names + "\n" + staged_names).splitlines()) - {""}
    status_lines = status.splitlines() if status else []
    for line in status_lines:
        if len(line) < 4:
            continue
        name = line[3:].strip()
        if " -> " in name:
            old_name, new_name = name.split(" -> ", 1)
            changed.add(old_name.strip('"'))
            changed.add(new_name.strip('"'))
        else:
            changed.add(name.strip('"'))
    return {
        "available": True,
        "branch": branch,
        "full_hash": full,
        "short_hash": short,
        "status_porcelain": status_lines,
        "changed_files": sorted(changed),
    }


def _unchanged_harness_import(root: Path, relative_path: str) -> bool:
    """Return True when a changed/untracked file is an unmodified file from the compiled pack.

    This lets a LAOS pack be extracted into an existing repository before the harness files are
    committed, without hiding later edits to those files. The file is ignored only while its
    current hash exactly matches the compiler manifest.
    """
    if relative_path == "HARNESS_MANIFEST.json":
        return (root / relative_path).is_file()
    manifest_path = paths(root)["manifest"]
    if not manifest_path.exists():
        return False
    try:
        manifest = load_json(manifest_path)
    except LaosError:
        return False
    expected = {item.get("path"): item.get("sha256") for item in manifest.get("files", []) if isinstance(item, dict)}
    expected_hash = expected.get(relative_path.replace("\\", "/"))
    candidate = root / relative_path
    return bool(expected_hash and candidate.is_file() and sha256_file(candidate) == expected_hash)


def validate_changed_files(root: Path, task: dict[str, Any], task_state: dict[str, Any]) -> list[str]:
    cfg = load_json(paths(root)["config"])
    info = git_info(root)
    if cfg.get("require_git", True) and not info["available"]:
        raise LaosError("Git is required by .laos/config.json but this is not a Git work tree")
    base_file = baseline_path(root, task["id"])
    if base_file.exists():
        delta = changed_from_baseline(root, task["id"])
        changed = sorted(set(delta["added"] + delta["modified"] + delta["deleted"]))
    else:
        changed = info.get("changed_files", []) if info["available"] else [x.get("path") for x in task_state.get("changed_files", []) if isinstance(x, dict)]
        delta = {"added": changed, "modified": [], "deleted": []}
    allowed = task.get("allowed_paths", ["**"])
    forbidden = task.get("forbidden_paths", [])
    violations = []
    for path in changed:
        if not path:
            continue
        if path.startswith("Evidence/") or path.startswith(".laos/state/") or path.startswith(".laos/runtime/__pycache__/") or path.endswith(".pyc") or path in {"RUN_STATE.md", "NEXT_ACTIONS.md"}:
            continue
        if _unchanged_harness_import(root, path):
            continue
        if forbidden and match_any(path, forbidden):
            violations.append(f"forbidden path changed: {path}")
        elif allowed and not match_any(path, allowed):
            violations.append(f"outside allowed paths: {path}")
        if test_like(path) and not task.get("allow_test_changes", False):
            violations.append(f"test file changed without allow_test_changes=true: {path}")
    if violations:
        raise LaosError("Scope gate failed:\n- " + "\n- ".join(sorted(set(violations))))
    task_state["baseline_delta"] = delta
    return changed

def load_check_results(root: Path) -> dict[str, Any]:
    return load_json(paths(root)["checks"], default={"results": []})


def required_checks_pass(root: Path, task: dict[str, Any], required_through: str = "TESTED") -> None:
    stage_order = ["IMPLEMENTED", "TESTED", "EVIDENCED", "REVIEWED", "CLOSED"]
    max_idx = stage_order.index(required_through) if required_through in stage_order else 1
    required = [c for c in task.get("checks", []) if c.get("required", True) and stage_order.index(c.get("stage", "TESTED")) <= max_idx]
    results = load_check_results(root).get("results", [])
    latest: dict[tuple[str, str], dict[str, Any]] = {}
    for result in results:
        latest[(result.get("task_id"), result.get("check_id"))] = result
    missing: list[str] = []
    failed: list[str] = []
    stale: list[str] = []
    current_fingerprint = task_scope_fingerprint(root)
    check_defs = {c.get("id"): c for c in task.get("checks", [])}
    for check in required:
        result = latest.get((task["id"], check["id"]))
        if not result:
            missing.append(check["id"])
            continue
        if result.get("exit_code") != 0:
            failed.append(f"{check['id']} (exit {result.get('exit_code')})")
        if result.get("source_fingerprint") != current_fingerprint:
            stale.append(f"{check['id']} (source changed after check)")
        expected_command = check_defs[check["id"]].get("command")
        if result.get("command") != expected_command:
            stale.append(f"{check['id']} (command differs from contract)")
        evidence_rel = result.get("evidence_path")
        evidence_path = root / evidence_rel if evidence_rel else None
        if not evidence_path or not evidence_path.is_file() or sha256_file(evidence_path) != result.get("evidence_sha256"):
            stale.append(f"{check['id']} (transcript missing or changed)")
    if missing or failed or stale:
        parts = []
        if missing:
            parts.append("missing required checks: " + ", ".join(missing))
        if failed:
            parts.append("failed checks: " + ", ".join(failed))
        if stale:
            parts.append("stale or invalid checks: " + ", ".join(stale))
        raise LaosError("Test gate failed: " + "; ".join(parts))

def required_evidence_exists(root: Path, task: dict[str, Any], through_stage: str = "EVIDENCED") -> None:
    stage_order = ["IMPLEMENTED", "TESTED", "EVIDENCED", "REVIEWED", "CLOSED"]
    max_idx = stage_order.index(through_stage) if through_stage in stage_order else 2
    index = load_json(paths(root)["evidence_index"], default={"items": []})
    latest: dict[tuple[str, str], dict[str, Any]] = {}
    for item in index.get("items", []):
        latest[(item.get("task_id"), item.get("path"))] = item
    _, graph, state = load_project(root)
    _, task_state = get_task(graph, state, task["id"])
    current_fingerprint = task_scope_fingerprint(root)
    issues: list[str] = []
    for req in task.get("evidence_required", []):
        stage = req.get("stage", "EVIDENCED")
        if stage not in stage_order or stage_order.index(stage) > max_idx:
            continue
        rel = req["path"].replace("\\", "/")
        path = root / rel
        min_bytes = int(req.get("min_bytes", 1))
        if not path.exists() or not path.is_file() or path.stat().st_size < min_bytes:
            issues.append(f"{rel} (missing or below {min_bytes} bytes)")
            continue
        rec = latest.get((task["id"], rel))
        review = task_state.get("review") or {}
        if not rec and review.get("evidence_path") == rel:
            rec = {"sha256": review.get("evidence_sha256"), "source_fingerprint": review.get("source_fingerprint")}
        if not rec:
            issues.append(f"{rel} (not registered)")
            continue
        if rec.get("sha256") != sha256_file(path):
            issues.append(f"{rel} (changed after registration)")
        if rec.get("source_fingerprint") != current_fingerprint:
            issues.append(f"{rel} (stale after source change)")
    if issues:
        raise LaosError("Evidence gate failed:\n- " + "\n- ".join(issues))

def side_effect_status(root: Path, task_id: str) -> dict[str, str]:
    path = paths(root)["side_effects"]
    status: dict[str, str] = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            rec = json.loads(line)
            if rec.get("task_id") == task_id:
                status[rec["operation_id"]] = rec["state"]
    return status


def gate_transition(root: Path, task: dict[str, Any], task_state: dict[str, Any], target: str) -> None:
    current = task_state["status"]
    if target not in ALL_STATES:
        raise LaosError(f"Unknown target state: {target}")
    if target in {"BLOCKED", "FAILED", "NEEDS_REPAIR", "NEEDS_ESCALATION", "DEFERRED", "SUPERSEDED"}:
        return
    expected = NEXT_STATE.get(current)
    if target != expected:
        raise LaosError(f"Illegal transition {current} -> {target}; expected {expected or 'no normal successor'}")
    if target == "IMPLEMENTED":
        changed = validate_changed_files(root, task, task_state)
        if not task.get("no_code_change", False) and not changed and not task_state.get("changed_files"):
            raise LaosError("Implementation gate failed: no changed files recorded or detected")
    elif target == "TESTED":
        required_checks_pass(root, task, "TESTED")
    elif target == "EVIDENCED":
        required_checks_pass(root, task, "EVIDENCED")
        required_evidence_exists(root, task, "EVIDENCED")
    elif target == "REVIEWED":
        required_evidence_exists(root, task, "REVIEWED")
        if task.get("review_required", True):
            review = task_state.get("review")
            if not review or review.get("verdict") not in {"PASS", "PASS_WITH_NON_BLOCKERS"}:
                raise LaosError("Review gate failed: an acceptable independent/fresh review is required")
    elif target == "CLOSED":
        required_checks_pass(root, task, "CLOSED")
        required_evidence_exists(root, task, "CLOSED")
        effects = side_effect_status(root, task["id"])
        required_ops = task.get("side_effects_required", [])
        unresolved = [op for op in required_ops if effects.get(op) not in SIDE_EFFECT_TERMINAL]
        if unresolved:
            raise LaosError("Side-effect gate failed; unresolved operations: " + ", ".join(unresolved))
        validate_changed_files(root, task, task_state)


def render_state_docs(root: Path, graph: dict[str, Any] | None = None, state: dict[str, Any] | None = None) -> None:
    if graph is None or state is None:
        _, graph, state = load_project(root)
    tasks = task_map(graph)
    counts: dict[str, int] = {}
    for ts in state["task_states"].values():
        counts[ts["status"]] = counts.get(ts["status"], 0) + 1
    manifest = load_json(paths(root)["manifest"], default={})
    git = git_info(root)
    lines = [
        "# RUN_STATE",
        "",
        f"Generated by LAOS v{VERSION} at `{utc_now()}`.",
        "",
        f"- Project: **{manifest.get('project_name', root.name)}**",
        f"- Pack ID: `{manifest.get('pack_id', 'unknown')}`",
        f"- Acceptance state: `{state.get('acceptance_state', 'PARTIAL / NOT FINAL')}`",
        f"- Git: `{git.get('branch', 'unavailable')}` / `{git.get('short_hash', 'unavailable')}`",
        "- Task counts: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())),
        "",
        "## Tasks",
        "",
        "| ID | Status | Title | Claimed by | Updated |",
        "|---|---|---|---|---|",
    ]
    for tid, task in sorted(tasks.items(), key=lambda kv: (kv[1].get("priority", 999), kv[0])):
        ts = state["task_states"][tid]
        lines.append(f"| {tid} | {ts['status']} | {task.get('title','')} | {ts.get('claimed_by') or ''} | {ts.get('updated_at','')} |")
    atomic_write(paths(root)["run_state_md"], "\n".join(lines) + "\n")

    ready = []
    blocked = []
    for tid, task in tasks.items():
        status = state["task_states"][tid]["status"]
        if status == "READY":
            ready.append((task.get("priority", 999), tid, task.get("title", "")))
        if status in {"BLOCKED", "FAILED", "NEEDS_REPAIR", "NEEDS_ESCALATION"}:
            blocked.append((tid, status, task.get("title", "")))
    nlines = ["# NEXT_ACTIONS", "", f"Generated at `{utc_now()}`.", "", "## Next legal tasks", ""]
    if ready:
        for _, tid, title in sorted(ready):
            nlines.append(f"1. `{tid}` - {title}")
    else:
        nlines.append("No task is currently READY. Run `laos doctor` and inspect blockers or completed dependencies.")
    if blocked:
        nlines += ["", "## Blocked or repair-required", ""]
        for tid, status, title in blocked:
            nlines.append(f"- `{tid}` [{status}] - {title}")
    atomic_write(paths(root)["next_actions_md"], "\n".join(nlines) + "\n")


def verify_repository_baseline(root: Path, actor: str, *, accept_current: bool = False, reason: str | None = None) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    expected = cfg.get("expected_repository_fingerprint")
    expected_commit = cfg.get("expected_git_commit")
    actual = project_fingerprint(root)
    git = git_info(root)
    commit_matches = not expected_commit or git.get("full_hash") == expected_commit
    fingerprint_matches = not expected or actual == expected
    if not fingerprint_matches and not accept_current:
        raise LaosError(f"Repository freshness gate failed: expected {expected}, actual {actual}. Reconcile or rerun with --accept-current after authorized TASK-000 evidence.")
    if accept_current:
        if not reason:
            raise LaosError("--accept-current requires --reason")
        task_zero = state.get("task_states", {}).get("TASK-000", {})
        if expected and task_zero.get("status") != "CLOSED":
            raise LaosError("A mismatched captured baseline may be accepted only after TASK-000 is CLOSED")
        expected = actual
        cfg["expected_repository_fingerprint"] = actual
        cfg["expected_git_commit"] = git.get("full_hash")
        save_json(paths(root)["config"], cfg)
    record = {
        "verified_at": utc_now(),
        "actor": actor,
        "expected_repository_fingerprint": expected,
        "actual_repository_fingerprint": actual,
        "fingerprint_matches": fingerprint_matches,
        "expected_git_commit": expected_commit,
        "actual_git_commit": git.get("full_hash"),
        "commit_matches": commit_matches,
        "accepted_current": accept_current,
        "reason": reason,
        "status": "PASS" if fingerprint_matches or accept_current else "FAIL",
    }
    state["repository_baseline"] = record
    save_json(paths(root)["state"], state)
    append_event(root, "REPOSITORY_BASELINE_VERIFIED", actor=actor, details=record)
    return record


def lock_expired(lock: dict[str, Any]) -> bool:
    expiry = parse_utc(lock.get("expires_at"))
    return bool(expiry and dt.datetime.now(dt.timezone.utc) > expiry)


def heartbeat(root: Path, task_id: str, actor: str) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    _, ts = get_task(graph, state, task_id)
    lock_path = paths(root)["locks"] / f"{task_id}.lock.json"
    if not lock_path.exists():
        raise LaosError("No active task lock")
    lock = load_json(lock_path)
    if lock.get("actor") != actor:
        raise LaosError(f"Task is claimed by {lock.get('actor')}, not {actor}")
    minutes = int(cfg.get("lock_lease_minutes", 60))
    lock["heartbeat_at"] = utc_now()
    lock["expires_at"] = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=minutes)).replace(microsecond=0).isoformat()
    save_json(lock_path, lock)
    ts["last_heartbeat_at"] = lock["heartbeat_at"]
    ts["updated_at"] = utc_now()
    save_json(paths(root)["state"], state)
    append_event(root, "TASK_HEARTBEAT", task_id=task_id, actor=actor, details={"expires_at": lock["expires_at"]})
    return lock


def anchor_event_chain(root: Path, actor: str, external_path: str | None = None) -> dict[str, Any]:
    event_path = paths(root)["events"]
    lines = [line for line in event_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not lines:
        raise LaosError("Cannot anchor an empty event ledger")
    tip = json.loads(lines[-1]).get("event_hash")
    record = {"anchored_at": utc_now(), "actor": actor, "event_count": len(lines), "event_chain_tip": tip, "events_sha256": sha256_file(event_path)}
    save_json(paths(root)["event_anchor"], record)
    if external_path:
        target = Path(external_path).expanduser().resolve()
        if root.resolve() in target.parents:
            raise LaosError("External anchor path must be outside the project root")
        save_json(target, record)
    append_event(root, "EVENT_CHAIN_ANCHORED", actor=actor, details={"anchor": str(paths(root)["event_anchor"].relative_to(root)), "external": external_path})
    return record


def verify_event_anchor(root: Path) -> tuple[bool, str]:
    anchor_path = paths(root)["event_anchor"]
    if not anchor_path.exists():
        return False, "event anchor missing"
    anchor = load_json(anchor_path)
    event_path = paths(root)["events"]
    lines = [line for line in event_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not lines:
        return False, "event ledger empty"
    # The anchor event itself is appended after the anchor was written. The anchor therefore
    # proves the chain prefix ending immediately before EVENT_CHAIN_ANCHORED.
    anchored_tip = anchor.get("event_chain_tip")
    tips = [json.loads(line).get("event_hash") for line in lines]
    if anchored_tip not in tips:
        return False, "anchored event hash is not present in current ledger"
    return True, f"anchor covers event hash {anchored_tip}"


def propose_amendment(root: Path, amendment_id: str, actor: str, title: str, reason: str, impact: str) -> Path:
    if not re.fullmatch(r"AMD-[0-9]{3,}", amendment_id):
        raise LaosError("Amendment ID must look like AMD-001")
    path = paths(root)["amendments"] / f"{amendment_id}.json"
    if path.exists():
        raise LaosError(f"Amendment already exists: {amendment_id}")
    data = {"id": amendment_id, "status": "PROPOSED", "title": title, "reason": reason, "impact": impact, "proposed_by": actor, "proposed_at": utc_now(), "approved_by": None, "approved_at": None}
    save_json(path, data)
    append_event(root, "AMENDMENT_PROPOSED", actor=actor, details=data)
    return path


def approve_amendment(root: Path, amendment_id: str, approver: str) -> dict[str, Any]:
    path = paths(root)["amendments"] / f"{amendment_id}.json"
    data = load_json(path)
    if data.get("status") != "PROPOSED":
        raise LaosError("Only PROPOSED amendments can be approved")
    if data.get("proposed_by") == approver:
        raise LaosError("Amendment approval must be independent of the proposer")
    data.update({"status": "APPROVED", "approved_by": approver, "approved_at": utc_now()})
    save_json(path, data)
    append_event(root, "AMENDMENT_APPROVED", actor=approver, details=data)
    return data


def doctor(root: Path) -> dict[str, Any]:
    p = paths(root)
    required = [p["config"], p["state"], p["events"], p["task_graph"], p["manifest"]]
    missing = [str(x.relative_to(root)) for x in required if not x.exists()]
    cfg, graph, state = load_project(root)
    ensure_state_shape(graph, state)
    tasks = task_map(graph)
    cycle = dependency_cycle(tasks)
    chain_ok, chain_msg = verify_event_chain(root)
    lock_issues: list[str] = []
    p["locks"].mkdir(parents=True, exist_ok=True)
    for lock_file in p["locks"].glob("*.lock.json"):
        lock = load_json(lock_file)
        tid = lock.get("task_id")
        if tid not in tasks:
            lock_issues.append(f"orphan lock {lock_file.name}")
        elif state["task_states"][tid]["status"] not in ACTIVE_STATES:
            lock_issues.append(f"stale lock {lock_file.name} for state {state['task_states'][tid]['status']}")
        elif lock_expired(lock):
            lock_issues.append(f"expired lock {lock_file.name}; owner {lock.get('actor')}")
    evidence_exists = p["evidence"].is_dir()
    expected = cfg.get("expected_repository_fingerprint")
    actual = project_fingerprint(root)
    baseline_record = state.get("repository_baseline")
    baseline = {
        "expected": expected,
        "actual": actual,
        "current_match": (not expected or expected == actual),
        "verified_record": baseline_record,
        "required_before_product_work": bool(expected),
    }
    anchor_ok, anchor_msg = verify_event_anchor(root) if p["event_anchor"].exists() else (False, "not yet anchored")
    warnings: list[str] = []
    if expected and not baseline["current_match"] and not baseline_record:
        warnings.append("Captured repository baseline does not match current project content. Run verify-baseline or TASK-000 reconciliation before product work.")
    if lock_issues:
        warnings.append("One or more task locks are stale or expired; do not create a competing lock without reconciliation.")
    result = {
        "status": "PASS" if not missing and not cycle and chain_ok and evidence_exists else "FAIL",
        "version": VERSION,
        "root": str(root),
        "missing": missing,
        "dependency_cycle": cycle,
        "event_chain": {"ok": chain_ok, "message": chain_msg},
        "event_anchor": {"ok": anchor_ok, "message": anchor_msg},
        "lock_issues": lock_issues,
        "evidence_root_exists": evidence_exists,
        "git": git_info(root),
        "repository_baseline": baseline,
        "task_count": len(tasks),
        "warnings": warnings,
    }
    return result

def claim_task(root: Path, task_id: str, actor: str) -> None:
    cfg, graph, state = load_project(root)
    ensure_state_shape(graph, state)
    task, ts = get_task(graph, state, task_id)
    if ts["status"] == "DEFINED":
        refresh_ready(root, actor=actor)
        cfg, graph, state = load_project(root)
        task, ts = get_task(graph, state, task_id)
    if ts["status"] != "READY":
        raise LaosError(f"Task {task_id} is {ts['status']}, not READY")
    expected = cfg.get("expected_repository_fingerprint")
    if expected and task.get("kind") != "repository_reconciliation" and task_id != "TASK-000":
        baseline = state.get("repository_baseline") or {}
        if baseline.get("status") != "PASS":
            raise LaosError("Repository baseline has not been verified. Run verify-baseline or complete TASK-000 reconciliation first.")
        current = project_fingerprint(root)
        accepted = baseline.get("actual_repository_fingerprint")
        if current != accepted:
            raise LaosError("Repository changed after baseline verification. Reverify or reconcile before claiming a product task.")
    lock_path = paths(root)["locks"] / f"{task_id}.lock.json"
    if lock_path.exists():
        existing = load_json(lock_path)
        if lock_expired(existing):
            raise LaosError(f"Task lock is expired but must be explicitly cleared after reconciliation: {lock_path}")
        raise LaosError(f"Task lock already exists: {lock_path}")
    minutes = int(cfg.get("lock_lease_minutes", 60))
    claimed = utc_now()
    lock = {
        "task_id": task_id,
        "actor": actor,
        "claimed_at": claimed,
        "heartbeat_at": claimed,
        "expires_at": (dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=minutes)).replace(microsecond=0).isoformat(),
        "lock_id": str(uuid.uuid4()),
    }
    baseline = save_task_baseline(root, task_id)
    lock["baseline_fingerprint"] = baseline["project_fingerprint"]
    save_json(lock_path, lock)
    ts.update({"status": "CLAIMED", "claimed_by": actor, "claimed_at": claimed, "updated_at": utc_now(), "baseline_fingerprint": baseline["project_fingerprint"], "last_heartbeat_at": claimed})
    save_json(paths(root)["state"], state)
    append_event(root, "TASK_CLAIMED", task_id=task_id, actor=actor, details=lock)
    render_state_docs(root, graph, state)

def start_task(root: Path, task_id: str, actor: str) -> None:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    lock_path = paths(root)["locks"] / f"{task_id}.lock.json"
    if not lock_path.exists():
        raise LaosError("Task must be claimed before start")
    lock = load_json(lock_path)
    if lock_expired(lock):
        raise LaosError("Task lock has expired. Reconcile the prior agent's state before continuing.")
    if lock.get("actor") != actor:
        raise LaosError(f"Task is claimed by {lock.get('actor')}, not {actor}")
    gate_transition(root, task, ts, "IN_PROGRESS")
    ts.update({"status": "IN_PROGRESS", "started_at": utc_now(), "updated_at": utc_now()})
    save_json(paths(root)["state"], state)
    heartbeat(root, task_id, actor)
    append_event(root, "TASK_STARTED", task_id=task_id, actor=actor)
    render_state_docs(root, graph, state)

def advance_task(root: Path, task_id: str, target: str, actor: str, note: str | None) -> None:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    gate_transition(root, task, ts, target)
    old = ts["status"]
    ts["status"] = target
    ts["updated_at"] = utc_now()
    if note:
        ts.setdefault("notes", []).append({"at": utc_now(), "actor": actor, "text": note})
    save_json(paths(root)["state"], state)
    append_event(root, "TASK_STATE_CHANGED", task_id=task_id, actor=actor, details={"from": old, "to": target, "note": note})
    if target in TERMINAL_STATES:
        lock = paths(root)["locks"] / f"{task_id}.lock.json"
        if lock.exists():
            lock.unlink()
    refresh_ready(root, actor=actor)
    _, graph, state = load_project(root)
    render_state_docs(root, graph, state)


def record_change(root: Path, task_id: str, path: str, reason: str, actor: str) -> None:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    norm = path.replace("\\", "/").lstrip("./")
    if task.get("forbidden_paths") and match_any(norm, task["forbidden_paths"]):
        raise LaosError(f"Path is forbidden for this task: {norm}")
    if task.get("allowed_paths") and not match_any(norm, task["allowed_paths"]):
        raise LaosError(f"Path is outside allowed scope for this task: {norm}")
    rec = {"path": norm, "reason": reason, "actor": actor, "at": utc_now()}
    ts.setdefault("changed_files", []).append(rec)
    ts["updated_at"] = utc_now()
    save_json(paths(root)["state"], state)
    append_event(root, "CHANGE_RECORDED", task_id=task_id, actor=actor, details=rec)


def checkpoint(root: Path, task_id: str, actor: str, note: str | None) -> Path:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    if ts.get("claimed_by") and ts.get("claimed_by") != actor:
        raise LaosError(f"Task is claimed by {ts.get('claimed_by')}, not {actor}")
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    checkpoint_id = str(uuid.uuid4())
    folder = paths(root)["checkpoints"] / f"{task_id}_{stamp}_{checkpoint_id[:8]}"
    folder.mkdir(parents=True, exist_ok=False)
    snapshot = folder / "workspace_snapshot.zip"
    manifest = project_manifest(root)
    with zipfile.ZipFile(snapshot, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for rel in sorted(manifest):
            path = root / rel
            if path.is_file():
                zf.write(path, rel)
    data = {
        "checkpoint_id": checkpoint_id,
        "created_at": utc_now(),
        "task_id": task_id,
        "task_state": ts,
        "note": note,
        "actor": actor,
        "git": git_info(root),
        "project_fingerprint": manifest_digest(manifest),
        "file_manifest": manifest,
        "snapshot": snapshot.name,
        "snapshot_sha256": sha256_file(snapshot),
        "event_chain_tip": None,
    }
    event_path = paths(root)["events"]
    if event_path.exists():
        lines = [x for x in event_path.read_text(encoding="utf-8").splitlines() if x.strip()]
        if lines:
            data["event_chain_tip"] = json.loads(lines[-1]).get("event_hash")
    out = folder / "checkpoint.json"
    save_json(out, data)
    append_event(root, "CHECKPOINT_CREATED", task_id=task_id, actor=actor, details={"path": str(out.relative_to(root)), "note": note, "fingerprint": data["project_fingerprint"]})
    heartbeat(root, task_id, actor)
    return out


def recover_checkpoint(root: Path, checkpoint_arg: str, actor: str, *, confirm: bool = False, delete_extra: bool = False) -> dict[str, Any]:
    checkpoint_path = Path(checkpoint_arg)
    if not checkpoint_path.is_absolute():
        checkpoint_path = (root / checkpoint_path).resolve()
    data = load_json(checkpoint_path)
    snapshot = checkpoint_path.parent / data.get("snapshot", "workspace_snapshot.zip")
    if not snapshot.is_file() or sha256_file(snapshot) != data.get("snapshot_sha256"):
        raise LaosError("Checkpoint snapshot is missing or does not match its recorded hash")
    planned = {
        "checkpoint_id": data.get("checkpoint_id"),
        "task_id": data.get("task_id"),
        "checkpoint_fingerprint": data.get("project_fingerprint"),
        "current_fingerprint": project_fingerprint(root),
        "delete_extra": delete_extra,
        "confirmed": confirm,
    }
    if not confirm:
        return {"status": "DRY_RUN", **planned, "instruction": "Rerun with --confirm after reviewing the checkpoint and current work."}
    with tempfile.TemporaryDirectory(prefix="laos_recover_") as tmp:
        temp = Path(tmp)
        with zipfile.ZipFile(snapshot, "r") as zf:
            for info in zf.infolist():
                name = info.filename.replace("\\", "/")
                if name.startswith("/") or ".." in PurePosixPath(name).parts:
                    raise LaosError(f"Unsafe checkpoint entry: {name}")
            zf.extractall(temp)
        expected = set(data.get("file_manifest", {}))
        if delete_extra:
            current = set(project_manifest(root))
            for rel in sorted(current - expected, reverse=True):
                path = root / rel
                if path.is_file():
                    path.unlink()
        for path in sorted(p for p in temp.rglob("*") if p.is_file()):
            rel = path.relative_to(temp)
            target = root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
    actual = project_fingerprint(root)
    status = "PASS" if actual == data.get("project_fingerprint") else "PARTIAL"
    rec = {"status": status, **planned, "recovered_fingerprint": actual, "recovered_at": utc_now(), "actor": actor}
    append_event(root, "CHECKPOINT_RECOVERED", task_id=data.get("task_id"), actor=actor, details=rec)
    return rec


def clear_stale_lock(root: Path, task_id: str, actor: str, reason: str) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    _, ts = get_task(graph, state, task_id)
    lock_path = paths(root)["locks"] / f"{task_id}.lock.json"
    if not lock_path.exists():
        raise LaosError("No task lock exists")
    lock = load_json(lock_path)
    if not lock_expired(lock) and ts.get("status") in ACTIVE_STATES:
        raise LaosError("Lock is active. Do not clear another agent's live lease.")
    lock_path.unlink()
    if ts.get("status") in ACTIVE_STATES:
        ts["status"] = "NEEDS_REPAIR"
        ts["updated_at"] = utc_now()
        ts.setdefault("notes", []).append({"at": utc_now(), "actor": actor, "text": f"Stale lock cleared: {reason}"})
        save_json(paths(root)["state"], state)
    rec = {"task_id": task_id, "cleared_by": actor, "reason": reason, "previous_lock": lock, "new_state": ts.get("status")}
    append_event(root, "STALE_LOCK_CLEARED", task_id=task_id, actor=actor, details=rec)
    return rec

def run_check(root: Path, task_id: str, check_id: str, actor: str, command: str | None = None) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    check_defs = {c["id"]: c for c in task.get("checks", [])}
    if check_id not in check_defs:
        raise LaosError(f"Check {check_id} is not defined for task {task_id}")
    check = check_defs[check_id]
    contracted = check.get("command")
    if not contracted:
        raise LaosError(f"No command defined for check {check_id}")
    if command and command != contracted and not cfg.get("allow_check_command_override", False):
        raise LaosError("Check command overrides are disabled. Amend the task contract instead of silently running a different check.")
    cmd = command or contracted
    if any(p.search(cmd) for p in SECRET_PATTERNS):
        raise LaosError("Command appears to contain a secret. Pass credentials through an explicitly allowed environment variable, not the command line.")
    evidence_rel = check.get("evidence_path") or f"Evidence/checks/{task_id}_{check_id}.txt"
    evidence_path = root / evidence_rel
    evidence_path.parent.mkdir(parents=True, exist_ok=True)
    started = utc_now()
    source_before = task_scope_fingerprint(root)
    timeout = int(check.get("timeout_seconds", task.get("timeout_seconds", cfg.get("command_timeout_seconds", 1800))))
    max_output = int(cfg.get("max_captured_command_output_bytes", 200000))
    standard_names = {"PATH", "HOME", "USERPROFILE", "TEMP", "TMP", "TMPDIR", "SYSTEMROOT", "COMSPEC", "PATHEXT", "LANG", "LC_ALL", "TERM"}
    explicit_names = set(check.get("environment_allowlist", []))
    secret_name_tokens = {"KEY", "TOKEN", "SECRET", "PASSWORD", "PASSWD", "CREDENTIAL"}
    env: dict[str, str] = {}
    for name, value in os.environ.items():
        upper = name.upper()
        if name in standard_names or name in explicit_names:
            env[name] = value
        elif cfg.get("inherit_nonsecret_environment", True) and not any(token in upper for token in secret_name_tokens):
            env[name] = value
    timed_out = False
    try:
        cp = subprocess.run(cmd, cwd=root, shell=True, text=True, capture_output=True, timeout=timeout, env=env)
        exit_code = cp.returncode
        output = (cp.stdout or "") + (("\n[stderr]\n" + cp.stderr) if cp.stderr else "")
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        exit_code = 124
        output = f"[TIMEOUT after {timeout} seconds]\n{exc.stdout or ''}\n{exc.stderr or ''}"
    raw_bytes = output.encode("utf-8", errors="replace")
    truncated = len(raw_bytes) > max_output
    if truncated:
        output = raw_bytes[:max_output].decode("utf-8", errors="replace") + f"\n[OUTPUT TRUNCATED AT {max_output} BYTES]\n"
    secret_hits = [pat.pattern for pat in SECRET_PATTERNS if pat.search(output)]
    if secret_hits:
        output = "[OUTPUT REDACTED: POSSIBLE SECRET DETECTED]\n"
    source_after = task_scope_fingerprint(root)
    transcript = [
        f"LAOS v{VERSION} command transcript",
        f"Task: {task_id}",
        f"Check: {check_id}",
        f"Actor: {actor}",
        f"Working directory: {root}",
        f"Started: {started}",
        f"Finished: {utc_now()}",
        f"Command: {cmd}",
        f"Exit code: {exit_code}",
        f"Timeout seconds: {timeout}",
        f"Timed out: {timed_out}",
        f"Output truncated: {truncated}",
        f"Environment variable names supplied: {', '.join(sorted(env))}",
        f"Source fingerprint before: {source_before}",
        f"Source fingerprint after: {source_after}",
        f"Secret scan hits: {len(secret_hits)}",
        "",
        output,
    ]
    atomic_write(evidence_path, "\n".join(transcript))
    results = load_check_results(root)
    rec = {
        "task_id": task_id,
        "check_id": check_id,
        "command": cmd,
        "exit_code": exit_code,
        "timed_out": timed_out,
        "output_truncated": truncated,
        "started_at": started,
        "finished_at": utc_now(),
        "evidence_path": evidence_rel,
        "evidence_sha256": sha256_file(evidence_path),
        "secret_scan_hits": len(secret_hits),
        "actor": actor,
        "source_fingerprint": source_after,
        "environment_names": sorted(env),
        "failure_signature": sha256_bytes(output[-4000:].encode("utf-8", errors="replace")) if exit_code != 0 else None,
    }
    results.setdefault("results", []).append(rec)
    save_json(paths(root)["checks"], results)
    append_event(root, "CHECK_EXECUTED", task_id=task_id, actor=actor, details=rec)
    if exit_code != 0 and rec.get("failure_signature"):
        same = [r for r in results.get("results", []) if r.get("task_id") == task_id and r.get("check_id") == check_id and r.get("failure_signature") == rec["failure_signature"]]
        if len(same) >= int(load_json(paths(root)["config"]).get("mandatory_escalation_after_same_failure", 3)):
            _, graph_now, state_now = load_project(root)
            _, ts_now = get_task(graph_now, state_now, task_id)
            ts_now["status"] = "NEEDS_ESCALATION"
            ts_now["updated_at"] = utc_now()
            ts_now.setdefault("notes", []).append({"at": utc_now(), "actor": "harness", "text": f"Repeated identical failure for {check_id}; escalation required."})
            save_json(paths(root)["state"], state_now)
            lock_path = paths(root)["locks"] / f"{task_id}.lock.json"
            if lock_path.exists():
                lock_path.unlink()
            append_event(root, "THRASHING_DETECTED", task_id=task_id, actor="harness", details={"check_id": check_id, "identical_failure_count": len(same), "failure_signature": rec["failure_signature"]})
        else:
            heartbeat(root, task_id, actor)
    else:
        heartbeat(root, task_id, actor)
    if secret_hits:
        raise LaosError(f"Check output may contain a secret. Output was redacted; inspect securely. Evidence: {evidence_rel}")
    return rec

def record_evidence(root: Path, task_id: str, evidence_path_arg: str, kind: str, actor: str) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    candidate = (root / evidence_path_arg).resolve() if not Path(evidence_path_arg).is_absolute() else Path(evidence_path_arg).resolve()
    try:
        rel = candidate.relative_to(root)
    except ValueError as e:
        raise LaosError("Evidence must be inside the project root") from e
    if not candidate.exists() or not candidate.is_file() or candidate.stat().st_size == 0:
        raise LaosError(f"Evidence is missing or empty: {candidate}")
    if not str(rel).replace("\\", "/").startswith("Evidence/"):
        raise LaosError("Evidence must be stored under the root Evidence folder")
    text_sample = ""
    try:
        text_sample = candidate.read_text(encoding="utf-8", errors="ignore")[:2_000_000]
    except OSError:
        pass
    hits = [pat.pattern for pat in SECRET_PATTERNS if pat.search(text_sample)]
    if hits:
        raise LaosError(f"Potential secret found in evidence {rel}; remove/redact before recording")
    index = load_json(paths(root)["evidence_index"], default={"items": []})
    rec = {
        "evidence_id": str(uuid.uuid4()),
        "task_id": task_id,
        "path": str(rel).replace("\\", "/"),
        "kind": kind,
        "bytes": candidate.stat().st_size,
        "sha256": sha256_file(candidate),
        "recorded_at": utc_now(),
        "actor": actor,
        "source_fingerprint": task_scope_fingerprint(root),
    }
    index.setdefault("items", []).append(rec)
    save_json(paths(root)["evidence_index"], index)
    append_event(root, "EVIDENCE_RECORDED", task_id=task_id, actor=actor, details=rec)
    if ts.get("claimed_by") == actor:
        heartbeat(root, task_id, actor)
    return rec


def record_review(root: Path, task_id: str, verdict: str, reviewer: str, evidence_path: str, notes: str | None, reviewer_session: str | None = None) -> None:
    if verdict not in {"PASS", "PASS_WITH_NON_BLOCKERS", "CONDITIONAL", "FAIL"}:
        raise LaosError("Invalid review verdict")
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    if cfg.get("reviewer_independence_required", True) and reviewer == ts.get("claimed_by"):
        raise LaosError("Reviewer must be independent of the builder/claiming actor")
    if task.get("review_level") == "INDEPENDENT_FRESH_CONTEXT" and not reviewer_session:
        raise LaosError("High-risk review requires --reviewer-session identifying the fresh review context")
    ev = root / evidence_path
    if not ev.exists() or ev.stat().st_size == 0:
        raise LaosError("Review evidence file is missing or empty")
    sample = ev.read_text(encoding="utf-8", errors="ignore")[:2_000_000]
    if any(p.search(sample) for p in SECRET_PATTERNS):
        raise LaosError("Potential secret found in review evidence")
    review = {
        "verdict": verdict,
        "reviewer": reviewer,
        "reviewer_session": reviewer_session,
        "evidence_path": evidence_path.replace("\\", "/"),
        "evidence_sha256": sha256_file(ev),
        "source_fingerprint": task_scope_fingerprint(root),
        "notes": notes,
        "at": utc_now(),
        "builder": ts.get("claimed_by"),
        "review_level": task.get("review_level", "FRESH_CONTEXT"),
    }
    ts["review"] = review
    ts["updated_at"] = utc_now()
    save_json(paths(root)["state"], state)
    append_event(root, "REVIEW_RECORDED", task_id=task_id, actor=reviewer, details=review)

def side_effect_transition(root: Path, task_id: str, operation_id: str, target: str, actor: str,
                           description: str | None, idempotency_key: str | None,
                           external_id: str | None, rollback: str | None) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    get_task(graph, state, task_id)
    path = paths(root)["side_effects"]
    records: list[dict[str, Any]] = []
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                records.append(json.loads(line))
    op_records = [r for r in records if r.get("task_id") == task_id and r.get("operation_id") == operation_id]
    existing = op_records[-1].get("state") if op_records else None
    established_key = next((r.get("idempotency_key") for r in op_records if r.get("idempotency_key")), None)
    if idempotency_key and established_key and idempotency_key != established_key:
        raise LaosError("Idempotency key cannot change during an operation lifecycle")
    key = idempotency_key or established_key
    if key:
        conflict = next((r for r in records if r.get("idempotency_key") == key and (r.get("task_id"), r.get("operation_id")) != (task_id, operation_id)), None)
        if conflict:
            raise LaosError(f"Idempotency key is already used by {conflict.get('task_id')}/{conflict.get('operation_id')}")
    if target in SIDE_EFFECT_TERMINAL:
        if existing is None:
            raise LaosError("Cannot terminate an unregistered side effect")
    elif target not in SIDE_EFFECT_STATES:
        raise LaosError(f"Invalid side-effect state: {target}")
    if existing:
        if existing in SIDE_EFFECT_TERMINAL:
            raise LaosError(f"Side effect is already terminal: {existing}")
        if target in SIDE_EFFECT_STATES:
            expected_idx = SIDE_EFFECT_STATES.index(existing) + 1
            if expected_idx >= len(SIDE_EFFECT_STATES) or SIDE_EFFECT_STATES[expected_idx] != target:
                raise LaosError(f"Illegal side-effect transition {existing} -> {target}")
    else:
        if target != "PROPOSED":
            raise LaosError("New side effect must start at PROPOSED")
        if not description or not key:
            raise LaosError("PROPOSED requires --description and --idempotency-key")
        if not rollback:
            raise LaosError("PROPOSED requires --rollback describing compensation or why it is impossible")
    rec = {
        "record_id": str(uuid.uuid4()),
        "timestamp": utc_now(),
        "task_id": task_id,
        "operation_id": operation_id,
        "previous_state": existing,
        "state": target,
        "description": description or (op_records[0].get("description") if op_records else None),
        "idempotency_key": key,
        "external_id": external_id,
        "rollback_or_compensation": rollback or (op_records[0].get("rollback_or_compensation") if op_records else None),
        "actor": actor,
        "source_fingerprint": task_scope_fingerprint(root),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")
    append_event(root, "SIDE_EFFECT_TRANSITION", task_id=task_id, actor=actor, details=rec)
    return rec

def record_failed_approach(root: Path, task_id: str, actor: str, approach: str, result: str, error_signature: str | None) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    get_task(graph, state, task_id)
    rec = {"record_id": str(uuid.uuid4()), "timestamp": utc_now(), "task_id": task_id, "actor": actor, "approach": approach, "result": result, "error_signature": error_signature}
    path = root / ".laos" / "state" / "failed_approaches.jsonl"
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")
    append_event(root, "FAILED_APPROACH_RECORDED", task_id=task_id, actor=actor, details=rec)
    return rec


def reopen_task(root: Path, task_id: str, actor: str, reason: str) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    if ts.get("status") not in {"BLOCKED", "FAILED", "NEEDS_REPAIR", "NEEDS_ESCALATION"}:
        raise LaosError(f"Task {task_id} is {ts.get('status')}; only blocked, failed, repair or escalation states can be reopened")
    old = ts["status"]
    ts.update({"status": "READY", "claimed_by": None, "claimed_at": None, "started_at": None, "updated_at": utc_now(), "review": None})
    ts.setdefault("notes", []).append({"at": utc_now(), "actor": actor, "text": f"Reopened from {old}: {reason}"})
    ts["repair_count"] = int(ts.get("repair_count", 0)) + 1
    lock_path = paths(root)["locks"] / f"{task_id}.lock.json"
    if lock_path.exists():
        lock_path.unlink()
    save_json(paths(root)["state"], state)
    append_event(root, "TASK_REOPENED", task_id=task_id, actor=actor, details={"from": old, "to": "READY", "reason": reason, "repair_count": ts["repair_count"]})
    render_state_docs(root, graph, state)
    return {"task_id": task_id, "from": old, "to": "READY", "repair_count": ts["repair_count"]}


def task_packet(root: Path, task_id: str) -> Path:
    cfg, graph, state = load_project(root)
    task, ts = get_task(graph, state, task_id)
    reqs_raw = load_json(paths(root)["requirements"], default={"requirements": []})
    reqs = {r.get("id"): r for r in reqs_raw.get("requirements", [])}
    lines = [
        f"# Task Packet - {task_id}: {task.get('title','')}", "",
        f"Generated: `{utc_now()}`", f"Current state: `{ts['status']}`", "",
        "## Objective", "", task.get("description", ""), "",
        "## Requirements", ""
    ]
    for rid in task.get("requirements", []):
        r = reqs.get(rid, {"text": "[missing requirement]"})
        lines.append(f"- `{rid}` - {r.get('text') or r.get('description')}")
    lines += ["", "## Acceptance criteria", ""]
    lines += [f"- {x}" for x in task.get("acceptance_criteria", [])] or ["- None specified (this is a pack defect)."]
    lines += ["", "## Dependencies", ""]
    lines += [f"- `{x}`" for x in task.get("dependencies", [])] or ["- None"]
    lines += ["", "## Scope", "", "Allowed paths:"]
    lines += [f"- `{x}`" for x in task.get("allowed_paths", ["**"])]
    lines += ["", "Forbidden paths:"]
    lines += [f"- `{x}`" for x in task.get("forbidden_paths", [])] or ["- None beyond global LAOS restrictions"]
    lines += ["", "## Preservation contract", ""]
    lines += [f"- {x}" for x in task.get("preserve", [])] or ["- Preserve all verified working behaviour relevant to this task."]
    lines += ["", "## Required permissions", ""]
    lines += [f"- `{x}`" for x in task.get("required_permissions", [])] or ["- No permissions beyond the pack-wide grant and local task scope."]
    lines += ["", "## Review level", "", f"`{task.get('review_level', 'FRESH_CONTEXT')}`", ""]
    lines += ["", "## Required checks", ""]
    for c in task.get("checks", []):
        lines.append(f"- `{c['id']}` [{c.get('stage','TESTED')}] `{c.get('command','')}`")
    if not task.get("checks"):
        lines.append("- None specified (review whether the task is valid).")
    lines += ["", "## Required evidence", ""]
    for e in task.get("evidence_required", []):
        lines.append(f"- `{e['path']}` by stage `{e.get('stage','EVIDENCED')}`")
    if not task.get("evidence_required"):
        lines.append("- None specified (review whether the task is valid).")
    lines += ["", "## Stop conditions", ""]
    lines += [f"- {x}" for x in task.get("stop_conditions", [])] or ["- Any global LAOS stop condition."]
    lines += ["", "## Required operating sequence", "",
              f"1. `python .laos/runtime/laos.py claim {task_id} --actor <agent>`",
              f"2. `python .laos/runtime/laos.py start {task_id} --actor <agent>`",
              "3. Inspect only relevant context and create the task plan evidence.",
              "4. Implement within the allowed path scope.",
              "5. Record changes, create restorable checkpoints, and send heartbeats during long work.",
              "6. Run every required check through `run-check`; command substitutions are not permitted.",
              "7. Record all required evidence.",
              "8. Advance through each legal state; do not manually edit task status.",
              "9. Obtain the required independent/fresh review before closure.",
              "10. Rerun checks and rerecord evidence whenever relevant source changes.",
              "11. Stop honestly if a gate fails.", ""]
    out = root / ".laos" / "state" / "task_packets" / f"{task_id}.md"
    atomic_write(out, "\n".join(lines))
    return out


def safe_zip_entries(zip_path: Path) -> tuple[list[zipfile.ZipInfo], list[str]]:
    issues: list[str] = []
    with zipfile.ZipFile(zip_path, "r") as zf:
        infos = zf.infolist()
        names = [i.filename for i in infos]
        if len(names) != len(set(names)):
            issues.append("duplicate ZIP entry names")
        for info in infos:
            p = PurePosixPath(info.filename)
            if p.is_absolute() or ".." in p.parts:
                issues.append(f"unsafe path traversal entry: {info.filename}")
            if "\\" in info.filename:
                issues.append(f"backslash in archive path: {info.filename}")
        return infos, issues


def iter_source_files(source: Path) -> list[Path]:
    forbidden_parts = {".git", "node_modules", "__pycache__", ".venv", "venv"}
    files = []
    for p in source.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(source)
        if any(part in forbidden_parts for part in rel.parts):
            continue
        if p.suffix.lower() == ".zip":
            raise LaosError(f"Nested ZIP forbidden: {p}")
        if p.name.lower() in {".env", ".env.local", ".env.production"}:
            raise LaosError(f"Real environment file forbidden: {p}")
        files.append(p)
    return sorted(files, key=lambda x: str(x.relative_to(source)).replace("\\", "/"))


def artifact_build(root: Path, source_arg: str, output_arg: str) -> dict[str, Any]:
    source = (root / source_arg).resolve() if not Path(source_arg).is_absolute() else Path(source_arg).resolve()
    output = (root / output_arg).resolve() if not Path(output_arg).is_absolute() else Path(output_arg).resolve()
    if not source.is_dir():
        raise LaosError(f"Artifact source is not a directory: {source}")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    files = iter_source_files(source)
    if not files:
        raise LaosError("Artifact source directory contains no files")
    manifest = []
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for file in files:
            rel = str(file.relative_to(source)).replace("\\", "/")
            data = file.read_bytes()
            if any(p.search(data.decode("utf-8", errors="ignore")) for p in SECRET_PATTERNS):
                raise LaosError(f"Potential secret found; artifact not created: {file}")
            zi = zipfile.ZipInfo(rel)
            zi.date_time = (1980, 1, 1, 0, 0, 0)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, data)
            manifest.append({"path": rel, "bytes": len(data), "sha256": sha256_bytes(data)})
    freeze = {
        "created_at": utc_now(),
        "source": str(source),
        "artifact": str(output),
        "files": manifest,
        "entry_count": len(manifest),
        "artifact_bytes": output.stat().st_size,
        "artifact_sha256": sha256_file(output),
        "status": "CREATED_NOT_VERIFIED",
    }
    freeze_path = output.with_suffix(output.suffix + ".freeze_manifest.json")
    save_json(freeze_path, freeze)
    append_event(root, "ARTIFACT_CREATED", actor="harness", details={"artifact": str(output), "freeze_manifest": str(freeze_path)})
    return freeze


def artifact_verify(root: Path, artifact_arg: str, source_arg: str | None, report_arg: str | None) -> dict[str, Any]:
    artifact = (root / artifact_arg).resolve() if not Path(artifact_arg).is_absolute() else Path(artifact_arg).resolve()
    if not artifact.exists():
        raise LaosError(f"Artifact not found: {artifact}")
    infos, issues = safe_zip_entries(artifact)
    source = None
    source_manifest: dict[str, dict[str, Any]] = {}
    if source_arg:
        source = (root / source_arg).resolve() if not Path(source_arg).is_absolute() else Path(source_arg).resolve()
        for file in iter_source_files(source):
            rel = str(file.relative_to(source)).replace("\\", "/")
            source_manifest[rel] = {"bytes": file.stat().st_size, "sha256": sha256_file(file)}
    extracted_manifest: dict[str, dict[str, Any]] = {}
    with tempfile.TemporaryDirectory(prefix="laos_verify_") as td:
        dest = Path(td)
        with zipfile.ZipFile(artifact, "r") as zf:
            zf.extractall(dest)
        for file in sorted(dest.rglob("*")):
            if file.is_file():
                rel = str(file.relative_to(dest)).replace("\\", "/")
                extracted_manifest[rel] = {"bytes": file.stat().st_size, "sha256": sha256_file(file)}
                text = file.read_text(encoding="utf-8", errors="ignore")
                if any(p.search(text) for p in SECRET_PATTERNS):
                    issues.append(f"possible secret in entry: {rel}")
                if rel.endswith("_zip_verification.txt") or rel.endswith(".verification.json") or "artifact_finalization_lock" in rel:
                    issues.append(f"self-referential verifier inside artifact: {rel}")
    if source is not None:
        if set(source_manifest) != set(extracted_manifest):
            missing = sorted(set(source_manifest) - set(extracted_manifest))
            extra = sorted(set(extracted_manifest) - set(source_manifest))
            if missing:
                issues.append("missing entries compared with source: " + ", ".join(missing))
            if extra:
                issues.append("extra entries compared with source: " + ", ".join(extra))
        for rel in set(source_manifest) & set(extracted_manifest):
            if source_manifest[rel] != extracted_manifest[rel]:
                issues.append(f"source/ZIP snapshot mismatch: {rel}")
    report = {
        "verified_at": utc_now(),
        "artifact": str(artifact),
        "artifact_bytes": artifact.stat().st_size,
        "entry_count": len(infos),
        "artifact_sha256": sha256_file(artifact),
        "source": str(source) if source else None,
        "snapshot_equality_checked": source is not None,
        "issues": sorted(set(issues)),
        "status": "PASS" if not issues else "FAIL",
        "entries": extracted_manifest,
    }
    report_path = Path(report_arg).resolve() if report_arg else artifact.with_suffix(artifact.suffix + ".verification.json")
    if report_path == artifact or str(report_path).startswith(str(artifact) + os.sep):
        raise LaosError("Verification report must remain outside the artifact")
    save_json(report_path, report)
    lock = {
        "locked_at": utc_now(),
        "artifact": str(artifact),
        "verification_report": str(report_path),
        "verified_bytes": report["artifact_bytes"],
        "verified_entry_count": report["entry_count"],
        "verified_sha256": report["artifact_sha256"],
        "status": report["status"],
    }
    lock_path = artifact.with_suffix(artifact.suffix + ".finalization_lock.json")
    save_json(lock_path, lock)
    append_event(root, "ARTIFACT_VERIFIED", actor="harness", details={"artifact": str(artifact), "report": str(report_path), "status": report["status"]})
    return report


def artifact_lock_check(artifact: Path, lock_path: Path | None = None) -> dict[str, Any]:
    if lock_path is None:
        lock_path = artifact.with_suffix(artifact.suffix + ".finalization_lock.json")
    lock = load_json(lock_path)
    infos, issues = safe_zip_entries(artifact)
    current = {
        "bytes": artifact.stat().st_size,
        "entry_count": len(infos),
        "sha256": sha256_file(artifact),
    }
    if current["bytes"] != lock.get("verified_bytes"):
        issues.append("byte size changed after verification")
    if current["entry_count"] != lock.get("verified_entry_count"):
        issues.append("entry count changed after verification")
    if current["sha256"] != lock.get("verified_sha256"):
        issues.append("SHA-256 changed after verification")
    return {"status": "PASS" if not issues else "FAIL", "artifact": str(artifact), "lock": str(lock_path), "current": current, "issues": issues}


def audit(root: Path) -> dict[str, Any]:
    result = doctor(root)
    cfg, graph, state = load_project(root)
    tasks = task_map(graph)
    closure_issues: list[str] = []
    side_effect_issues: list[str] = []
    for tid, task in tasks.items():
        ts = state["task_states"][tid]
        if ts["status"] == "CLOSED":
            try:
                required_checks_pass(root, task, "CLOSED")
                required_evidence_exists(root, task, "CLOSED")
                validate_changed_files(root, task, ts)
                effects = side_effect_status(root, tid)
                unresolved = [op for op in task.get("side_effects_required", []) if effects.get(op) not in SIDE_EFFECT_TERMINAL]
                if unresolved:
                    side_effect_issues.append(f"{tid}: unresolved side effects {unresolved}")
            except LaosError as e:
                closure_issues.append(f"{tid}: {e}")
    result["closure_issues"] = closure_issues
    result["side_effect_issues"] = side_effect_issues
    if closure_issues or side_effect_issues:
        result["status"] = "FAIL"
    return result


def finalize_project(root: Path, actor: str) -> dict[str, Any]:
    cfg, graph, state = load_project(root)
    tasks = task_map(graph)
    not_closed = []
    for tid, task in tasks.items():
        status = state["task_states"][tid]["status"]
        mandatory = task.get("mandatory", True)
        if mandatory and status != "CLOSED":
            not_closed.append(f"{tid}={status}")
        if not mandatory and status not in {"CLOSED", "DEFERRED", "SUPERSEDED"}:
            not_closed.append(f"{tid}={status}")
    if not_closed:
        raise LaosError("Finalization blocked; tasks not in an acceptable terminal state: " + ", ".join(not_closed))
    audit_result = audit(root)
    if audit_result.get("status") != "PASS":
        raise LaosError("Finalization audit failed: " + json.dumps(audit_result.get("closure_issues") or audit_result.get("side_effect_issues") or audit_result.get("missing")))
    baseline = state.get("repository_baseline") or {}
    if cfg.get("expected_repository_fingerprint") and baseline.get("status") != "PASS":
        raise LaosError("Finalization blocked: repository baseline was never verified")
    task_rows = []
    for tid, task in sorted(tasks.items()):
        ts = state["task_states"][tid]
        task_rows.append({"task_id": tid, "title": task.get("title"), "status": ts.get("status"), "review": ts.get("review")})
    report = {
        "laos_version": VERSION,
        "finalized_at": utc_now(),
        "finalized_by": actor,
        "project": load_json(paths(root)["manifest"], default={}).get("project_name", root.name),
        "acceptance": "ACCEPTED",
        "project_fingerprint": project_fingerprint(root),
        "git": git_info(root),
        "tasks": task_rows,
        "event_chain": verify_event_chain(root),
        "known_limits": [],
        "audit": audit_result,
    }
    final_json = root / "Evidence" / "FINAL_ACCEPTANCE_REPORT.json"
    save_json(final_json, report)
    lines = [
        "# FINAL TRUTH REPORT", "", f"Finalized at `{report['finalized_at']}` by `{actor}`.", "",
        f"Acceptance: **{report['acceptance']}**", "", f"Project fingerprint: `{report['project_fingerprint']}`", "",
        "## Task disposition", "", "| Task | Status | Title |", "|---|---|---|",
    ]
    for row in task_rows:
        lines.append(f"| {row['task_id']} | {row['status']} | {row['title']} |")
    lines += ["", "## Truth boundary", "", "This report is generated from the LAOS state, current source fingerprint, registered evidence, exact check transcripts, reviews, side-effect journal, and Git truth. It does not convert unknown external state into a success claim.", ""]
    atomic_write(root / "Evidence" / "FINAL_TRUTH_REPORT.md", "\n".join(lines))
    state["acceptance_state"] = "ACCEPTED"
    state["finalized_at"] = report["finalized_at"]
    state["finalized_by"] = actor
    save_json(paths(root)["state"], state)
    append_event(root, "PROJECT_FINALIZED", actor=actor, details={"acceptance": "ACCEPTED", "report": "Evidence/FINAL_ACCEPTANCE_REPORT.json", "project_fingerprint": report["project_fingerprint"]})
    anchor = anchor_event_chain(root, actor)
    report["event_anchor"] = anchor
    save_json(final_json, report)
    render_state_docs(root, graph, state)
    return report

def print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LAOS v7 portable runtime")
    parser.add_argument("--root", help="Project root containing .laos")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="subcommand", required=True)

    sub.add_parser("doctor")
    sub.add_parser("status")
    sub.add_parser("next")
    sub.add_parser("audit")
    sub.add_parser("refresh")
    p = sub.add_parser("finalize"); p.add_argument("--actor", required=True)
    p = sub.add_parser("verify-baseline"); p.add_argument("--actor", required=True); p.add_argument("--accept-current", action="store_true"); p.add_argument("--reason")
    p = sub.add_parser("anchor"); p.add_argument("--actor", required=True); p.add_argument("--external-path")

    p = sub.add_parser("claim"); p.add_argument("task_id"); p.add_argument("--actor", required=True)
    p = sub.add_parser("start"); p.add_argument("task_id"); p.add_argument("--actor", required=True)
    p = sub.add_parser("heartbeat"); p.add_argument("task_id"); p.add_argument("--actor", required=True)
    p = sub.add_parser("advance"); p.add_argument("task_id"); p.add_argument("--to", required=True, choices=sorted(ALL_STATES)); p.add_argument("--actor", required=True); p.add_argument("--note")
    p = sub.add_parser("block"); p.add_argument("task_id"); p.add_argument("--actor", required=True); p.add_argument("--reason", required=True)
    p = sub.add_parser("reopen"); p.add_argument("task_id"); p.add_argument("--actor", required=True); p.add_argument("--reason", required=True)
    p = sub.add_parser("clear-stale-lock"); p.add_argument("task_id"); p.add_argument("--actor", required=True); p.add_argument("--reason", required=True)
    p = sub.add_parser("record-change"); p.add_argument("task_id"); p.add_argument("path"); p.add_argument("--reason", required=True); p.add_argument("--actor", required=True)
    p = sub.add_parser("checkpoint"); p.add_argument("task_id"); p.add_argument("--actor", required=True); p.add_argument("--note")
    p = sub.add_parser("recover"); p.add_argument("checkpoint"); p.add_argument("--actor", required=True); p.add_argument("--confirm", action="store_true"); p.add_argument("--delete-extra", action="store_true")
    p = sub.add_parser("run-check"); p.add_argument("task_id"); p.add_argument("check_id"); p.add_argument("--actor", required=True)
    p = sub.add_parser("record-evidence"); p.add_argument("task_id"); p.add_argument("path"); p.add_argument("--kind", required=True); p.add_argument("--actor", required=True)
    p = sub.add_parser("record-review"); p.add_argument("task_id"); p.add_argument("--verdict", required=True); p.add_argument("--reviewer", required=True); p.add_argument("--reviewer-session"); p.add_argument("--evidence", required=True); p.add_argument("--notes")
    p = sub.add_parser("failed-approach"); p.add_argument("task_id"); p.add_argument("--actor", required=True); p.add_argument("--approach", required=True); p.add_argument("--result", required=True); p.add_argument("--error-signature")
    p = sub.add_parser("task-packet"); p.add_argument("task_id")

    p = sub.add_parser("side-effect")
    p.add_argument("task_id"); p.add_argument("operation_id"); p.add_argument("--to", required=True)
    p.add_argument("--actor", required=True); p.add_argument("--description"); p.add_argument("--idempotency-key")
    p.add_argument("--external-id"); p.add_argument("--rollback")

    p = sub.add_parser("amendment-propose"); p.add_argument("amendment_id"); p.add_argument("--actor", required=True); p.add_argument("--title", required=True); p.add_argument("--reason", required=True); p.add_argument("--impact", required=True)
    p = sub.add_parser("amendment-approve"); p.add_argument("amendment_id"); p.add_argument("--approver", required=True)

    p = sub.add_parser("artifact-build"); p.add_argument("--source", required=True); p.add_argument("--output", required=True)
    p = sub.add_parser("artifact-verify"); p.add_argument("artifact"); p.add_argument("--source"); p.add_argument("--report")
    p = sub.add_parser("artifact-lock-check"); p.add_argument("artifact"); p.add_argument("--lock")
    return parser

def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        root = find_root(args.root)
        cmd = args.subcommand
        if cmd == "doctor":
            result = doctor(root); print_json(result); return 0 if result["status"] == "PASS" else 2
        if cmd == "status":
            refresh_ready(root); _, graph, state = load_project(root); render_state_docs(root, graph, state); print(paths(root)["run_state_md"].read_text(encoding="utf-8")); return 0
        if cmd == "next":
            refresh_ready(root); _, graph, state = load_project(root); tasks = task_map(graph)
            ready = [(t.get("priority",999), tid, t) for tid,t in tasks.items() if state["task_states"][tid]["status"] == "READY"]
            if not ready: print("No READY task."); return 3
            _, tid, task = sorted(ready)[0]; packet = task_packet(root, tid); print_json({"task_id": tid, "title": task.get("title"), "task_packet": str(packet)}); return 0
        if cmd == "audit":
            result = audit(root); print_json(result); return 0 if result["status"] == "PASS" else 2
        if cmd == "refresh": print_json({"newly_ready": refresh_ready(root)}); return 0
        if cmd == "finalize": print_json(finalize_project(root, args.actor)); return 0
        if cmd == "verify-baseline": print_json(verify_repository_baseline(root, args.actor, accept_current=args.accept_current, reason=args.reason)); return 0
        if cmd == "anchor": print_json(anchor_event_chain(root, args.actor, args.external_path)); return 0
        if cmd == "claim": claim_task(root, args.task_id, args.actor); print("CLAIMED"); return 0
        if cmd == "start": start_task(root, args.task_id, args.actor); print("IN_PROGRESS"); return 0
        if cmd == "heartbeat": print_json(heartbeat(root, args.task_id, args.actor)); return 0
        if cmd == "advance": advance_task(root, args.task_id, args.to, args.actor, args.note); print(args.to); return 0
        if cmd == "block": advance_task(root, args.task_id, "BLOCKED", args.actor, args.reason); print("BLOCKED"); return 0
        if cmd == "reopen": print_json(reopen_task(root, args.task_id, args.actor, args.reason)); return 0
        if cmd == "clear-stale-lock": print_json(clear_stale_lock(root, args.task_id, args.actor, args.reason)); return 0
        if cmd == "record-change": record_change(root, args.task_id, args.path, args.reason, args.actor); print("RECORDED"); return 0
        if cmd == "checkpoint": print(checkpoint(root, args.task_id, args.actor, args.note)); return 0
        if cmd == "recover": print_json(recover_checkpoint(root, args.checkpoint, args.actor, confirm=args.confirm, delete_extra=args.delete_extra)); return 0
        if cmd == "run-check":
            rec = run_check(root, args.task_id, args.check_id, args.actor, None); print_json(rec); return 0 if rec["exit_code"] == 0 else 2
        if cmd == "record-evidence": print_json(record_evidence(root, args.task_id, args.path, args.kind, args.actor)); return 0
        if cmd == "record-review": record_review(root, args.task_id, args.verdict, args.reviewer, args.evidence, args.notes, args.reviewer_session); print("RECORDED"); return 0
        if cmd == "failed-approach": print_json(record_failed_approach(root, args.task_id, args.actor, args.approach, args.result, args.error_signature)); return 0
        if cmd == "task-packet": print(task_packet(root, args.task_id)); return 0
        if cmd == "side-effect": print_json(side_effect_transition(root, args.task_id, args.operation_id, args.to, args.actor, args.description, args.idempotency_key, args.external_id, args.rollback)); return 0
        if cmd == "amendment-propose": print(propose_amendment(root, args.amendment_id, args.actor, args.title, args.reason, args.impact)); return 0
        if cmd == "amendment-approve": print_json(approve_amendment(root, args.amendment_id, args.approver)); return 0
        if cmd == "artifact-build": print_json(artifact_build(root, args.source, args.output)); return 0
        if cmd == "artifact-verify":
            result = artifact_verify(root, args.artifact, args.source, args.report); print_json(result); return 0 if result["status"] == "PASS" else 2
        if cmd == "artifact-lock-check":
            artifact = Path(args.artifact).resolve(); lock = Path(args.lock).resolve() if args.lock else None
            result = artifact_lock_check(artifact, lock); print_json(result); return 0 if result["status"] == "PASS" else 2
        raise LaosError(f"Unhandled command: {cmd}")
    except LaosError as e:
        print(f"LAOS ERROR: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("LAOS interrupted; create or inspect a checkpoint before continuing.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())
